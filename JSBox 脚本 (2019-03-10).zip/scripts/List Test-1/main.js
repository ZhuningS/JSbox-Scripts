
const actionSum = 3
const duration = 0.55
const rowHeight = 80
const offset = rowHeight*3
const iconSize = rowHeight*40/48
const fontSize = rowHeight*8/48
const leftSensitivity = -50
const fontName = 'PingFangHK-Regular'



function actionPlus(text,rowHeight,fontName){
    var rowHeight = rowHeight ? rowHeight : 80
    var fontName = fontName ? fontName : 'PingFangHK-Regular'
    let offset = rowHeight*3
    let iconSize = rowHeight*40/48
    let fontSize = rowHeight*8/48
    return {
        type:"view",
        events: {
            tapped: function(sender) {
                $ui.toast("message");
            }
            },
        views:[{
            views:[{
                type: "web",
                views:[
                    {
                        type: "label",
                        props: {
                          text: $l10n(text),
                          color:$color("white"),
                          align: $align.center,
                          font:$font(fontName, fontSize)
                        },
                        layout: (make,view)=>{
                            make.size.equalTo($size(iconSize,iconSize))
                            make.centerY.equalTo(view.super.bottom).offset(-fontSize/4)
                            make.centerX.equalTo(view.super)
                        }
                      }
                ],
                props: {        
                  title: "Button",
                  html:$file.read("assets/linkIcon.html").string,
                  transparent:false,
                  showsProgress:false,
                  userInteractionEnabled:false
                },
                layout:$layout.fill
              },
            ],
            layout:(make,view)=>{
                make.size.equalTo($size(iconSize,iconSize))
                make.centerY.equalTo(view.super).offset(-fontSize/2)
                make.centerX.equalTo(view.super.left).offset(offset/actionSum/2)
            }
        }],
        props:{
            id:"action_1",
            bgcolor:$color("#157EFB"),
            userInteractionEnabled:true,
        },
        layout: function(make, view) {
            make.left.equalTo(view.super.right)
            make.centerY.equalTo(view.super)
            make.height.equalTo(view.super)
            make.width.equalTo(view.super).multipliedBy(1)
          },
    }
}


const action_1 = {
    type:"view",
    events: {
        tapped: function(sender) {
            $ui.toast("message");
        }
        },
    views:[{
        views:[{
            type: "web",
            views:[
                {
                    type: "label",
                    props: {
                      text: $l10n('SHARE'),
                      color:$color("white"),
                      align: $align.center,
                      font:$font(fontName, fontSize)
                    },
                    layout: (make,view)=>{
                        make.size.equalTo($size(iconSize,iconSize))
                        make.centerY.equalTo(view.super.bottom).offset(-fontSize/4)
                        make.centerX.equalTo(view.super)
                    }
                  }
            ],
            props: {        
              title: "Button",
              html:$file.read("assets/linkIcon.html").string,
              transparent:false,
              showsProgress:false,
              userInteractionEnabled:false
            },
            layout:$layout.fill
          },
        ],
        layout:(make,view)=>{
            make.size.equalTo($size(iconSize,iconSize))
            make.centerY.equalTo(view.super).offset(-fontSize/2)
            make.centerX.equalTo(view.super.left).offset(offset/actionSum/2)
        }
    }],
    props:{
        id:"action_1",
        bgcolor:$color("#157EFB"),
        userInteractionEnabled:true,
    },
    layout: function(make, view) {
        make.left.equalTo(view.super.right)
        make.centerY.equalTo(view.super)
        make.height.equalTo(view.super)
        make.width.equalTo(view.super).multipliedBy(1)
      },
}

const action_2 = {
    type:"view",
    events: {
        tapped: function(sender) {
            $ui.toast("message");
        }
        },
    views:[{
        views:[{
            type: "web",
            views:[
                {
                    type: "label",
                    props: {
                      text: $l10n('MORE'),
                      color:$color("white"),
                      align: $align.center,
                      font:$font(fontName, fontSize)
                    },
                    layout: (make,view)=>{
                        make.size.equalTo($size(iconSize,iconSize))
                        make.centerY.equalTo(view.super.bottom).offset(-fontSize/4)
                        make.centerX.equalTo(view.super)
                    }
                  }
            ],
            props: {        
              title: "Button",
              html:$file.read("assets/setting.html").string,
              transparent:false,
              showsProgress:false,
              userInteractionEnabled:false
            },
            layout:$layout.fill
          },
        ],
        layout:(make,view)=>{
            make.size.equalTo($size(iconSize,iconSize))
            make.centerY.equalTo(view.super).offset(-fontSize/2)
            make.centerX.equalTo(view.super.left).offset(offset/actionSum/2)
        }
    }],
    props:{
        id:"action_2",
        bgcolor:$color("#FFCC00"),
        userInteractionEnabled:true,
    },
    layout: function(make, view) {
        make.left.equalTo(view.super.right)
        make.centerY.equalTo(view.super)
        make.height.equalTo(view.super)
        make.width.equalTo(view.super).multipliedBy(1)
      },

}

const action_3 = {
    type:"view",
    events: {
        tapped: function(sender) {
            $ui.toast("message");
        }
        },
    views:[{
        views:[{
            type: "web",
            views:[
                {
                    type: "label",
                    props: {
                      text: $l10n('DELETE'),
                      color:$color("white"),
                      align: $align.center,
                      font:$font(fontName, fontSize)
                    },
                    layout: (make,view)=>{
                        make.size.equalTo($size(iconSize,iconSize))
                        make.centerY.equalTo(view.super.bottom).offset(-fontSize/4)
                        make.centerX.equalTo(view.super)
                    }
                  }
            ],
            props: {        
              title: "Button",
              html:$file.read("assets/trash.html").string,
              transparent:false,
              showsProgress:false,
              userInteractionEnabled:false
            },
            layout:$layout.fill
          },
        ],
        layout:(make,view)=>{
            make.size.equalTo($size(iconSize,iconSize))
            make.centerY.equalTo(view.super).offset(-fontSize/2)
            make.centerX.equalTo(view.super.left).offset(offset/actionSum/2)
        }
    }],
    props:{
        id:"action_3",
        bgcolor:$color("#FF2D55"),
        userInteractionEnabled:true,
    },
    layout: function(make, view) {
        make.left.equalTo(view.super.right)
        make.centerY.equalTo(view.super)
        make.height.equalTo(view.super)
        make.width.equalTo(view.super).multipliedBy(1)
      },

}

$ui.render({
    props: {
        title: "LIST TEST"
    },
    views: [
        {
       
            type: "list",
            props: {
                rowHeight:rowHeight,
                template: {
                    props: {
                      bgcolor: $color("clear")
                    },
                    views: [

                      {
                        type: "label",
                        props: {
                          id: "label111",
                          bgcolor: $color("clear"),
                          textColor: $color("#abb2bf"),
                          align: $align.center,
                          font: $font(32)
                        },
                        layout: $layout.fill
                      },
                      {
                        type:"button",
                        props: {
                            id:'icon',
                          
                          bgcolor: $color("clear"),
                          align: $align.left
                        },
                        layout: (make,view)=>{
                            make.left.equalTo(view.super).offset(20)
                            make.centerY.equalTo(view.super)
                        }
                    },
                    {
                      type:"img",
                      props: {
                        id:'iconButton',
                        
                        bgcolor: $color("red"),
                        align: $align.center
                      },
                      layout: (make,view)=>{
                          make.center.equalTo(view.super)
                      }
                  }
                    ]
                  },
                  data: [
                    
                
                  {
                    title: "System (Text)",
                    rows: [
                      {
                        type: "view",
                        views:[
                          action_1,
                          action_2,
                          action_3 
                        ],
                        props: {
                          id:"slide",
                          title: "Button",
                          bgcolor:$color('clear'),
                        },
                        layout: function(make, view) {
                          make.center.equalTo(view.super)
                          make.height.equalTo(view.super)
                          make.width.equalTo(view.super).multipliedBy(1)
                        },
                        events: {
                          touchesBegan: function(sender, location) {
                            $cache.set("beganLocation", location);
                          },
                          touchesMoved: function(sender, location) {

                          },
                          touchesEnded:function(sender,location){
                            let beganLocation = $cache.get("beganLocation");
                            $console.info(location.x-beganLocation.x);
                            if(location.x-beganLocation.x<leftSensitivity){
                              $device.taptic(2);
                              $delay(0, function() {
                                $delay(0,function(){
                                  sender.animator.moveXY({x:-offset,y:0}).easeOutBack.animate(duration)
                                  $('action_2').animator.moveXY({x:offset/actionSum,y:0}).easeOutBack.animate(duration)
                                  $('action_3').animator.moveXY({x:offset/actionSum*(actionSum-1),y:0}).easeOutBack.animate(duration)
                                })
                              });
                              
                            }
                            else{
                                $delay(0, function() {
                                    sender.animator.moveXY({x:-offset/6,y:0}).easeOutBack.animate(duration)
                                    $('action_2').animator.moveXY({x:offset/actionSum/6,y:0}).easeOutBack.animate(duration)
                                    $('action_3').animator.moveXY({x:offset/actionSum*(actionSum-1)/6,y:0}).easeOutBack.animate(duration)
                                    $delay(.6,function(){
                                        sender.animator.moveXY({x:offset/6,y:0}).easeOutBack.animate(duration)
                                        $('action_2').animator.moveXY({x:-offset/actionSum/6,y:0}).easeOutBack.animate(duration)
                                        $('action_3').animator.moveXY({x:-offset/actionSum*(actionSum-1)/6,y:0}).easeOutBack.animate(duration)
                                    })
                                  });
                            }
                          }
                        }
                      },{},{},
                      {
                        icon:{
                              icon: $icon("005", $color("gray"), $size(20, 20)),
                          },
                          label111: {
                          text: "Hello"
                          }
                      },
                      {
                          label111: {
                          text: "World"
                          }
                      },
                      "JavaScript", "Swift",
                      {
                        iconButton:{
                          icon: $icon("005", $color("black"), $size(20, 20)),
                      }
                    },
                    ]
                  },
                  ],
                 
            },
            events: {
              didSelect:function(sender, indexPath, data) {

            }
          },
            layout: $layout.fill
        
    }


]
});