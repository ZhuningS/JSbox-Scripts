var launcherData = JSON.parse($file.read("assets/launcherData.json").string)
var bookmarkData = JSON.parse($file.read("assets/bookmarkData.json").string)
var qrCodeData = JSON.parse($file.read("assets/qrCodeData.json").string)
var launcherDataDel = []
var bookmarkDataDel = []
var qrCodeDataDel = []
var newLogoImg
var newQRImg
var logoShadowColor
var count = 0
var type = 1
var viewType = 0
var logoItems = 4
var labelhidden = false
var shadowhidden = false
var buyMeaCoffee = require('scripts/coffee')
buyMeaCoffee.showcoffee()

if ($cache.get("type")) {
  type = $cache.get("type").type
  logoItems = $cache.get("type").iconSize
  labelhidden = $cache.get("type").titleDisplay
  shadowhidden = $cache.get("type").shadowDisplay
}
var data = martixData()
var screenWidth = $device.info.screen.width
var logoViewWidth = screenWidth / logoItems
var logoViewHeight = logoViewWidth * (95 / (screenWidth / 4))
var logoViewRadius = 55 / (screenWidth / 4)
var logoTopinsetRadius = 10 / 95
var logoTopinset = logoViewHeight * logoTopinsetRadius
var logoWidth = logoViewWidth * logoViewRadius
var labelViewRadius = 20 / 95
var labelHeight = logoViewHeight * labelViewRadius
var fontSizeRadius = 12 / 20
var fontSize = labelHeight * fontSizeRadius
var shadowWidthRadius = 45 / 55
var shadowWidth = logoWidth * shadowWidthRadius
if (labelhidden == true) {
  logoViewHeight = logoViewHeight - labelHeight
}

$ui.render({
  props: {
    id: "mainView",
    navButtons: [
      {
        icon: "058",
        handler: function () {
          buyMeaCoffee.coffee()
        }
      }
    ]
  },
  views: [{
    type: "matrix",
    props: {
      id: "NLauncher",
      columns: logoItems,
      itemHeight: logoViewHeight,
      spacing: 0,
      data: data,
      reorder: true,
      template: {
        props: {},
        views: [{
          type: "view",
          props: {
            id: "shadowView",
            hidden: shadowhidden
          },
          layout: function (make, view) {
            make.size.equalTo($size(shadowWidth, logoWidth))
            make.top.inset(logoTopinset)
            make.centerX.equalTo(view.super.centerX)
          }
        }, {
          type: "image",
          props: {
            id: "logoImg",
            smoothRadius: 10
          },
          layout: function (make, view) {
            make.size.equalTo($size(logoWidth, logoWidth))
            make.top.inset(logoTopinset)
            make.centerX.equalTo(view.super.centerX)
          }
        }, {
          type: "label",
          props: {
            id: "logoName",
            textColor: $color("#181B39"),
            align: $align.center,
            font: $font(fontSize),
            hidden: labelhidden
          },
          layout: function (make, view) {
            make.right.left.bottom.inset(0)
            make.height.equalTo(labelHeight)
          }
        }]
      }
    },
    layout: $layout.fill,
    events: {
      forEachItem: function (view, indexPath) {
        shadow(view.views[0], data[count].shadowView.bgcolor)
        count++
      },
      didSelect: function (sender, indexPath, data) {
        open(indexPath.row)
      },
      reorderMoved: function (fromIndexPath, toIndexPath) {
        if (type == 0) {
          bookmarkData = orderItem(bookmarkData, fromIndexPath.row, toIndexPath.row)
        } else if (type == 1) {
          launcherData = orderItem(launcherData, fromIndexPath.row, toIndexPath.row)
        } else if (type == 2) {
          qrCodeData = orderItem(qrCodeData, fromIndexPath.row, toIndexPath.row)
        } else { }
      },
      reorderFinished: function (data) {
        dataWriteandDel()
      }
    }
  }, {
    type: "button",
    props: {
      id: "rightBt",
      title: " ",
      titleColor: $color("#AAAAAA"),
      bgcolor: $color("clear")
    },
    layout: function (make, view) {
      make.centerY.equalTo(view.super.centerY)
      make.right.inset(10)
      make.size.equalTo($size(30, 50))
    },
    events: {
      tapped: function (sender) {
        blqSwitch(1)
      }
    }
  }, {
    type: "button",
    props: {
      id: "leftBt",
      title: " ",
      titleColor: $color("#AAAAAA"),
      bgcolor: $color("clear")
    },
    layout: function (make, view) {
      make.centerY.equalTo(view.super.centerY)
      make.left.inset(10)
      make.size.equalTo($size(30, 50))
    },
    events: {
      tapped: function (sender) {
        blqSwitch(0)
      }
    }
  }, {
    type: "view",
    props: {
      id: "addBtView",
      clipsToBounds: false,
      bgcolor: $color("white"),
      hidden: true
    },
    views: [{
      type: "button",
      props: {
        title: "╋",
        titleColor: $color("#AAAAAA"),
        bgcolor: $color("clear")
      },
      layout: $layout.fill,
      events: {
        tapped: function (sender) {
          viewType = 0
          addnewitem()
        },
        longPressed: function () {
          viewType = 1
          addnewitem()
        }
      }
    }],
    layout: function (make, view) {
      make.size.equalTo($size(40, 40))
      make.centerX.equalTo(view.super.centerX)
      make.bottom.inset(20)
      shadow(view, $color("gray"))
    }
  }, {
    type: "view",
    props: {
      id: "addItemsView",
      alpha: 0,
      bgcolor: $color("#F9F9F8")
    },
    layout: function (make, view) {
      make.edges.inset(20)
      shadow(view, $color("gray"))
    }
  }, {
    type: "view",
    props: {
      id: "showQRView",
      bgcolor: $color("clear"),
      hidden: true
    },
    views: [{
      type: "blur",
      props: {
        alpha: 0,
        style: 4
      },
      layout: $layout.fill
    }, {
      type: "image",
      props: {
        id: "showQRImg",
        smoothRadius: 10
      },
      layout: function (make, view) {
        make.center.equalTo(view.super)
        make.size.equalTo($size(150, 150))
      },
      events: {
        tapped: function (sender) {
          $ui.animate({
            duration: 0.3,
            animation: function () {
              $("blur").alpha = 0
              $("showQRImg").scale(1)
            }
          })
          $("showQRView").hidden = true
        }
      }
    }],
    layout: $layout.fill
  }]
})

function shadow(view, color) {
  var layer = view.runtimeValue().invoke("layer")
  layer.invoke("setCornerRadius", 10)
  layer.invoke("setShadowOffset", $size(0, 7))
  layer.invoke("setShadowColor", color.runtimeValue().invoke("CGColor"))
  layer.invoke("setShadowOpacity", 0.6)
  layer.invoke("setShadowRadius", 5)
}

if ($app.env != $env.today) {
  $("addBtView").hidden = false
  $("rightBt").title = ">"
  $("leftBt").title = "<"
}

var newLogoItems = {
  type: "view",
  props: {
    id: "newLogoItemsView",
    bgcolor: $color("clear")
  },
  views: [{
    type: "view",
    props: {
      id: "newLogoShadow",
      alpha: 0.4,
      bgcolor: $color("gray")
    },
    views: [{
      type: "button",
      props: {
        id: "newLogoBt",
        icon: $icon("104", $color("white"), $size(20, 20)),
        bgcolor: $color("clear")
      },
      layout: $layout.fill,
      events: {
        tapped: function (sender) {
          addLogoQR("logo")
        }
      }
    }],
    layout: function (make, view) {
      make.centerX.equalTo(view.super.centerX)
      make.top.inset(40)
      make.size.equalTo($size(55, 55))
      shadow(view, $color("gray"))
    }
  }, {
    type: "image",
    props: {
      id: "newLogo",
      bgcolor: $color("clear"),
      smoothRadius: 10
    },
    layout: function (make, view) {
      make.centerX.equalTo(view.super.centerX)
      make.top.inset(40)
      make.size.equalTo($size(55, 55))
    }
  }, {
    type: "tab",
    props: {
      alpha: 0.8,
      items: [$l10n("BOOKMARK"), $l10n("LAUNCHER"), $l10n("QRCODE")],
      index: type,
      tintColor: $color("white")
    },
    layout: function (make, view) {
      make.centerX.equalTo(view.super.centerX)
      make.top.inset(115)
      make.height.equalTo(30)
      shadow(view, $color("gray"))
    },
    events: {
      changed: function (sender) {
        type = sender.index
        listType(type)
      }
    }
  }],
  layout: $layout.fill
}

var launcherListItems = [
  {
    title: $l10n("TITLE"),
    rows: [{
      type: "input",
      props: {
        id: "newTitle",
        bgcolor: $color("white"),
        placeholder: "Neurogram"
      },
      layout: $layout.fill
    }]
  },
  {
    title: $l10n("URL"),
    rows: [{
      type: "view",
      props: {

      },
      views: [{
        type: "input",
        props: {
          id: "newUrl",
          bgcolor: $color("clear"),
          placeholder: "Neurogram://"
        },
        layout: $layout.fill
      }, {
        type: "switch",
        props: {
          id: "urlSwitch",
          on: false,
          onColor: $color("#4BD663"),
          bgcolor: $color("white"),
          hidden: true
        },
        layout: function (make, view) {
          make.right.inset(10)
          make.centerY.equalTo(view.super.centerY)
        },
        events: {
          changed: function (sender) {
            urlorQR($("urlSwitch").on)
          }
        }
      }],
      layout: $layout.fill
    }]
  }, {
    title: $l10n("SHADOWCOLOR"),
    rows: [{
      type: "matrix",
      props: {
        id: "shadowColorPick",
        columns: 5,
        itemHeight: 34,
        spacing: 5,
        data: [],
        template: {
          props: {},
          views: [
            {
              type: "view",
              props: {
                id: "shadowColor",
                smoothRadius: 10
              },
              layout: $layout.fill
            }
          ]
        }
      },
      layout: $layout.fill,
      events: {
        didSelect: function (sender, indexPath, data) {
          logoShadowColor = data.shadowColor.info.bgcolor
          $("newLogoShadow").alpha = 1
          $("newLogoShadow").updateLayout(function (make, view) {
            make.centerX.equalTo(view.super.centerX)
            make.top.inset(40)
            make.size.equalTo($size(45, 55))
            shadow($("newLogoShadow"), $color(data.shadowColor.info.bgcolor))
          })
        }
      }
    }]
  }
]

var bookmarkListItems = {
  title: $l10n("BROWSER"),
  rows: [{
    type: "view",
    props: {

    },
    views: [{
      type: "label",
      props: {
        id: "SafariLabel",
        text: $l10n("OPENINSAFARI"),
        align: $align.left
      },
      layout: $layout.fill
    }, {
      type: "switch",
      props: {
        id: "SafariSwitch",
        on: true,
        onColor: $color("#4BD663")
      },
      layout: function (make, view) {
        make.right.inset(10)
        make.centerY.equalTo(view.super.centerY)
      }
    }],
    layout: $layout.fill
  }]
}

var qrCodeListItems = {
  title: $l10n("QRCODE"),
  rows: [{
    type: "view",
    props: {

    },
    views: [{
      type: "view",
      props: {
        id: "newQRCodeView",
        alpha: 0.4,
        bgcolor: $color("gray")
      },
      views: [{
        type: "button",
        props: {
          id: "qrImgBt",
          icon: $icon("104", $color("white"), $size(55, 55)),
          bgcolor: $color("clear")
        },
        layout: $layout.fill,
        events: {
          tapped: function (sender) {
            addLogoQR("qrCode")
          }
        }

      }],
      layout: function (make, view) {
        make.center.equalTo(view.super.center)
        make.size.equalTo($size(150, 150))
        shadow(view, $color("gray"))
      }
    }, {
      type: "image",
      props: {
        id: "newQRCodeImg",
        bgcolor: $color("clear"),
        smoothRadius: 10
      },
      layout: function (make, view) {
        make.center.equalTo(view.super.center)
        make.size.equalTo($size(150, 150))
      }
    }, {
      type: "view",
      props: {
        id: "urlorQR",
        bgcolor: $color("clear"),
        hidden: true
      },
      layout: $layout.fill
    }],
    layout: $layout.fill
  }]
}

function listDataView(type) {
  if (type == 0) {
    var listData = launcherListItems.concat(bookmarkListItems)
    var thirdRowHeight = 44
  } else if (type == 1) {
    var listData = launcherListItems
    var thirdRowHeight = 44
  } else {
    var listData = launcherListItems.concat(qrCodeListItems)
    var thirdRowHeight = 180
  }

  return {
    type: "list",
    props: {
      id: "listTypeView",
      bgcolor: $color("clear"),
      data: listData,
      radius: 10
    },
    layout: function (make, view) {
      make.top.inset(155)
      make.bottom.left.right.inset(0)
    },
    events: {
      rowHeight: function (sender, indexPath) {
        if (indexPath.section == 3) {
          return thirdRowHeight
        } else if (indexPath.section == 2) {
          return 88.0
        } else {
          return 44.0
        }
      }
    }
  }
}

var settingsView = {
  type: "list",
  props: {
    id: "settingsView",
    radius: 10,
    reorder: true,
    crossSections: false,
    footer: {
      type: "label",
      props: {
        height: 20,
        text: "NLauncher by Neurogram",
        textColor: $color("#AAAAAA"),
        align: $align.center,
        font: $font(12)
      }
    },
    actions: [
      {
        title: "delete",
        color: $color("red"), // default to gray
        handler: function (sender, indexPath) {
          if (indexPath.section == 0) {
            bookmarkDataDel.push(bookmarkData[indexPath.row])
            bookmarkData.splice(indexPath.row, 1)
          } else if (indexPath.section == 1) {
            launcherDataDel.push(launcherData[indexPath.row])
            launcherData.splice(indexPath.row, 1)
          } else if (indexPath.section == 2) {
            qrCodeDataDel.push(qrCodeData[indexPath.row])
            qrCodeData.splice(indexPath.row, 1)
          } else { }
        }
      }
    ]
  },
  layout: function (make, view) {
    make.edges.insets($insets(40, 0, 0, 0))
  },
  events: {
    didSelect: function (sender, indexPath, data) {
      if (indexPath.section == 7) {
        buyMeaCoffee.coffee()
      } else if (indexPath.section == 3) {
        $pick.data({
          props: {
            items: [[$l10n("BOOKMARK"), $l10n("LAUNCHER"), $l10n("QRCODE")]]
          },
          handler: function (data) {
            $("settingsView").delete($indexPath(3, 0))
            var cell = $("settingsView").insert({
              indexPath: $indexPath(3, 0),
              value: data[0]
            })
          }
        })
      } else if (indexPath.section == 4) {
        $pick.data({
          props: {
            items: [[$l10n("BIG"), $l10n("MEDIUM"), $l10n("SMALL")]]
          },
          handler: function (data) {
            $("settingsView").delete($indexPath(4, 0))
            var cell = $("settingsView").insert({
              indexPath: $indexPath(4, 0),
              value: data[0]
            })
          }
        })
      } else if (indexPath.section == 5) {
        $pick.data({
          props: {
            items: [[$l10n("VISIBLE"), $l10n("HIDDEN")]]
          },
          handler: function (data) {
            $("settingsView").delete($indexPath(5, 0))
            var cell = $("settingsView").insert({
              indexPath: $indexPath(5, 0),
              value: data[0]
            })
          }
        })
      } else if (indexPath.section == 6) {
        $pick.data({
          props: {
            items: [[$l10n("VISIBLE"), $l10n("HIDDEN")]]
          },
          handler: function (data) {
            $("settingsView").delete($indexPath(6, 0))
            var cell = $("settingsView").insert({
              indexPath: $indexPath(6, 0),
              value: data[0]
            })
          }
        })
      }
    },
    reorderMoved: function (from, to) {
      if (from.section == 0) {
        bookmarkData = orderItem(bookmarkData, from.row, to.row)
      } else if (from.section == 1) {
        launcherData = orderItem(launcherData, from.row, to.row)
      } else if (from.section == 2) {
        qrCodeData = orderItem(qrCodeData, from.row, to.row)
      } else { }
    }
  }
}

var cancelnDoneBt = {
  type: "view",
  props: {
    id: "cancelnDoneView",
    bgcolor: $color("clear"),
    radius: 10
  },
  views: [{
    type: "button",
    props: {
      title: "×",
      titleColor: $color("#AAAAAA"),
      bgcolor: $color("clear"),
      font: $font(40)
    },
    layout: function (make, view) {
      make.top.left.inset(0)
      make.size.equalTo($size(40, 40))
    },
    events: {
      tapped: function (sender) {
        removeView()
      }
    }
  }, {
    type: "button",
    props: {
      title: "▷",
      titleColor: $color("#AAAAAA"),
      bgcolor: $color("clear"),
      font: $font(20)
    },
    layout: function (make, view) {
      make.top.right.inset(0)
      make.size.equalTo($size(40, 40))
    },
    events: {
      tapped: function () {
        saveData()
      }
    }
  }],
  layout: function (make, view) {
    make.top.right.left.inset(0)
    make.height.equalTo(40)
  }
}

function addnewitem() {
  $ui.animate({
    duration: 0.5,
    animation: function () {
      $("addItemsView").alpha = 1
    }
  })
  if (viewType == 0) {
    $("addItemsView").add(newLogoItems)
    $("addItemsView").add(listDataView(type))
    $("addItemsView").add(cancelnDoneBt)
    $("tab").index = type
    if (type == 2) {
      $("newUrl").hidden = true
      $("urlSwitch").hidden = false
    }
  } else {
    $("addItemsView").add(cancelnDoneBt)
    $("addItemsView").add(settingsView)
    $("settingsView").data = settingsListData()
  }
}

function listType(type) {
  $("listTypeView").remove()
  $("addItemsView").add(listDataView(type))
  if (type != 2) {
    $("urlSwitch").hidden = true
  } else {
    $("urlSwitch").hidden = false
    $("newUrl").hidden = true
  }
}

function urlorQR(on) {
  $ui.animate({
    duration: 0.3,
    animation: function () {
      if (on == 1) {
        $("qrImgBt").rotate(150)
        $("newUrl").hidden = false
        $("urlorQR").hidden = false
      } else {
        $("qrImgBt").rotate(0)
        $("newUrl").hidden = true
        $("urlorQR").hidden = true
      }
    }
  })
}

function removeView() {
  $ui.animate({
    duration: 0.5,
    animation: function () {
      $("addItemsView").alpha = 0
    }
  })
  $("cancelnDoneView").remove()
  if (viewType == 0) {
    $("newLogoItemsView").remove()
    $("listTypeView").remove()
  } else {
    launcherDataDel = []
    bookmarkDataDel = []
    qrCodeDataDel = []
    launcherData = JSON.parse($file.read("assets/launcherData.json").string)
    bookmarkData = JSON.parse($file.read("assets/bookmarkData.json").string)
    qrCodeData = JSON.parse($file.read("assets/qrCodeData.json").string)
    $("settingsView").remove()
  }
}

function saveData() {
  if (viewType == 0) {
    var data = {
      "title": $("newTitle").text,
      "shadow": logoShadowColor
    }
    if (type == 0) {
      data.url = $("newUrl").text
      data.logo = "assets/bookmark/" + $("newTitle").text + ".jpg"
      if ($("SafariSwitch").on == 1) {
        data.safari = true
      } else {
        data.safari = false
      }
      bookmarkData.push(data)
      dataWrite(bookmarkData, "bookmarkData")
      $file.write({
        data: newLogoImg,
        path: "assets/bookmark/" + $("newTitle").text + ".jpg"
      })
    } else if (type == 1) {
      data.url = $("newUrl").text
      data.logo = "assets/launcher/" + $("newTitle").text + ".jpg"
      launcherData.push(data)
      dataWrite(launcherData, "launcherData")
      $file.write({
        data: newLogoImg,
        path: "assets/launcher/" + $("newTitle").text + ".jpg"
      })
    } else {
      data.logo = "assets/qrCode/" + $("newTitle").text + ".jpg"
      if ($("urlSwitch").on == 1) {
        data.url = $("newUrl").text
      } else {
        data.qrImg = "assets/qrCode/" + $("newTitle").text + "-qr.jpg"
        $file.write({
          data: newQRImg,
          path: "assets/qrCode/" + $("newTitle").text + "-qr.jpg"
        })
      }
      qrCodeData.push(data)
      dataWrite(qrCodeData, "qrCodeData")
      $file.write({
        data: newLogoImg,
        path: "assets/qrCode/" + $("newTitle").text + ".jpg"
      })
    }
    rerun()
  } else if (viewType == 1) {
    dataWriteandDel()
    if("Bookmark" == $l10n("BOOKMARK")){
      var home = {
        "Bookmark": 0,
        "Launcher": 1,
        "QR Code": 2,
      }
  
      var iconSize = {
        "Big": 4,
        "Medium": 5,
        "Small": 6
      }
  
      var titleDisplay = {
        "Visible": false,
        "Hidden": true
      }
  
      var shadowDisplay = {
        "Visible": false,
        "Hidden": true
      }
    }else{
      var home = {
        "书签": 0,
        "启动器": 1,
        "二维码": 2,
      }
  
      var iconSize = {
        "大": 4,
        "中": 5,
        "小": 6
      }
  
      var titleDisplay = {
        "显示": false,
        "隐藏": true
      }
  
      var shadowDisplay = {
        "显示": false,
        "隐藏": true
      }
    }
    
    $cache.set("type", {
      "type": home[$("settingsView").object($indexPath(3, 0))],
      "iconSize": iconSize[$("settingsView").object($indexPath(4, 0))],
      "titleDisplay": titleDisplay[$("settingsView").object($indexPath(5, 0))],
      "shadowDisplay": shadowDisplay[$("settingsView").object($indexPath(6, 0))]
    })
    rerun()
  } else { }
}

function rerun() {
  let name = $text.URLEncode($addin.current.name.split(".js"))
  $app.openURL("jsbox://run?name=" + name)
}

function dataWriteandDel() {
  dataWrite(launcherData, "launcherData")
  dataWrite(bookmarkData, "bookmarkData")
  dataWrite(qrCodeData, "qrCodeData")
  deleteImg(launcherDataDel)
  deleteImg(bookmarkDataDel)
  deleteImg(qrCodeDataDel)
}

function dataWrite(file, path) {
  $file.write({
    data: $data({ string: JSON.stringify(file) }),
    path: "assets/" + path + ".json"
  })
}

function deleteImg(dataDel) {
  for (var i in dataDel) {
    $file.delete(dataDel[i].logo)
    if (dataDel[i].qrImg) {
      $file.delete(dataDel[i].qrImg)
    }
  }
}

function martixData() {
  if (type == 0) {
    var dataType = bookmarkData
  } else if (type == 1) {
    var dataType = launcherData
  } else {
    var dataType = qrCodeData
  }
  var data = []
  for (var i in dataType) {
    data.push({
      shadowView: {
        bgcolor: $color(dataType[i].shadow)
      },
      logoImg: {
        src: dataType[i].logo
      },
      logoName: {
        text: dataType[i].title
      }
    })
  }
  return data
}

function settingsListData() {
  if ($cache.get("type")) {
    var home = [$l10n("BOOKMARK"), $l10n("LAUNCHER"), $l10n("QRCODE")]
    home = home[$cache.get("type").type]
    var iconSize = ["", "", "", "", $l10n("BIG"), $l10n("MEDIUM"), $l10n("SMALL")]
    iconSize = iconSize[$cache.get("type").iconSize]
    if ($cache.get("type").titleDisplay == true) {
      var titleSwitch = $l10n("HIDDEN")
    } else {
      var titleSwitch = $l10n("VISIBLE")
    }
    if ($cache.get("type").shadowDisplay == true) {
      var shadowSwitch = $l10n("HIDDEN")
    } else {
      var shadowSwitch = $l10n("VISIBLE")
    }
  } else {
    var home = $l10n("LAUNCHER")
    var iconSize = $l10n("BIG")
    var titleSwitch = $l10n("VISIBLE")
    var shadowSwitch = $l10n("VISIBLE")
  }
  return [
    {
      title: $l10n("BOOKMARK"),
      rows: settingsRowData("bookmark")
    },
    {
      title: $l10n("LAUNCHER"),
      rows: settingsRowData("launcher")
    },
    {
      title: $l10n("QRCODE"),
      rows: settingsRowData("qrCode")
    },
    {
      title: $l10n("HOME"),
      rows: [home]
    },
    {
      title: $l10n("ICONSIZE"),
      rows: [iconSize]
    },
    {
      title: $l10n("TITLE"),
      rows: [titleSwitch]
    },
    {
      title: $l10n("SHADOW"),
      rows: [shadowSwitch]
    },
    {
      title: $l10n("COFFEE"),
      rows: [$l10n("BUYMEACOFFEE")]
    }
  ]
}

function settingsRowData(rowsType) {
  if (rowsType == "bookmark") {
    var dataType = bookmarkData
  } else if (rowsType == "launcher") {
    var dataType = launcherData
  } else {
    var dataType = qrCodeData
  }
  var data = []
  for (var i in dataType) {
    data.push(dataType[i].title)
  }
  return data
}


function blqSwitch(cal) {
  if (cal == 1) {
    type = type + 1
  } else {
    type = type - 1
  }
  if (type == -1) {
    type = 2
  } else if (type == 3) {
    type = 0
  }
  count = 0
  data = martixData()
  $("NLauncher").data = data
}

function open(row) {
  if (type == 0) {
    if (bookmarkData[row].safari == true) {
      $app.openURL(bookmarkData[row].url)
    } else {
      $safari.open({
        url: bookmarkData[row].url,
      })
    }
  } else if (type == 1) {
    $app.openURL(launcherData[row].url)
  } else {
    if (qrCodeData[row].url) {
      $app.openURL(qrCodeData[row].url)
    } else {
      $("showQRView").hidden = false
      $ui.animate({
        duration: 0.3,
        animation: function () {
          $("blur").alpha = 1
          $("showQRImg").scale(1.3)
          $("showQRImg").src = qrCodeData[row].qrImg
        }
      })
    }
  }
}

function orderItem(data, from, to) {
  var object = data[from]
  data.splice(from, 1)
  data.splice(to, 0, object)
  return data
}

function addLogoQR(imgType) {
  $photo.prompt({
    handler: function (resp) {
      var image = resp.image
      if (imgType == "logo") {
        newLogoImg = image.jpg(1.0)
        $("newLogo").src = "data:image/png;base64," + $text.base64Encode(newLogoImg)
        let mime = newLogoImg.info.mimeType
        let q = 1
        if (newLogoImg.info.size > 4E6) q = 4
        if (newLogoImg.info.size > 8E6) q = 8
        getPalette($text.base64Encode(newLogoImg), mime, 9, q)

      } else {
        newQRImg = image.jpg(1.0)
        $("newQRCodeImg").src = "data:image/png;base64," + $text.base64Encode(newQRImg)
      }
    }
  })
}

function init() {
  let webView = {
    type: 'web',
    props: {
      id: 'web',
      html: `
      <style>*{margin:0;padding:0;}</style>
      <img id="img">
      <script>
          var CanvasImage = function (a) { this.canvas = document.createElement("canvas"), this.context = this.canvas.getContext("2d"), document.body.appendChild(this.canvas), this.width = this.canvas.width = a.width, this.height = this.canvas.height = a.height, this.context.drawImage(a, 0, 0, this.width, this.height) }; CanvasImage.prototype.clear = function () { this.context.clearRect(0, 0, this.width, this.height) }, CanvasImage.prototype.update = function (a) { this.context.putImageData(a, 0, 0) }, CanvasImage.prototype.getPixelCount = function () { return this.width * this.height }, CanvasImage.prototype.getImageData = function () { return this.context.getImageData(0, 0, this.width, this.height) }, CanvasImage.prototype.removeCanvas = function () { this.canvas.parentNode.removeChild(this.canvas) }; var ColorThief = function () { };
          if (ColorThief.prototype.getColor = function (a, b) { var c = this.getPalette(a, 5, b), d = c[0]; return d }, ColorThief.prototype.getPalette = function (a, b, c) { "undefined" == typeof b && (b = 10), ("undefined" == typeof c || c < 1) && (c = 10); for (var d, e, f, g, h, i = new CanvasImage(a), j = i.getImageData(), k = j.data, l = i.getPixelCount(), m = [], n = 0; n < l; n += c)d = 4 * n, e = k[d + 0], f = k[d + 1], g = k[d + 2], h = k[d + 3], h >= 125 && (e > 250 && f > 250 && g > 250 || m.push([e, f, g])); var o = MMCQ.quantize(m, b), p = o ? o.palette() : null; return i.removeCanvas(), p }, !pv) var pv = { map: function (a, b) { var c = {}; return b ? a.map(function (a, d) { return c.index = d, b.call(c, a) }) : a.slice() }, naturalOrder: function (a, b) { return a < b ? -1 : a > b ? 1 : 0 }, sum: function (a, b) { var c = {}; return a.reduce(b ? function (a, d, e) { return c.index = e, a + b.call(c, d) } : function (a, b) { return a + b }, 0) }, max: function (a, b) { return Math.max.apply(null, b ? pv.map(a, b) : a) } }; var MMCQ = function () { function a(a, b, c) { return (a << 2 * i) + (b << i) + c } function b(a) { function b() { c.sort(a), d = !0 } var c = [], d = !1; return { push: function (a) { c.push(a), d = !1 }, peek: function (a) { return d || b(), void 0 === a && (a = c.length - 1), c[a] }, pop: function () { return d || b(), c.pop() }, size: function () { return c.length }, map: function (a) { return c.map(a) }, debug: function () { return d || b(), c } } } function c(a, b, c, d, e, f, g) { var h = this; h.r1 = a, h.r2 = b, h.g1 = c, h.g2 = d, h.b1 = e, h.b2 = f, h.histo = g } function d() { this.vboxes = new b(function (a, b) { return pv.naturalOrder(a.vbox.count() * a.vbox.volume(), b.vbox.count() * b.vbox.volume()) }) } function e(b) { var c, d, e, f, g = 1 << 3 * i, h = new Array(g); return b.forEach(function (b) { d = b[0] >> j, e = b[1] >> j, f = b[2] >> j, c = a(d, e, f), h[c] = (h[c] || 0) + 1 }), h } function f(a, b) { var d, e, f, g = 1e6, h = 0, i = 1e6, k = 0, l = 1e6, m = 0; return a.forEach(function (a) { d = a[0] >> j, e = a[1] >> j, f = a[2] >> j, d < g ? g = d : d > h && (h = d), e < i ? i = e : e > k && (k = e), f < l ? l = f : f > m && (m = f) }), new c(g, h, i, k, l, m, b) } function g(b, c) { function d(a) { var b, d, e, f, g, h = a + "1", j = a + "2", k = 0; for (i = c[h]; i <= c[j]; i++)if (o[i] > n / 2) { for (e = c.copy(), f = c.copy(), b = i - c[h], d = c[j] - i, g = b <= d ? Math.min(c[j] - 1, ~~(i + d / 2)) : Math.max(c[h], ~~(i - 1 - b / 2)); !o[g];)g++; for (k = p[g]; !k && o[g - 1];)k = p[--g]; return e[j] = g, f[h] = e[j] + 1, [e, f] } } if (c.count()) { var e = c.r2 - c.r1 + 1, f = c.g2 - c.g1 + 1, g = c.b2 - c.b1 + 1, h = pv.max([e, f, g]); if (1 == c.count()) return [c.copy()]; var i, j, k, l, m, n = 0, o = [], p = []; if (h == e) for (i = c.r1; i <= c.r2; i++) { for (l = 0, j = c.g1; j <= c.g2; j++)for (k = c.b1; k <= c.b2; k++)m = a(i, j, k), l += b[m] || 0; n += l, o[i] = n } else if (h == f) for (i = c.g1; i <= c.g2; i++) { for (l = 0, j = c.r1; j <= c.r2; j++)for (k = c.b1; k <= c.b2; k++)m = a(j, i, k), l += b[m] || 0; n += l, o[i] = n } else for (i = c.b1; i <= c.b2; i++) { for (l = 0, j = c.r1; j <= c.r2; j++)for (k = c.g1; k <= c.g2; k++)m = a(j, k, i), l += b[m] || 0; n += l, o[i] = n } return o.forEach(function (a, b) { p[b] = n - a }), d(h == e ? "r" : h == f ? "g" : "b") } } function h(a, c) { function h(a, b) { for (var c, d = 1, e = 0; e < k;)if (c = a.pop(), c.count()) { var f = g(i, c), h = f[0], j = f[1]; if (!h) return; if (a.push(h), j && (a.push(j), d++), d >= b) return; if (e++ > k) return } else a.push(c), e++ } if (!a.length || c < 2 || c > 256) return !1; var i = e(a), j = 0; i.forEach(function () { j++ }); var m = f(a, i), n = new b(function (a, b) { return pv.naturalOrder(a.count(), b.count()) }); n.push(m), h(n, l * c); for (var o = new b(function (a, b) { return pv.naturalOrder(a.count() * a.volume(), b.count() * b.volume()) }); n.size();)o.push(n.pop()); h(o, c - o.size()); for (var p = new d; o.size();)p.push(o.pop()); return p } var i = 5, j = 8 - i, k = 1e3, l = .75; return c.prototype = { volume: function (a) { var b = this; return b._volume && !a || (b._volume = (b.r2 - b.r1 + 1) * (b.g2 - b.g1 + 1) * (b.b2 - b.b1 + 1)), b._volume }, count: function (b) { var c = this, d = c.histo; if (!c._count_set || b) { var e, f, g, h = 0; for (e = c.r1; e <= c.r2; e++)for (f = c.g1; f <= c.g2; f++)for (g = c.b1; g <= c.b2; g++)index = a(e, f, g), h += d[index] || 0; c._count = h, c._count_set = !0 } return c._count }, copy: function () { var a = this; return new c(a.r1, a.r2, a.g1, a.g2, a.b1, a.b2, a.histo) }, avg: function (b) { var c = this, d = c.histo; if (!c._avg || b) { var e, f, g, h, j, k = 0, l = 1 << 8 - i, m = 0, n = 0, o = 0; for (f = c.r1; f <= c.r2; f++)for (g = c.g1; g <= c.g2; g++)for (h = c.b1; h <= c.b2; h++)j = a(f, g, h), e = d[j] || 0, k += e, m += e * (f + .5) * l, n += e * (g + .5) * l, o += e * (h + .5) * l; k ? c._avg = [~~(m / k), ~~(n / k), ~~(o / k)] : c._avg = [~~(l * (c.r1 + c.r2 + 1) / 2), ~~(l * (c.g1 + c.g2 + 1) / 2), ~~(l * (c.b1 + c.b2 + 1) / 2)] } return c._avg }, contains: function (a) { var b = this, c = a[0] >> j; return gval = a[1] >> j, bval = a[2] >> j, c >= b.r1 && c <= b.r2 && gval >= b.g1 && gval <= b.g2 && bval >= b.b1 && bval <= b.b2 } }, d.prototype = { push: function (a) { this.vboxes.push({ vbox: a, color: a.avg() }) }, palette: function () { return this.vboxes.map(function (a) { return a.color }) }, size: function () { return this.vboxes.size() }, map: function (a) { for (var b = this.vboxes, c = 0; c < b.size(); c++)if (b.peek(c).vbox.contains(a)) return b.peek(c).color; return this.nearest(a) }, nearest: function (a) { for (var b, c, d, e = this.vboxes, f = 0; f < e.size(); f++)c = Math.sqrt(Math.pow(a[0] - e.peek(f).color[0], 2) + Math.pow(a[1] - e.peek(f).color[1], 2) + Math.pow(a[2] - e.peek(f).color[2], 2)), (c < b || void 0 === b) && (b = c, d = e.peek(f).color); return d }, forcebw: function () { var a = this.vboxes; a.sort(function (a, b) { return pv.naturalOrder(pv.sum(a.color), pv.sum(b.color)) }); var b = a[0].color; b[0] < 5 && b[1] < 5 && b[2] < 5 && (a[0].color = [0, 0, 0]); var c = a.length - 1, d = a[c].color; d[0] > 251 && d[1] > 251 && d[2] > 251 && (a[c].color = [255, 255, 255]) } }, { quantize: h } }();
          const img = document.getElementById('img')
          const colorThief = new ColorThief()
          function main(base64, num = 9, quality = 1) {
              img.onload = function () {
                  setTimeout(() => {
                    let palette = colorThief.getPalette(img, num, quality)
                    $notify("rec", { palette })
                  }, 0)
              }
              img.src = base64
          }
      </script>`,
      frame: $rect(10000, 10000, 1024, 768),
      userInteractionEnabled: 0
    },
    events: {
      rec: function (object) {
        $("shadowColorPick").data = object.palette.map(color => {
          var colors = color
          return {
            shadowColor: {
              bgcolor: $rgb(...color),
              info: { bgcolor: "#" + ((1 << 24) + (colors[0] << 16) + (colors[1] << 8) + colors[2]).toString(16).slice(1).toUpperCase() }
            }
          }
        })
      }
    }
  }
  $ui.window.add(webView)
}

function getPalette(base64, mime, num = 9, q = 1) {
  $('web').eval({
    script: `main('data:${mime};base64,${base64}', ${num}, ${q})`,
    handler: function (r, e) {
      if (r || e) reset()
    }
  })
}

function reset() {
  $('web').remove()
  init()
}
init()