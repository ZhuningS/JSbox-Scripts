# AnyKey

- Custom keyboard examples for development
- Also a highly customizable keyboard

# Tips

- Go settings and set as "Keyboard Script"
- In keyboard, select text, and tap to run plugin
- In main app, tap to run or edit
- Drag & Drop to reorder items

# Resources

- [JSBox keyboard APIs](https://docs.xteko.com/#/keyboard/method)
- [Demo keyboard](https://github.com/cyanzhong/xTeko/tree/master/extension-demos/keyboard)
- [Emoji Keys](https://github.com/cyanzhong/xTeko/tree/master/extension-demos/emoji-key)