exports.clear = $color("clear");
exports.black = $color("black");