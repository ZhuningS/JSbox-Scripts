let helper = require("scripts/helper");
let text = helper.getText();
let result = text.toUpperCase();
helper.setText(result);