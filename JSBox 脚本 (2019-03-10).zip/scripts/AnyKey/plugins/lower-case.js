let helper = require("scripts/helper");
let text = helper.getText();
let result = text.toLowerCase();
helper.setText(result);