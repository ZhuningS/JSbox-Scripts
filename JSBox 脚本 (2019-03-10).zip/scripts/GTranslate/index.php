<?php
header("HTTP/1.1 302 Found");
header("Location: https://xteko.com/redir?name=GTranslate&url=http%3A%2F%2Fjs.able.cat%2FGTranslate%2F.output%2FGTranslate.box&icon=icon_179.png&types=15&version=1.0&author=AbleCats&website=http%3A%2F%2Fjs.able.cat%2FGTranslate%2F");
exit();
?>'