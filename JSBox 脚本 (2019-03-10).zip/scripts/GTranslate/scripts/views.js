var alert = true;

const updata = require('scripts/updata');
const keyboard = require('scripts/keyboard');

const isX = $device.isIphoneX;
const today = $app.env !== $env.app ? true : false;
const offset = today ? 0 : $device.isIphoneX ? 40 : 20;


const oneLayout = (make, view) => {
  let vs = view.super;
  make.top.inset(offset);
  make.left.right.inset(0);
  make.height.equalTo(vs.height).dividedBy(2).offset(-offset / 2);
}
const twoLayout = (make, view) => {
  make.left.right.bottom.inset(0);
  make.top.equalTo(view.prev.bottom);
}
const copyLayout = (make, view) => {
  make.bottom.inset(5)
  make.right.inset(today ? 5 : isX ? 20 : 5)
}


const topView = {
  type: "view",
  props: {
    id: "topView"
  },
  layout: oneLayout,
  views: [{
    type: "text",
    props: {
      id: "topText",
      bgcolor: $color("white"),
      insets: $insets(14, 10, 12, 10),
      textColor: $color("lightGray"),
    },
    layout: $layout.fill
  }, {
    type: "button",
    props: {
      alpha: .7,
      bgcolor: $color("clear"),
      icon: $icon("021", $color("lightGray"), $size(20, 20))
    },
    layout: copyLayout,
    events: {
      tapped(sender) {
        $device.taptic(1);
        $("topText").text = $app.env !== $env.keyboard ? "" : $clipboard.text = "";
      }
    }
  }]
}
const blurView = {
  type: "blur",
  props: {
    alpha: 0,
    style: 1, // 0 ~ 5
    userInteractionEnabled: 0
  },
  layout: $layout.fill
}
const bottomView = {
  type: "view",
  props: {
    id: "bottomView"
  },
  layout: twoLayout,
  views: [{
    type: "text",
    props: {
      id: "bottomText",
      editable: false,
      bgcolor: $color("#4484f4"),
      textColor: $color("white"),
      insets: $insets(14, 10, 12, 10)
    },
    layout: $layout.fill
  }, {
    type: "button",
    props: {
      alpha: .7,
      bgcolor: $color("clear"),
      icon: $icon("019", $color("lightGray"), $size(20, 20))
    },
    layout: copyLayout,
    events: {
      tapped(sender) {
        $device.taptic(1);
        $app.env !== $env.keyboard ? $clipboard.text = $("bottomText").text : $keyboard.insert($("bottomText").text);
      }
    }
  }]
}
const buttonView = {
  type: "button",
  props: {
    circular: 1,
    id: "googleButton",
    bgcolor: $color("white"),
    src: "assets/google.png"
  },
  layout: (make, view) => {
    make.size.equalTo($size(30, 30));
    make.centerX.equalTo(view.super);
    make.centerY.equalTo(view.super).offset(today ? 0 : offset / 2);
  },
  events: {
    tapped: async (sender) => {
      await googleTrans($("topText").text.length ? $("topText").text : $clipboard.text);
    },
    longPressed: () => {
      $device.taptic(2);
      if ($app.env !== $env.keyboard) $app.close();
    },
    touchesBegan: (sender, location) => {
      $device.taptic(1);
    },
    touchesMoved: (sender, location) => {
      snapshot(location)
    }
  }
}


function init() {
  return async () => {
    $ui.render({
      props: {
        id: "mainView",
        statusBarStyle: 0,
        navBarHidden: true,
        bgcolor: $color("white")
      },
      views: [topView, bottomView, blurView, buttonView],
      events: {
        appeared: async () => {
          timer();
          updata.check();
          keyboard.hideBar("mainView");
        }
      }
    })
    $delay(0.1, async () => {
      $clipboard.text ? await googleTrans($clipboard.text) : 0;
    });
  }
}
function snapshot(l) {
  let flag = l.y >= 30 || l.y <= -30 ? true : false;
  switch (flag && alert) {
    case true:
      alert = false;
      $ui.alert({
        title: "是否分享该页面", actions: [{ title: "否", handler: () => { alert = true; } }, {
          title: "是", handler: () => {
            $delay(today ? 0 : 0.3, () => {
              $share.sheet([$("mainView").snapshot])
            });
            alert = true;
          }
        }]
      });
      break;
    case false:

      break;
  }
}
function whichLan(text) {
  let englishChar = text.match(/[a-zA-Z]/g);
  let englishNumber = !englishChar ? 0 : englishChar.length;
  let chineseChar = text.match(/[\u4e00-\u9fff\uf900-\ufaff]/g);
  let chineseNumber = !chineseChar ? 0 : chineseChar.length;

  return (chineseNumber * 2) >= englishNumber && chineseNumber ? "zh-CN" : englishNumber >= 8 ? "en" : "auto";
}
function animation(s, c, a) {
  $("googleButton").updateLayout(make => {
    make.size.equalTo($size(s, s));
  });
  $("googleButton").bgcolor = $color(c);
  $ui.animate({
    duration: 1, damping: 0.9, velocity: 0.6,
    animation: () => {
      $("blur").alpha = a;
      $("googleButton").relayout();
    }
  })
}

async function timer() {
  $timer.schedule({
    interval: 0.5,
    handler: async () => {
      if ($app.env == $env.keyboard) {
        let sW = $clipboard.text;
        $("topText").text == sW ? 0 : $("topText").text = sW;
      }
    }
  })
}
async function request(m, u, h, b, t, s) {
  let d = await $http.request({
    method: m,
    url: u,
    timeout: t,
    header: h,
    body: b,
    showsProgress: s,
  })
  return d.data
}
async function tryTrans(sl, tl, text) {
  let or = tr = "";
  let d = await request("POST", "http://translate.google.cn/translate_a/single", { "User-Agent": "iOSTranslate", "Content-Type": "application/x-www-form-urlencoded" }, { "dt": "t", "q": text, "tl": tl, "ie": "UTF-8", "sl": sl, "client": "ia", "dj": "1" }, 5, false);
  d.sentences.forEach(e => {
    $("topText").text = or = or.concat(e.orig)
    $("bottomText").text = tr = tr.concat(e.trans)
  });
}
async function googleTrans(text) {
  animation(64, "clear", 1);
  let sl = whichLan(text);
  let tl = sl == "zh-CN" ? "en" : "zh-CN";
  await tryTrans(sl, tl, text);
  $("topText").text == $("bottomText").text ? await tryTrans("auto", sl, text) : 0;
  animation(30, "white", 0);
}


module.exports = {
  init: init,
}