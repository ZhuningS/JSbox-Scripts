# GTranslate V1.5.2
### fixed：
>优化键盘模式下的便利操作

### tips:
>G 点击 长按 上下移动都有彩蛋～
>更新完毕后需自行重启方可对更新生效～

[GTranslate 安装](http://js.able.cat/GTranslate)