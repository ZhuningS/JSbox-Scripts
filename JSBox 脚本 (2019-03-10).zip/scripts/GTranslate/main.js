const views = require('scripts/views');


$app.listen({
  ready: views.init()
})

$app.keyboardToolbarEnabled = true;