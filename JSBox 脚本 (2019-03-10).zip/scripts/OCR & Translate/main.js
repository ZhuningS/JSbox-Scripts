
var ocrData = [
  [[$color("#fd354a"), $color("#da0a6f")],"General Text", "通用印刷","GT.png"],
  [[$color("#f97227"), $color("#f52156")],"Handwriting", "手写体","HW.png"],
  [[$color("#edb319"), $color("#e47b18")],"ID Card", "身份证","ID.png"],
  [[$color("#eecb01"), $color("#e8a400")],"Business Card", "名片","BC.png"],
  [[$color("#7ace1e"), $color("#5aba23")],"Bank Card", "银行卡","BKC.png"],
  [[$color("#25c578"), $color("#3ab523")],"Plate Number", "车牌","PN.png"],
  [[$color("#24d59a"), $color("#24bb9d")],"Driving License", "驾驶证","DL.png"],
  [[$color("#00c0c8"), $color("#00a0ca")],"Vehicle License", "行驶证","VL.png"],
  [[$color("#12b7de"), $color("#2193e6")],"Business License", "营业执照","BL.png"],
  [[$color("#2f74e0"), $color("#5d44e0")],"Invoice", "票据","Inv.png"],
  [[$color("#825af6"), $color("#6251f5")],"Passport", "护照","Pass.png"],
  [[$color("#cc3ec8"), $color("#9f0cdd")],"Settings", "设置","Set.png"]
]

function matrixData(){
  var data = []
  for(var i in ocrData){
    data.push({
      gradient: {
        colors: ocrData[i][0]
      },
      labelEn: {
        text: ocrData[i][1]
      },
      labelCn:{
        text: ocrData[i][2]
      },
      image:{
        src: "assets/" + ocrData[i][3]
      }
    })
  }
  return data
}


var mData = matrixData()

$ui.render({
    props: {
        title: "OCR & Translate"
    },
    views: [{
        type: "matrix",
        props: {        
          columns: 2,
          itemHeight: 88,
          spacing: 5,
          data: mData,
          template: {
            props: {},
            views: [
              {
                type: "gradient",
                props: {
                  locations: [0.0, 1.0],
                  startPoint: $point(0, 0),
                  endPoint: $point(1, 1),
                  radius: 10
                },
                layout: $layout.fill
              },{
                type: "label",
                props: {
                  id: "labelEn",
                  textColor: $color("white"),
                  align: $align.center,
                  font: $font(22),
                  
                },
                layout: function(make, view){
                  make.top.inset(5)
                  make.left.inset(7)
                }
              },{
                type: "label",
                props: {
                  id: "labelCn",
                  textColor: $color("white"),
                  align: $align.center,
                  font: $font(18),
                  autoFontSize: true
                },
                layout: function(make, view){
                  make.top.inset(35)
                  make.left.inset(7)
                }
              },{
                type: "image",
                props:{
                  bgcolor: $color("clear")
                },
                layout: function(make, view){
                  make.bottom.right.inset(5)
                  make.size.equalTo($size(40, 40))
                }
              }
            ]
          }
        },
        layout: $layout.fill,
        events:{
          didSelect: function(sender, indexPath, data) {
            var ocr = require('scripts/ocr')
            ocr.ocrType(data.labelEn.text)
          }
        }
      }]
})