function ocrServer() {
  return JSON.parse($file.read("assets/settings.json").string)
}

var ocrServers = ocrServer()
var image = ""
var img = ""

var loading = {
  type:"view",
  props:{
    id:"loadingView",
    bgcolor: $color("clear")
  },
  views:[{
    type: "blur",
    props:{
      style: 2,
      radius: 20
    },
    views:[{
      type: "spinner",
      props:{
        loading: true,
        style: 0
      },
      layout: function(make,view){
        make.top.inset(30)
        make.centerX.equalTo(view.super.centerX)
      }
    },{
        type:"label",
        props:{
          text: "Loading...",
          align: $align.center,
          textColor:$color("white"),
          font: $font(25)
        },
        layout: function(make, view){
          make.bottom.inset(35)
          make.centerX.equalTo(view.super.centerX)
        }
      }],
    layout: function(make, view){    
      make.height.equalTo(150)
      make.width.equalTo (150)
      make.center.equalTo(view.super)
    }
  }],
  layout: $layout.fill
}


function ocrType(type) {
  if (type !== "Settings") {
    $photo.prompt({
      handler: function(resp) {
        var origHeight = resp.image.size.height
        var origWidth = resp.image.size.width
        if (origHeight > 1000 || origWidth > 1000) {
          if (origHeight > origWidth) {
            var ratio = origHeight / 1000
            var height = 1000
            var width = origWidth / ratio
          } else {
            var ratio = origWidth / 1000
            var width = 1000
            var height = origHeight / ratio
          }
          image = resp.image.resized($size(width, height))
        } else {
          image = resp.image
        }
        var imageData = image.jpg(1.0)
        img = $text.base64Encode(imageData)
        ocr(type)
      }
    })
  } else {  
    var setting = require('scripts/settings')
    setting.settings()
  }
}

function ocr(type) {
  if (type == "General Text") {
    if (ocrServers[0] == 0) {
      baiduOcr("general", "commontext")
    } else if (ocrServers[0] == 1) {
      tencentOcr("generalocr")
    } else if (ocrServers[0] == 2) {
      sogouUpload()
    } else if (ocrServers[0] == 3) {
      youdaOcr()
    }
  } else if (type == "Handwriting") {
    tencentOcr("handwritingocr")
  } else if (type == "ID Card") {
    if (ocrServers[2] == 0) {
      baiduOcr("idcard", "idcard")
    } else {
      tencentOcr("idcardocr")
    }
  } else if (type == "Business Card") {
    tencentOcr("bcocr")
  } else if (type == "Bank Card") {
    if (ocrServers[4] == 0) {
      baiduOcr("bankcard", "bankcard")
    } else {
      tencentOcr("creditcardocr")
    }
  } else if (type == "Plate Number") {
    if (ocrServers[5] == 0) {
      baiduOcr("plate", "license_plate")
    } else {
      tencentOcr("plateocr")
    }
  } else if (type == "Driving License") {
    if (ocrServers[6] == 0) {
      baiduOcr("driving", "driving")
    } else {
      tencentOcr("driverlicenseocr", 1)
    }
  } else if (type == "Vehicle License") {
    if (ocrServers[7] == 0) {
      baiduOcr("vehicle", "vehicle")
    } else {
      tencentOcr("driverlicenseocr", 0)
    }
  } else if (type == "Business License") {
    if (ocrServers[8] == 0) {
      baiduOcr("business", "business_license")
    } else {
      tencentOcr("bizlicenseocr")
    }
  } else if (type == "Invoice") {
    $ui.menu({
      items: ["通用票据", "增值税发票"],
      handler: function(title, idx) {
        if (idx == 0) {
          baiduOcr("receipt", "receipt")
        } else {
          baiduOcr("receipt", "vat_invoice")
        }
      }
    })
  } else if (type == "Passport") {
    passportView()
  }

}

function setUpdate() {
  ocrServers = ocrServer()
}

module.exports = {
  ocrType: ocrType,
  setUpdate: setUpdate
}

function passportView() {
  $ui.push({
    props: {
      title: "hmmm......"
    },
    views: [{
      type: "image",
      props: {
        src: "assets/vincent.JPG"
      },
      layout: function(make, view) {
        make.size.equalTo($size(300, 300))
        make.center.equalTo(view.super)
      }
    }]
  })
}

function baiduOcr(linkType, type) {
  $ui.toast("Baidu OCR")
  $("matrix").super.add(loading)
  $http.post({
    url: "https://cloud.baidu.com/aidemo",
    header: {
      "Content-Type": "application/x-www-form-urlencoded",
      "Referer": "https://cloud.baidu.com/product/ocr/" + linkType
    },
    body: {
      "type": type,
      "image": "data:image/png;base64," + img,
      "image_url": ""
    },
    handler: function(resp) {
      $("loadingView").remove()
      var orig = ""
      if (type == "commontext") {
        var data = resp.data.data.words_result
        for (var i in data) {
          orig = orig + data[i].words + "\n"
        }
      } else {
        orig = baiduData(type, resp.data.data)
      }
      results(orig)
    }
  })
}

function baiduData(type, results) {
  if (type == "idcard" || type == "driving" || type == "vehicle" || type == "business_license" || type == "receipt") {
    return baiduDP(results.words_result, type)
  } else if (type == "bankcard") {
    var data = results.result
    if (data.bank_card_type == 1) {
      var cardType = "借记卡"
    } else {
      var cardType = "信用卡"
    }
    var text = "卡号：" + data.bank_card_number + "\n" + "发卡行：" + data.bank_name + "\n" + "卡片类型：" + cardType
    return text
  } else if (type == "license_plate") {
    var data = results.words_result
    var text = "车牌号：" + data.number + "\n" + "颜色：" + data.color
    return text
  } else if (type == "vat_invoice") {
    var data = results.words_result
    var text = "| 发票基本信息" + "\n" + "发票名称：" + data.InvoiceType + "\n" + "发票代码：" + data.InvoiceCode + "\n" + "发票号码：" + data.InvoiceNum + "\n" + "开票日期：" + data.InvoiceDate + "\n" + "密码区：" + data.Password + "\n" + "备注：" + data.Remarks + "\n" + "收款人：" + data.Payee + "\n" + "复核：" + data.Checker + "\n" + "开票人：" + data.NoteDrawer + "\n" + "\n" + "| 购买方" + "\n" + "名称：" + data.PurchaserName + "\n" + "纳税人识别号：" + data.PurchaserRegisterNum + "\n" + "地址、电话：" + data.PurchaserAddress + "\n" + "开户行及账号：" + data.PurchaserBank + "\n" + "\n" + "| 销售方" + "\n" + "名称：" + data.SellerName + "\n" + "纳税人识别号：" + data.SellerRegisterNum + "\n" + "地址、电话：" + data.SellerAddress + "\n" + "开户行及账号：" + data.SellerBank + "\n" + "\n" + "| 货物或应税劳务、服务" + "\n" + "名称：" + data.CommodityName[0].word + "\n" + "单位：" + data.CommodityUnit[0].word + "\n" + "数量：" + data.CommodityNum[0].word + "\n" + "\n" + "| 合计" + "\n" + "金额合计：" + data.TotalAmount + "\n" + "税额合计：" + data.TotalTax + "\n" + "价税合计：" + data.AmountInFiguers + "\n" + "商品税率：" + data.CommodityTaxRate[0].word
    return text
  }

}

function baiduDP(data, type) {
  var result = ""
  for (var i in data) {
    if (type == "receipt") {
      result += data[i].words + "\n"
    } else {
      result += i + "：" + data[i].words + "\n"
    }
  }
  return result
}

function tencentOcr(type, driverType) {
  $ui.toast("Tencent OCR")
  $("matrix").super.add(loading)
  $http.request({
    method: "POST",
    url: "https://open.youtu.qq.com/youtu/ocrapi/" + type,
    header: {
      "Authorization": "OIsSVPtzm2X2bL6z/IlYwvGKCAJhPTEwMDA5NjMzJms9QUtJRGpYQmR1ek9hNlF1SlpmNUpxQk5PSzdqOVBhZFhqbDhKJmU9MTUyNTkyNzQzMSZ0PTE1MjU4NDEwMzEmcj0zODEyNTc0ODEmdT0zMjU1MjA1ODcy",
    },
    body: {
      "image": img,
      "app_id": "100009633",
      "type" : driverType
    },
    handler: function(resp) {
      $("loadingView").remove()
      var orig = ""
      if (type == "generalocr"|| type == "handwritingocr") {
        var data = resp.data.items
        for (var i in data) {
          orig = orig + data[i].itemstring + "\n"
        }
      } else {
        orig = tencentData(type, resp.data)
      }
      results(orig)
    }
  })
}

function tencentData(type, results){
  if(type == "idcardocr"){
    var text = "姓名：" + results.name + "\n" + "性别：" + results.sex + "\n" + "民族：" + results.nation + "\n" + "出生：" + results.birth + "\n" + "住址：" + results.address + "\n" + "号码：" + results.id
    return text
  }else if(type == "bcocr"||type == "bizlicenseocr"||type == "creditcardocr" ||type == "plateocr"||type == "driverlicenseocr"){
    var text = ""
    for(var i in results.items){
      text = text + results.items[i].item +"："+ results.items[i].itemstring + "\n"
    }
    return text
  }
}

function sogouUpload() {
  $ui.toast("Sogou OCR")
  $("matrix").super.add(loading)
  $http.upload({
    url: "http://pic.sogou.com/pic/upload_pic.jsp",
    files: [{
      "image": image,
      "name": "pic_path",
      "filename": "test.jpeg",
    }],
    handler: function(resp) {
      $("loadingView").remove()
      var data = resp.data
      var imgUrl = $text.URLEncode(data)
      sogouOcr(imgUrl)
    }
  })
}

function sogouOcr(url) {
  $("matrix").super.add(loading)
  $http.get({
    url: "http://pic.sogou.com/pic/ocr/ocrOnline.jsp?query=" + url,
    handler: function(resp) {
      $("loadingView").remove()
      var data = resp.data.result
      var orig = ""
      for (i in data) {
        orig = orig + data[i].content
      }
      results(orig)
    }
  })
}

function youdaOcr() {
  $ui.toast("Youdao OCR")
  $("matrix").super.add(loading)
  $http.post({
    url: "http://fanyi.youdao.com/appapi/tranocr?language=unk&category=iphobe&imei=39bf9b1d15e30cd9729128706b5b3cd7&model=iPhone&mid=9.3.3&version=3.2.0&keyfrom=fanyi.3.2.0.iphone&vendor=AppStore",
    header: {
      "Content-Type": "text/plain"
    },
    body: img,
    handler: function(resp) {
      $("loadingView").remove()
      var data = resp.data.tranRegions
      var orig = ""
      for (var i in data) {
        orig = orig + data[i].context + "\n"
      }
      results(orig)
    }
  })
}

function results(orig) {
  var trans = require('scripts/translate')
  trans.translateView(orig, image)
}