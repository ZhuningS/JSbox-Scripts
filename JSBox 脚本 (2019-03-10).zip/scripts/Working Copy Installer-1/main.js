// require('socketLogger').init();

const ROOT = '../../../../../../../../../../';

const path = NSURL.$URLWithString($context.link).$path();
const name = path.$lastPathComponent().rawValue();

$file.copy({
    src: ROOT + path.rawValue(),
    dst: name
});

$file.mkdir(`${name}/assets`);
$file.mkdir(`${name}/scripts`);
$file.mkdir(`${name}/strings`);

const dest = `${name}.box`;
await $archiver.zip({ directory: name, dest });

await $addin.save({ name, data: $file.read(dest) });

$file.delete(name);
$file.delete(dest);

$context.close();

$app.openURL('jsbox://');