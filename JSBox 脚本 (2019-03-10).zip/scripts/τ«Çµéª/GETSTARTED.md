## 官网

- <http://ksria.com/simpread#jsbox>

## 配置指南

- 确保已 [安装 JSBox](https://itunes.apple.com/cn/app/jsbox-%E5%88%9B%E9%80%A0%E4%BD%A0%E8%87%AA%E5%B7%B1%E7%9A%84%E5%B7%A5%E5%85%B7/id1312014438?mt=8)；

- 打开简悦的设定选项卡；_点击简悦右侧的 ▶ 并选择 **设定**_

  ![](http://ojec5ddd5.bkt.clouddn.com/menu2@jsbox.png)

- 按照下图步骤进行配置；
  ![](http://ojec5ddd5.bkt.clouddn.com/setting2@jsbox.png)

  1. 粘贴 Dropbox token 到输入框；_获取 Dropbox token 请看本文最下方 **如何获取 Dropbox token**_
  2. 点击 **从 Dropbox 读取你的配置文件** ； _以便获取其它导出服务的token_
  3. 点击 **同步适配列表**； _以便获取最新的适配列表_
  4. 如果已安装「阅读器」的话，请点击 **共享适配列表给阅读器** ；_建议每次同步更新后都需要操作一次_

通过上述步骤即可设置完毕，更详细说明点击下方「红色 Button」