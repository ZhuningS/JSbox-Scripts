var file = require("scripts/fileUtil");
var action = require("scripts/actionUtil");
var ui = require("scripts/uiUtil");
var update = require("scripts/updateUtil");
var lco = require("scripts/lco");

function init(){
  $cache.set("pickedInOrder", []);
  minus();
}

async function main() {
  init();
  await lco.update();
  // await file.getOnline();

  const scriptName = $addin.current.name;
  const query = $context.query;

 

  if ($app.env === $env.action || $app.env === $env.safari) {
    //在拓展中打开
    shareSheetBoot();
  } else if (query.from === "album") {
    //通过url scheme打开此脚本,而且from的参数为album
    shareSheetHandle();
  } else if (query.from === "desktop") {
    $cache.set("like", true);
    generalBoot();
  } else if ($app.env === $env.app) {
    generalBoot();
  }

  function generalBoot() {
    ui.openning();

    update.getLatestVersion({
      handler: version => {
        console.log(`latest version: ${version}`);
        console.log(`current version: ${update.getCurVersion()}`);
        if (
          update.needUpdate(version, update.getCurVersion()) ||
          !$file.exists("config.json")
        ) {
          $ui.toast($l10n("发现新版本,正在下载..."));
          $http.get({
            url: "https://raw.githubusercontent.com/lcolok/Catcher/master/updateLog.md" +
              "?t=" +
              new Date().getTime(),
            handler: resp => {
              update.updateScript(version);
            }
          });
        } else {
          console.log($l10n("已经是最新版"));
          action.showMenu();
          // action.menu($("mainView")); //弹出菜单
        }
      }
    });
  }

  function shareSheetBoot() {
    let albumPic = $context.imageItems;
    // $cache.set("albumPic", albumPic);
    if (albumPic) {
      $ui.toast($l10n("成功载入,识别中..."));
      file.setTempPic(albumPic[0]);
      $delay(0.3, function () {
        $app.openURL(
          `jsbox://run?name=${encodeURIComponent(scriptName)}&from=album`
        );
        $context.close();
      });
    } else {
      $ui.toast($l10n("抱歉,由于载入需要时间,请重试"));
      $delay(2, function () {});
    }
  }

  function shareSheetHandle() {
    // let albumPic = $cache.get("albumPic")[0];
    let albumPic = file.getTempPic();

    ui.renderBoot();

    ui.loading($("mainView"));

    $delay(0.0, function () {
      action.ocr($("mainView"), albumPic);
    });
  }

 
}
function minus() {
  //减少一次免打扰运行次数
  let runCount = $cache.get("runCount");
  if (runCount !== undefined) {
    $cache.set("runCount", runCount - 1);
  } else {
    $cache.set("runCount", 3);
  }
}

main();