var lottie = require("scripts/lottieUtil");
var lco = require("scripts/lco");

function closeWin() {
    lco.sfx("Messenger_cancelRecord");
    $("text").blur();
    $("editerBoard").updateLayout((make, view) => {
        make.top.inset($ui.window.frame.height);
        make.left.right.bottom.inset(0);
    });
    $("topperView").updateLayout((make, view) => {
        make.top.inset(0);
        make.left.right.inset(0);
        make.bottom.inset(0);
        rightCorner(view);
    });
    $ui.animate({
        duration: 0.3,
        delay: 0,
        damping: 1,
        velocity: 0,
        options: 0,
        animation: function () {
            $("editerBoard").relayout();
            $("topperView").relayout();
        },
        completion: function () {
            $("editerBoard").remove();
        }
    });
    fade($("editerBlack"));

}

function fade(sender) {
    $ui.animate({
        duration: 0.3,
        animation: function () {
            sender.alpha = 0;
        },
        completion: function () {
            sender.remove();
        }
    });
}

function textRounded(view) {
    let layer = view.runtimeValue().invoke("layer");
    layer.invoke("setCornerRadius", 8);
}

function rounded(view) {
    let layer = view.runtimeValue().invoke("layer");
    layer.invoke("setCornerRadius", 12);
    // layer.invoke("setShadowRadius", 10);
    // layer.invoke("setShadowOpacity", 1);
    // layer.invoke("setShadowOffset", $size(0, 0));
    // layer.invoke(
    //     "setShadowColor",
    //     $color("black")
    //     .runtimeValue()
    //     .invoke("CGColor")
    // );
}

function rightCorner(view) {
    let layer = view.runtimeValue().invoke("layer");
    layer.invoke("setCornerRadius", 0);
}

function viewsAddShadows(view) {
    //在layout中使用即可 给Views添加阴影
    let layer = view.runtimeValue().invoke("layer");
    layer.invoke("setCornerRadius", 20);
    layer.invoke("setShadowRadius", 3);
    layer.invoke("setShadowOpacity", 0.6);
    layer.invoke("setShadowOffset", $size(0, 3));
    layer.invoke(
        "setShadowColor",
        $color("black")
        .runtimeValue()
        .invoke("CGColor")
    );
}

function toastShadows(view) {
    //在layout中使用即可 给Views添加阴影
    let layer = view.runtimeValue().invoke("layer");
    layer.invoke("setCornerRadius", 15);
    layer.invoke("setShadowRadius", 8);
    layer.invoke("setShadowOpacity", 0.35);
    layer.invoke("setShadowOffset", $size(0, 0));
    layer.invoke(
        "setShadowColor",
        $color("black")
        .runtimeValue()
        .invoke("CGColor")
    );
}

function thumbShadows(view) {
    //在layout中使用即可 给Views添加阴影
    let layer = view.runtimeValue().invoke("layer");
    layer.invoke("setCornerRadius", 10);
    layer.invoke("setShadowRadius", 2);
    layer.invoke("setShadowOpacity", 1);
    layer.invoke("setShadowOffset", $size(0, 0));
    layer.invoke(
        "setShadowColor",
        $color("black")
        .runtimeValue()
        .invoke("CGColor")
    );
}

function textsAddShadows(view) {
    //在layout中使用即可 给Views添加阴影
    let layer = view.runtimeValue().invoke("layer");
    layer.invoke("setShadowRadius", 1.2);
    layer.invoke("setShadowOpacity", 1);
    layer.invoke("setShadowOffset", $size(0, 1));
    layer.invoke(
        "setShadowColor",
        $color("black")
        .runtimeValue()
        .invoke("CGColor")
    );
}

function loading(sender) {
    const scanner = lottie.BTN({
        props: {
            // path:'assets/lottie/ModernPictogramsForLottie_Printer.json',
            id: "scanner",
            startFrame: 0,
            // scale: 1,
            alpha: 0
        },
        layout: (make, view) => {
            make.edges.equalTo(view.super);
            //   ui.viewsAddShadows(view);//性能杀手
        },
        lottieLayout: (make, view) => {
            make.center.equalTo(view.super);
            make.size.equalTo($size(350, 350));
        },
        lottieEvents: {},
        events: {
            tapped: (make, view) => {
                // action.menu($("mainView"));
            }
        }
    });

    sender.add(scanner);
    playLoading();
    $delay(0.0, function () {
        $ui.animate({
            duration: 0.4,
            animation: function () {
                $("scanner").alpha = 0.8; //透明度
            }
        });
    });
}

function playLoading() {
    try {
        $("scanner_lottie").speed = 2.0;
        
        $("scanner_lottie").play({
            fromFrame: 122, // Optional
            toFrame: 180,
            handler: finished => {

                lco.sfx("Sorted3_CTP_Definitely");

                $("scanner_lottie").play({
                    fromFrame: 181, // Optional
                    toFrame: 274,
                    handler: finished => {

                        $("scanner_lottie").loop = true;
                        $("scanner_lottie").play({
                            fromFrame: 275, // Optional
                            toFrame: 340,
                            handler: finished => {

                            }
                        });
                    }
                })

            }
        });
    } catch (e) {
        console.warn("playLoading:当前没有scanner控件");
    }
}

function stopLoading() {
    try {
        fade($("scanner"));
    } catch (e) {
        console.warn("stopLoading当前没有scanner控件");
    }
}

function textMaker(name, color, textSize) {
    textSize = textSize ? textSize : 10;
    name += "Text";
    color = color ? color : $color("white");
    return {
        type: "label",
        props: {
            id: name,
            text: $l10n(name.toUpperCase()),
            align: $align.center,
            alpha: 0,
            userInteractionEnabled: true,
            autoFontSize: true,
            //   shadowColor:$color('black'),
            textColor: color,
            font: $font("PingFangSC-Regular", textSize)
        },
        layout: function (make, view) {
            textsAddShadows(view);
            make.center.equalTo(view.super);
            make.size.equalTo($size(0, 0));
        }
    };
}

function circleMaker(name, color) {
    name += "Circle";
    color = color ? color : $color("black");
    return {
        type: "view",
        props: {
            id: name,
            bgcolor: color,
            alpha: 0.8,
            userInteractionEnabled: true
        },
        layout: (make, view) => {
            viewsAddShadows(view);
            let layer = $(name)
                .runtimeValue()
                .invoke("layer");
            layer.invoke("setCornerRadius", 0);
            make.center.equalTo(view.super);
            make.size.equalTo($size(0, 0));
        },
        views: []
    };
}

function btnMaker(json) {
    let id,
        path,
        events,
        layout,
        textColor,
        circleColor,
        lottieEvents,
        startFrame,
        scale,
        lottieLayout,
        alpha;
    id = json.id;
    path = json.path ? json.path : `assets/lottie/${id}.json`;
    scale = json.scale ? json.scale : 1;
    lottieLayout = json.lottieLayout ? json.lottieLayout : undefined;
    events = json.events;
    layout = json.layout;
    textColor = json.textColor;
    textSize = json.textSize;
    circleColor = json.circleColor;
    lottieEvents = json.lottieEvents;
    startFrame = json.startFrame;
    alpha = json.alpha ? json.alpha : 1;

    return {
        type: "view",
        props: {
            id: id + "BTN",
            alpha: alpha
        },
        layout: layout,
        views: [
            textMaker(id, textColor, textSize),
            circleMaker(id, circleColor),
            lottie.BTN({
                props: {
                    path: path,
                    id: id + "BTN_inside",
                    startFrame: startFrame,
                    scale: scale,
                    alpha: 0.9
                },
                layout: lottieLayout,
                lottieLayout: lottieLayout,
                events: events,
                lottieEvents: lottieEvents
            })
        ]
    };
}

function appear(id, segments, speed, size, finished) {
    size = size ? size : 36;
    speed = speed ? speed : 1;
    if ($(id + "Text")) {
        if ($(id + "Text").alpha === 0) {
            $(id + "Circle").updateLayout((make, view) => {
                make.center.equalTo(view.super);
                make.size.equalTo($size(size, size));
            });
            $ui.animate({
                duration: 0.3,
                delay: 0.0,
                damping: 0,
                velocity: 0,
                options: 0,
                animation: function () {
                    $(id + "Circle").relayout();
                    let layer = $(id + "Circle")
                        .runtimeValue()
                        .invoke("layer");
                    layer.invoke("setCornerRadius", size / 2);
                },
                completion: function () {}
            });

            $(id + "Text").updateLayout((make, view) => {
                textsAddShadows(view);
                make.size.equalTo(view.super);
                make.centerX.equalTo(view.super);
                make.centerY.equalTo(view.super).offset(size / 2 + 10);
            });
            $ui.animate({
                duration: 0.2,
                delay: 0.2,
                damping: 0,
                velocity: 0,
                options: 0,
                animation: function () {
                    $(id + "Text").alpha = 1;
                    $(id + "Text").relayout();
                },
                completion: function () {}
            });

            $ui.animate({
                duration: 0.4,
                delay: 0,
                damping: 0,
                velocity: 0,
                options: 0,
                animation: function () {
                    $(id + "BTN_inside").alpha = 1;
                },
                completion: function () {}
            });


            $(id + "BTN_inside_lottie").speed = speed;
            $(id + "BTN_inside_lottie").play({
                fromFrame: segments[0], // Optional
                toFrame: segments[1],
                handler: finished => {

                }
            });

        }
    }
}

function disappear(id, segments, speed) {
    speed = speed ? speed : 1;
    $(id + "Text").updateLayout((make, view) => {
        textsAddShadows(view);
        make.centerX.equalTo(view.super);
        make.centerY.equalTo(view.super).offset(0);
        make.size.equalTo($size(0, 0));
    });
    $ui.animate({
        duration: 0.3,
        delay: 0,
        damping: 0,
        velocity: 0,
        options: 0,
        animation: function () {
            $(id + "Text").relayout();
            $(id + "Text").alpha = 0;
        },
        completion: function () {}
    });

    if ($(id + "Text").alpha !== 0) {
        $(id + "Circle").updateLayout((make, view) => {
            //膨胀一下先

            make.center.equalTo(view.super);
            make.size.equalTo($size(46, 46));
        });
        $ui.animate({
            duration: 0.4,
            delay: 0,
            damping: 0.8,
            velocity: 0,
            options: 0,
            animation: function () {
                let layer = $(id + "Circle")
                    .runtimeValue()
                    .invoke("layer");
                layer.invoke("setCornerRadius", 23);
                $(id + "Circle").relayout();
            },
            completion: function () {}
        });
    }
    $(id + "Circle").updateLayout((make, view) => {
        make.center.equalTo(view.super);
        make.size.equalTo($size(0, 0));
    });
    $ui.animate({
        //缩小
        duration: 0.2,
        delay: 0.3,
        damping: 0.8,
        velocity: 0,
        options: 0,
        animation: function () {
            $(id + "Circle").relayout();

            let layer = $(id + "Circle")
                .runtimeValue()
                .invoke("layer");
            layer.invoke("setCornerRadius", 0);
        },
        completion: function () {}
    });


    $(id + "BTN_inside_lottie").speed = speed;
    $(id + "BTN_inside_lottie").play({
        fromFrame: segments[0], // Optional
        toFrame: segments[1],
        handler: finished => {}
    });
}

function press(id, segments, speed, expansion) {
    let curSize = $(id + "Circle").frame.width;
    expansion = expansion ? curSize + expansion : curSize * 1.3;
    speed = speed ? speed : 1;

    if ($(id + "Text").alpha !== 0) {
        $(id + "Circle").updateLayout((make, view) => {
            //膨胀一下先

            make.center.equalTo(view.super);
            make.size.equalTo($size(expansion, expansion));
        });
        $ui.animate({
            duration: 0.2,
            delay: 0,
            damping: 0,
            velocity: 0,
            options: 0,
            animation: function () {
                let layer = $(id + "Circle")
                    .runtimeValue()
                    .invoke("layer");
                layer.invoke("setCornerRadius", expansion / 2);
                $(id + "Circle").relayout();
            },
            completion: function () {}
        });
    }
    $(id + "Circle").updateLayout((make, view) => {
        make.center.equalTo(view.super);
        make.size.equalTo($size(curSize, curSize));
    });
    $ui.animate({
        //缩小
        duration: 0.5,
        delay: 0.2,
        damping: 0.4,
        velocity: 0,
        options: 0,
        animation: function () {
            $(id + "Circle").relayout();

            let layer = $(id + "Circle")
                .runtimeValue()
                .invoke("layer");
            layer.invoke("setCornerRadius", curSize / 2);
        },
        completion: function () {}
    });

    $(id + "BTN_inside_lottie").speed = speed;
    $(id + "BTN_inside_lottie").play({
        fromFrame: segments[1], // Optional
        toFrame: segments[0],
        handler: finished => {}
    });

}

function makeIcon() {
    let scriptName = $addin.current.name;
    $system.makeIcon({
        title: "Catcher",
        url: `jsbox://run?name=${encodeURIComponent(scriptName)}&from=desktop`,
        icon: $file.read("assets/icon.jpg").image
        // icon:$ui.window.snapshot
    });
}

function openning() {
    const scanner = lottie.BTN({
        props: {
            // path:'assets/lottie/ModernPictogramsForLottie_Printer.json',
            id: "scanner",
            startFrame: 0,
            // scale: 1,
            alpha: 0.8, //透明度
            userInteractionEnabled: false

        },
        layout: (make, view) => {
            make.edges.equalTo(view.super);
            // ui.viewsAddShadows(view); //性能杀手
        },
        //lottieLayout:$layout.fill,
        lottieEvents: {},
        events: {
            tapped: (sender) => {
                if ($cache.get("like")) {
                    $cache.set("runCount", 99);
                }
                if ($cache.get("runCount") <= 0) {
                    $ui.alert({
                        title: $l10n("喜欢Catcher吗?"),
                        message: $l10n("添加到桌面可以让你更快捷地使用它"),
                        actions: [{
                                title: $l10n("喜欢"),
                                handler: function () {
                                    makeIcon();
                                }
                            },
                            {
                                title: $l10n("加群支持一下"),
                                handler: function () {
                                    $app.openURL("tg://resolve?domain=CatcherJS");
                                }
                            },
                            {
                                title: $l10n("再考虑"),
                                handler: function () {
                                    $cache.set("runCount", 3);
                                    return;
                                }
                            }
                        ]
                    });
                }

                // diyToast({
                //     icon: "",
                //     src: "assets/sniffer.png",
                //     //                    src:"https://images.apple.com/v/ios/what-is/b/images/performance_large.jpg",
                //     title: "嗅探到3个电话,1条链接,4个日期",
                //     message: ["☎135-3366-3800", "🔗https://docs.xteko.com/#/uikit/view?id=type-view", "📍这是第三行", "📞135-3366-3800", "📆2018年10月06日22:51:48", "🗺️这是第六行", "🗓️这是第七行", "📅这是第八行", "☎这是第九行", "☎这是第十行", "☎135-3366-3800", "🔗https://docs.xteko.com/#/uikit/view?id=type-view", "📍这是第三行", "📞135-3366-3800", "📆2018年10月06日22:51:48", "🗺️这是第六行", "🗓️这是第七行", "📅这是第八行", "☎这是第九行", "☎这是第十行", "☎135-3366-3800", "🔗https://docs.xteko.com/#/uikit/view?id=type-view", "📍这是第三行", "📞135-3366-3800", "📆2018年10月06日22:51:48", "🗺️这是第六行", "🗓️这是第七行", "📅这是第八行", "☎这是第九行", "☎这是第十行", "☎135-3366-3800", "🔗https://docs.xteko.com/#/uikit/view?id=type-view", "📍这是第三行", "📞135-3366-3800", "📆2018年10月06日22:51:48", "🗺️这是第六行", "🗓️这是第七行", "📅这是第八行", "☎这是第九行", "☎这是第十行", "☎135-3366-3800", "🔗https://docs.xteko.com/#/uikit/view?id=type-view", "📍这是第三行", "📞135-3366-3800", "📆2018年10月06日22:51:48", "🗺️这是第六行", "🗓️这是第七行", "📅这是第八行", "☎这是第九行", "☎这是第十行"]
                // });
            }
        }
    });


    renderBoot();
    $("mainView").add(scanner);

    try {
        $("scanner_lottie").speed = 1.0;
        $("scanner_lottie").play({
            fromFrame: 0, // Optional
            toFrame: 120,
            handler: finished => {

            }
        });
    } catch (e) {
        console.warn("playLoading:当前没有scanner控件");
    }
}

function renderBoot() {
    $ui.render({
        type: "view",
        props: {
            id: "toppestView",
            navBarHidden: true,
            statusBarHidden: 0,
            statusBarStyle: 0,
            bgcolor: $color("black"),
        },
        views: [{
            type: "view",
            props: {
                id: "topperView",
                clipsToBounds: true,
                bgcolor: $color("white"),
            },
            views: [{
                type: "view",
                props: {
                    id: "topView",
                },
                views: [{
                    type: "view",
                    props: {
                        id: "mainView"
                    },
                    views: [{
                        type: "view",
                        props: {
                            id: "buttonView"
                        },
                        views: [],
                        layout: $layout.fill
                    }, ],
                    layout: $layout.fill
                }],
                layout: $layout.fill
            }],
            layout: $layout.fill
        }],
        layout: $layout.fill
    });

}

function diyToast(json) {
    let title = json.title ? json.title : json;
    let message = json.message ? json.message : undefined;

    let src = json.src ? json.src : undefined;

    let delay;

    if ($(title + "Toast")) {
        retract($(title + "Toast"));
        delay = 0.45;
    } else {
        delay = 0;
    }
    $delay(delay, function () {
        if (!$(title + "Toast")) {
            let rowHeight = 25;
            let titleFontSize = 16;
            let messageFontSize = 14;
            let thumbSize = 50;
            let spacing = 6;
            let sideInset = 8;
            let upInset = 50;
            // let whiteBoardHeight = titleFontSize + message.length * (rowHeight) + 3 * sideInset;
            // let whiteBoardHeight = thumbSize + 2 * sideInset;
            let whiteBoardHeight = 90;
            let whiteBoardHeight2 = rowHeight * message.length + titleFontSize + sideInset * 2.9; //设置为2.9,toast的列表就可以拖动,设置为3,则不能拖动
            whiteBoardHeight2 = whiteBoardHeight2 > 500 ? 500 : whiteBoardHeight2;
            let startPoint = -$ui.window.frame.height / 2 - whiteBoardHeight / 2 - 10;
            let endPoint = startPoint + whiteBoardHeight + upInset;
            let endPoint2 = startPoint + whiteBoardHeight2 - whiteBoardHeight + upInset;



            let expandBlur = {
                //type:"view",
                type: "blur",
                props: {
                    id: title + "_expandBlur",
                    style: 3,
                    alpha: 0,
                    userInteractionEnabled: true
                    //bgcolor:$color('black')
                },
                layout: (make, view) => {
                    make.center.equalTo(view.super);
                    make.size.equalTo(view.super);
                },
                events: {
                    tapped: sender => {

                        retract($(title + "Toast"));
                        $delay(0.0, function () {
                            fade(sender);
                        });
                    }
                }
            };
            $("topperView").add(expandBlur);

            let thumbImage = {
                type: "image",
                props: {
                    id: title + "_thumbImage",
                    src: src
                },
                layout: function (make, view) {
                    thumbShadows(view);
                    make.left.equalTo(view.super).offset(sideInset);
                    // make.top.equalTo(view.super).offset(sideInset);
                    make.centerY.equalTo(view.super);
                    make.size.equalTo($size(thumbSize, thumbSize));
                }
            };

            let titleLabel = {
                type: "label",
                props: {
                    id: title + "_titleLabel",
                    text: title,
                    align: $align.left,
                    font: $font("PingFangSC-Medium", titleFontSize),
                    autoFontSize: true
                },
                layout: function (make, view) {
                    make.left.equalTo($(title + "_thumbImage").right).offset(sideInset);
                    make.right.inset(sideInset);
                    make.top.inset(sideInset);
                }
            };

            let messageList = {
                type: "list",
                props: {
                    data: message,
                    id: title + "_messageList",
                    rowHeight: rowHeight,
                    // alwaysBounceVertical: false,
                    template: {
                        type: "label",
                        props: {
                            //text: message.join("\n"),
                            font: $font("PingFangSC-Regular", messageFontSize),
                            autoFontSize: true,
                            align: $align.left,
                        }
                    },

                },
                events: {
                    // willBeginDragging: function (sender) {
                    didSelect: function (sender, indexPath, data) {
                        listDidSelect(sender, indexPath, data);
                    },
                    didLongPress: function (sender, indexPath, data) {
                        listDidLongPress(sender, indexPath, data);
                    },
                    // },

                    // touchesBegan: (sender, location) => {
                    //     getOffset($(title + "Toast"), location);
                    // },
                    // touchesMoved: (sender, location) => {
                    //     console.info(sender.contentOffset)
                    //     if ($(title + "Toast").expanded) {
                    //         if (sender.contentOffset.y <= 0) {
                    //             moveLarge($(title + "Toast"), location, endPoint2, whiteBoardHeight2);
                    //         }
                    //     }
                    // },
                    // touchesEnded: (sender, location) => {
                    //     if ($(title + "Toast").throwed) {
                    //         retract($(title + "Toast"), location);
                    //         fade($(title + "_expandBlur"));
                    //     } else {
                    //         resetLarge($(title + "Toast"), location, endPoint2, whiteBoardHeight2);
                    //     }
                    // }

                },

                layout: function (make, view) {
                    // toastShadows(view);
                    make.left.equalTo($(title + "_thumbImage").right).offset(0);
                    make.top.equalTo($(title + "_titleLabel").bottom);
                    make.right.equalTo($(title + "Toast")).offset(-thumbSize - sideInset);
                    make.bottom.equalTo($(title + "Toast")).offset(0);
                }
            }

            let hint = {
                type: "label",
                props: {
                    id: title + "_hint",
                    font: $font("PingFangSC-Regular", 8),
                    autoFontSize: false,
                    align: $align.center,
                    text: $l10n("点按操作🔘\n上滑收起👆\n下拉展开👇"),

                    textColor: $color("lightGray"),
                    lines: 0,
                },
                layout: (make, view) => {
                    // make.centerX.equalTo($(title+"_thumbImage"));
                    // make.top.equalTo($(title+"_thumbImage").bottom).offset(8);
                    make.right.bottom.inset(10);
                }
            };

            let whiteGradient = {
                type: "gradient",
                props: {
                    colors: [$rgba(255, 255, 255, 0), $rgba(255, 255, 255, 1)],
                    locations: [0.2, 1.0],
                    startPoint: $point(0, 0),
                    endPoint: $point(0, 1),
                    id: title + "_whiteGradient",
                    userInteractionEnabled: 0,
                },
                layout: function (make, view) {
                    // make.top.bottom.equalTo(view.super);
                    // make.left.equalTo($(title + "_thumbImage").right).offset(sideInset);
                    // make.right.equalTo($(title + "Toast")).offset(-sideInset);

                    make.top.equalTo($(title + "_messageList"));
                    make.left.right.equalTo($(title + "_messageList"));
                    make.bottom.equalTo($(title + "_messageList")).offset(50);
                },
            };

            let whiteBoard = {
                type: "view",
                views: [
                    thumbImage,
                    titleLabel,
                    messageList,
                    // whiteGradient,
                    hint
                ],
                props: {
                    bgcolor: $color("white"),
                    id: title + "_whiteBoard",
                    clipsToBounds: true,
                },
                layout: function (make, view) {
                    make.edges.equalTo(view.super)
                    toastShadows(view);
                },

            };

            let newToast = {
                type: "view",
                views: [whiteBoard],
                props: {
                    bgcolor: $color("white"),
                    id: title + "Toast",
                    // expanded:false,
                },
                layout: function (make, view) {
                    toastShadows(view);
                    make.left.right.inset(sideInset);
                    make.height.equalTo(whiteBoardHeight);
                    //make.bottom.equalTo($("messageList").bottom)
                    make.centerY.equalTo(startPoint);
                },
                events: {
                    // tapped: sender => {

                    // },
                    touchesBegan: (sender, location) => {
                        getOffset(sender, location);
                    },
                    touchesMoved: (sender, location) => {
                        if (sender.expanded) {
                            moveLarge(sender, location, endPoint2, whiteBoardHeight2);
                        } else {
                            moveSmall(sender, location, endPoint, whiteBoardHeight);
                        }
                        console.info(sender.frame.y);
                    },
                    touchesEnded: (sender, location) => {
                        if (!sender.expanded) { //开没展开的状态
                            if (sender.dragged) {
                                expand(sender, location, endPoint2, whiteBoardHeight2);
                            } else {
                                resetSmall(sender, location, endPoint, whiteBoardHeight);
                            }
                        } else { //已经展开
                            if (sender.throwed) {
                                retract(sender, location);
                                fade($(title + "_expandBlur"));
                            } else {
                                resetLarge(sender, location, endPoint2, whiteBoardHeight2);
                            }
                        }
                    }
                }
            }

            $ui.window.add(newToast);
            $delay(0.1, function () {
                $(title + "Toast").updateLayout((make, view) => {
                    make.left.right.inset(sideInset);
                    make.height.equalTo(whiteBoardHeight);
                    make.centerY.equalTo(endPoint);
                });

                $ui.animate({
                    duration: 0.5,
                    delay: 0,
                    damping: 1,
                    velocity: 0,
                    options: 0,
                    animation: function () {
                        $(title + "Toast").relayout();
                    },
                    completion: function () {}
                });
            });
        }
    });
}

function listDidLongPress(sender, indexPath, data) {
    $clipboard.text = clearEmoji(data);
    $ui.toast($l10n("已复制:") + $clipboard.text);
}

function listDidSelect(sender, indexPath, data) {
    if (data.match("🔗")) {
        let defaultBrowser = $cache.get("defaultBrowser");
        if (!defaultBrowser) {
            $ui.alert({
                title: $l10n("是否进行转跳?"),
                message: $l10n("请选择浏览器"),
                actions: [{
                        title: "Chrome",
                        handler: function () {
                            chrome(data);
                        }
                    },
                    {
                        title: "Safari",
                        handler: function () {
                            safari(data);
                        }
                    },
                    {
                        title: "Chrome并设置为默认",
                        handler: function () {
                            $cache.set("defaultBrowser", "Chrome");
                            chrome(data);
                        }
                    },
                    {
                        title: "Safari并设置为默认",
                        handler: function () {
                            $cache.set("defaultBrowser", "Safari");
                            safari(data);
                        }
                    },
                    {
                        title: $l10n("取消")
                    }
                ]
            })
        } else {
            if (defaultBrowser === "Chrome") {
                chrome(data);
            } else if (defaultBrowser === "Safari") {
                safari(data);
            }
        }
    }

}

function chrome(data) {
    let url = clearEmoji(data).replace(/^/, "googlechrome://");
    url = url.replace(/^googlechrome:\/\/http:\/\//, "googlechrome://");
    url = url.replace(/^googlechrome:\/\/https:\/\//, "googlechromes://")
    $app.openURL(url);
}

function safari(data) {
    $app.openURL(clearEmoji(data));
}

function expand(sender, location, endPoint, whiteBoardHeight) {
    sender.expanded = true;
    let title = sender.id.replace("Toast", "");

    // let listExpand = {
    //     type: "list",
    //     props: {
    //         data: list.data,
    //         id: title + "_listExpand",
    //         rowHeight: 50,
    //         alwaysBounceVertical: false,
    //         alpha: 0,
    //         template: {
    //             type: "label",
    //             props: {
    //                 //text: message.join("\n"),
    //                 font: $font("PingFangSC-Regular", 16),
    //                 autoFontSize: true,
    //                 align: $align.left,
    //             }
    //         },

    //     },
    //     events: {
    //         // willBeginDragging: function (sender) {
    //         didSelect: (sender, indexPath, data) => {
    //             listDidSelect(sender, indexPath, data)
    //         },
    //         didLongPress: (sender, indexPath, data) => {
    //             listDidLongPress(sender, indexPath, data);
    //         },
    //         // },
    //         didScroll: function (sender) {

    //         }
    //     },

    //     layout: function (make, view) {
    //         toastShadows(view);

    //         // make.top.equalTo($(title + "_titleLabel").bottom);
    //         // make.bottom.equalTo($(title + "Toast")).offset(0);

    //         // make.edges.equalTo(view.super)
    //         make.top.inset(40);
    //         make.left.right.bottom.inset(0);
    //     }
    // }

    // $(title + "_whiteBoard").add(listExpand);

    // list.remove();

    // $(title + "_messageList").scrollEnabled = false;

    $(title + "_thumbImage").updateLayout((make, view) => {
        make.centerY.equalTo(view.super.top).offset(23);
        make.size.equalTo($size(22, 22));
    });

    sender.updateLayout((make, view) => {
        // make.centerY.equalTo(endPoint);
        // make.height.equalTo(whiteBoardHeight);
        make.centerY.equalTo($ui.window);
        make.height.equalTo(whiteBoardHeight);
    });
    $(title + "_messageList").updateLayout((make, view) => {
        make.top.inset(40);
        make.left.right.bottom.equalTo($(title + "Toast"));
    });

    $ui.animate({
        duration: 0.5,
        delay: 0,
        damping: 0.5,
        velocity: 0,
        options: 0,
        animation: function () {
            sender.relayout();
            $(title + "_thumbImage").relayout();
            $(title + "_hint").alpha = 0;

            // $(title + "_messageList").relayout();
        },
        completion: function () {

        }
    });
    // $ui.animate({
    //     duration: 0.02,
    //     delay: 0,
    //     damping: 0,
    //     velocity: 0,
    //     options: 0,
    //     animation: function () {
    //         $(title + "_listExpand").alpha = 1;
    //     },
    //     completion: function () {

    //     }
    // });

    $delay(0.0, function () {
        $ui.animate({
            duration: 0.2,
            delay: 0,
            damping: 0,
            velocity: 0,
            options: 0,
            animation: function () {
                $(title + "_expandBlur").alpha = 1;
            },
            completion: function () {

            }
        });
    });
}




function retract(sender, location) {
    sender.expanded = false;
    sender.dragged = false;

    let mul;

    if (location) {
        let beganOffset = sender.info;
        let {
            // x,
            y
        } = sender.frame;
        // x += location.x - beganOffset.x;
        y += location.y - beganOffset.y;
        targetY = y - $ui.window.frame.height / 2;
    } else {
        targetY = -1;
    }

    if (targetY < 0) {
        mul = 1;
    } else {
        mul = -1
    }
    let whiteBoardHeight = sender.frame.height;
    let startPoint = (-$ui.window.frame.height / 2 - whiteBoardHeight / 2 - 10) * mul
    sender.updateLayout((make, view) => {
        make.centerY.equalTo(startPoint);
    });
    $ui.animate({
        duration: 0.4,
        delay: 0,
        damping: 1,
        velocity: 0,
        options: 0,
        animation: function () {
            sender.relayout();
        },
        completion: function () {
            sender.remove();
        }
    });
}

function getOffset(sender, location) {
    // let x = location.x - sender.frame.width / 2;
    let y = location.y - sender.frame.height / 2;
    sender.info = {
        // x: x,
        y: y
    };
}

function moveLarge(sender, location, endPoint, curHeight) {

    let max = 100;
    // let min = 150;

    let beganOffset = sender.info;
    let {
        // x,
        y
    } = sender.frame;
    // x += location.x - beganOffset.x;
    y += location.y - beganOffset.y;

    targetY = y - $ui.window.frame.height / 2;


    // let offset = Math.abs(endPoint - targetY);
    let offset = Math.abs(targetY);

    let damping = 0.8;
    let smooth = (offset - 1) * damping + 1;

    // if (targetY > endPoint) {
    //     targetY = y - $ui.window.frame.height / 2 - smooth;
    // }

    sender.updateLayout(function (make, view) {
        // make.centerX.equalTo(x - $ui.window.frame.width / 2);
        // console.info(targetY);
        make.centerY.equalTo(targetY);
        make.size.equalTo($size(0, curHeight));
    });
    $ui.animate({
        duration: 0.001,
        damping: 0,
        velocity: 100,
        animation: () => {
            sender.relayout();
        }
    });

    // if ((!sender.dragged) && offset > max) {
    //     $device.taptic(2);
    //     sender.dragged = true;
    // } else if ((sender.dragged) && offset <= min) {
    //     $device.taptic(2);
    //     sender.dragged = false;
    // }

    if ((!sender.throwed) && offset > max) {
        $device.taptic(2);
        sender.throwed = true;
    } else if ((sender.throwed) && offset <= max) {
        // $device.taptic(2);
        sender.throwed = false;
    }
}

function moveSmall(sender, location, endPoint, curHeight) {

    let max = 200;
    let min = 150;

    let beganOffset = sender.info;
    let {
        // x,
        y
    } = sender.frame;
    // x += location.x - beganOffset.x;
    y += location.y - beganOffset.y;

    targetY = y - $ui.window.frame.height / 2;


    let offset = Math.abs(endPoint - targetY);

    let damping = 0.8;
    let smooth = (offset - 1) * damping + 1;

    if (targetY > endPoint) {
        targetY = y - $ui.window.frame.height / 2 - smooth;
    }

    sender.updateLayout(function (make, view) {
        // make.centerX.equalTo(x - $ui.window.frame.width / 2);
        // console.info(targetY);
        make.centerY.equalTo(targetY);
        make.size.equalTo($size(0, curHeight + smooth / 4));
    });
    $ui.animate({
        duration: 0.001,
        damping: 0,
        velocity: 100,
        animation: () => {
            sender.relayout();
        }
    });

    if ((!sender.dragged) && offset > max) {
        $device.taptic(2);
        sender.dragged = true;
    } else if ((sender.dragged) && offset <= min) {
        $device.taptic(2);
        sender.dragged = false;
    }

}

function resetLarge(sender, location, endPoint, whiteBoardHeight) {

    let beganOffset = sender.info;
    let {
        x,
        y
    } = sender.frame;
    x += location.x - beganOffset.x;
    y += location.y - beganOffset.y;

    targetY = y - $ui.window.frame.height / 2;

    // console.info(endPoint - targetY);


    sender.updateLayout(function (make, view) {
        make.centerY.equalTo($ui.window);
        make.size.equalTo($size(0, whiteBoardHeight));
    });
    $ui.animate({
        duration: 0.4,
        damping: 0.5,
        velocity: 0,
        animation: () => {
            sender.relayout();
        }
    });
    sender.expanded = true;

}

function resetSmall(sender, location, endPoint, whiteBoardHeight) {

    let beganOffset = sender.info;
    let {
        x,
        y
    } = sender.frame;
    x += location.x - beganOffset.x;
    y += location.y - beganOffset.y;

    targetY = y - $ui.window.frame.height / 2;

    // console.info(endPoint - targetY);

    if (targetY >= endPoint - 30) {
        sender.updateLayout(function (make, view) {
            make.centerY.equalTo(endPoint);
            make.size.equalTo($size(0, whiteBoardHeight));
        });
        $ui.animate({
            duration: 0.3,
            damping: 0.5,
            velocity: 0,
            animation: () => {
                sender.relayout();
            }
        });
    } else {
        retract(sender, location);
    }

}




function clearEmoji(text) {
    return text.replace(/(?:[\u2700-\u27bf]|(?:\ud83c[\udde6-\uddff]){2}|[\ud800-\udbff][\udc00-\udfff]|[\u0023-\u0039]\ufe0f?\u20e3|\u3299|\u3297|\u303d|\u3030|\u24c2|\ud83c[\udd70-\udd71]|\ud83c[\udd7e-\udd7f]|\ud83c\udd8e|\ud83c[\udd91-\udd9a]|\ud83c[\udde6-\uddff]|\ud83c[\ude01-\ude02]|\ud83c\ude1a|\ud83c\ude2f|\ud83c[\ude32-\ude3a]|\ud83c[\ude50-\ude51]|\u203c|\u2049|[\u25aa-\u25ab]|\u25b6|\u25c0|[\u25fb-\u25fe]|\u00a9|\u00ae|\u2122|\u2139|\ud83c\udc04|[\u2600-\u26FF]|\u2b05|\u2b06|\u2b07|\u2b1b|\u2b1c|\u2b50|\u2b55|\u231a|\u231b|\u2328|\u23cf|[\u23e9-\u23f3]|[\u23f8-\u23fa]|\ud83c\udccf|\u2934|\u2935|[\u2190-\u21ff])/g, "");

}

module.exports = {
    viewsAddShadows: viewsAddShadows,
    textsAddShadows: textsAddShadows,
    openning: openning,
    loading: loading,
    playLoading: playLoading,
    stopLoading: stopLoading,
    // textMaker:textMaker,
    // circleMaker:circleMaker,
    btnMaker: btnMaker,
    appear: appear,
    disappear: disappear,
    press: press,
    fade: fade,
    diyToast: diyToast,
    rounded: rounded,
    rightCorner: rightCorner,
    textRounded: textRounded,
    renderBoot: renderBoot,
    closeWin: closeWin,
}