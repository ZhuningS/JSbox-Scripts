const file = require("scripts/fileUtil");

function BTN(json) {
  let path,
    animationData,
    id,
    events,
    layout,
    scale,
    lottieLayout,
    lottieEvents,
    childID,
    lottieJs,
    alpha;

  try {
    id = json.props.id;
    path = json.props.path ? json.props.path : `assets/lottie/${id}.json`;
    startFrame = json.props.startFrame;
    scale = json.props.scale;
    alpha = json.props.alpha !== undefined ? json.props.alpha : 1;
    fps = json.props.fps;
    events = json.events;
    layout = json.layout;
    lottieLayout = json.lottieLayout;
    lottieEvents = json.lottieEvents;
  } catch (e) { }

  if (!path) {
    $ui.toast("没有指定json文件路径");
    return;
  }
  if (!id) {
    $ui.toast("没有指定id");
    return;
  }

  if (!layout) {
    layout = $layout.fill;
  }
  if (!lottieLayout) {
    //如果没有填写lottieLayout参数
    if (!scale) {
      //而且没有scale参数
      lottieLayout = function (make, view) {
        make.center.equalTo(view.super);
        make.size.equalTo($size(350,350));
      };
    } else {
      //有scale参数
      lottieLayout = function (make, view) {
        make.center.equalTo(view.super);
        make.size.equalTo($size(250,250));
      };
    }
  }

 

  childID = id + "_lottie";
  // animationData = JSON.stringify($file.read(path).string);
  // lottieJs = $file.read(file.lottiePath()).string;
  const lottieBTN = {
    type: "view",
    props: {
      id: id,
      userInteractionEnabled: true,
      // bgcolor: $color("black"),
      alpha: alpha
    },
    views: [
      {
        type: "lottie",
        props: {
          src: path,
          id: childID,
          // bgcolor: $color("green"),
        },
        layout: lottieLayout,
        events: lottieEvents
      }
    ],
    events: events,
    layout: layout
  };
  return lottieBTN;
}

// function BTN(json) {//备用的BTN
//   let path,
//     animationData,
//     id,
//     events,
//     layout,
//     scale,
//     lottieLayout,
//     lottieEvents,
//     childID,
//     lottieJs,
//     alpha;

//   try {
//     id = json.props.id;
//     path = json.props.path ? json.props.path : `assets/lottie/${id}.json`;
//     startFrame = json.props.startFrame;
//     scale = json.props.scale;
//     alpha = json.props.alpha !== undefined ? json.props.alpha : 1;
//     fps = json.props.fps;
//     events = json.events;
//     layout = json.layout;
//     lottieLayout = json.lottieLayout;
//     lottieEvents = json.lottieEvents;
//   } catch (e) {}

//   if (!path) {
//     $ui.toast("没有指定json文件路径");
//     return;
//   }
//   if (!id) {
//     $ui.toast("没有指定id");
//     return;
//   }

//   if (!layout) {
//     layout = $layout.fill;
//   }
//   if (!lottieLayout) {
//     //如果没有填写lottieLayout参数
//     if (!scale) {
//       //而且没有scale参数
//       lottieLayout = function(make, view) {
//         make.center.equalTo(view.super);
//         make.size.equalTo(view.super);
//       };
//     } else {
//       //有scale参数
//       lottieLayout = function(make, view) {
//         make.center.equalTo(view.super);
//         make.size.equalTo(view.super).multipliedBy(scale);
//       };
//     }
//   }

//   childID = id + "_lottie";
//   animationData = JSON.stringify($file.read(path).string);
//   lottieJs = $file.read(file.lottiePath()).string;
//   const lottieBTN = {
//     type: "view",
//     props: {
//       id: id,
//       userInteractionEnabled: true,
//       bgcolor: $color("clear"),
//       alpha: alpha
//     },
//     views: [
//       {
//         type: "web",
//         props: {
//           id: childID,
//           scrollEnabled: !1,
//           showsProgress: !1,
//           transparent: 1,
//           userInteractionEnabled: !1,

//           html: `<!DOCTYPE html>
//           <html lang="en">
//           <head>
//               <meta charset="UTF-8">
//               <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
//               <meta http-equiv="X-UA-Compatible" content="ie=edge">
//               <title>Document</title>
//           </head>
//           <style>
//               #svgContainer,
//               html {
//                   background-color: rgba(255,255,255,0)//透明背景
//               }
//               html {
//                   margin: 0;
//                   padding: 0
//               }
//               body,
//               html {
//                   overflow: hidden
//               }
//               #svgContainer {

//                   position: absolute;
//                   top: 0;
//                   left: 0;
//                   right: 0;
//                   bottom: 0;
//                   margin: auto
//               }
//           </style>
//           </head>
//           <body>
//               <div id="svgContainer"></div>
//               <script type="text/javascript">${lottieJs}</script>
//               <script>
//                   var animationData = ${animationData};//在这修改应用的动画json
//                   var svgContainer = document.getElementById("svgContainer");
//                   animItem = bodymovin.loadAnimation({ wrapper: svgContainer, animType: "svg", loop: !0, animationData: JSON.parse(animationData) });
//                   animItem.goToAndStop(${startFrame},true);//初始帧设定

//               </script>
//           </body>
//           </html>`
//         },
//         layout: lottieLayout,
//         events: lottieEvents
//       }
//     ],
//     events: events,
//     layout: layout
//   };
//   return lottieBTN;
// }


module.exports = {
  BTN: BTN
};
