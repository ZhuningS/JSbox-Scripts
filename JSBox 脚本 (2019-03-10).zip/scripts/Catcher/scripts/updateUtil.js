function getCurVersion() {
  let version = $file.exists("version.lcolok")
    ? $file.read("version.lcolok").string
    : "0.0.0";
  return version;
}

// function getCurVersion() {
//     let version = JSON.parse($file.read("config.json").string).info.version;
//     return version
// }

function needRestart() {
  return $http.get({
    url:
      "https://github.com/lcolok/Catcher/raw/master/restart.lcolok" +
      "?t=" +
      new Date().getTime()
  });
}

function getLatestVersion(params) {
  $http.get({
    url:
      "https://raw.githubusercontent.com/lcolok/Catcher/master/version.lcolok" +
      "?t=" +
      new Date().getTime(),
    handler: res => {
      params.handler(res.data);
    }
  });
}

// function getLatestVersion(params) {
//     $http.get({
//         url: 'https://raw.githubusercontent.com/lcolok/Catcher/master/config.json' + '?t=' + new Date().getTime(),
//         handler: res => {
//             params.handler(res.data.info.version)
//         }
//     })
// }

function updateScript(version) {
  let url =
    "https://github.com/lcolok/Catcher/blob/master/.output/Catcher.box?raw=true" +
    "?t=" +
    new Date().getTime();
  const scriptName = $addin.current.name;
  let downloadBox = $http.download({
    url: url
  });
  Promise.all([downloadBox, needRestart()]).then(res => {
    let box = res[0].data;
    let restart = /true/.test(res[1].data);
    console.log(restart);
    $addin.save({
      name: scriptName,
      data: box,
      handler: success => {
        if (success) {
          // let donateList = $file.read("donate.md").string;
          // let names = donateList.split(/[\r\n]+/).filter(i => i!== '');
          // $ui.toast(`静默更新完成，感谢${names.length - 3}位老板`);
          $ui.toast($l10n("静默更新完成"));
          if (restart) {
            $delay(0.3, () => {
              $addin.run(scriptName);
            });
          }
        }
      }
    });
  });
}

function needUpdate(nv, ov) {
  let getVersionWeight = i => {
    return i
      .split(".")
      .map(i => i * 1)
      .reduce((s, i) => s * 100 + i);
  };
  return getVersionWeight(nv) > getVersionWeight(ov);
}

// function check(){
//     getLatestVersion({
//         handler: version => {
//             console.log(`latest version: ${version}`);
//             console.log(`current version: ${getCurVersion()}`);
//             if (needUpdate(version, getCurVersion())) {
//                 $http.get({
//                     url: 'https://raw.githubusercontent.com/lcolok/Catcher/master/updateLog.md' + '?t=' + new Date().getTime(),
//                     handler: resp => {
//                         updateScript(version)
//                     }
//                 })

//             }else{
//                 console.log("已经是最新版");
//             }
//         }
//     })
// }

module.exports = {
  getCurVersion: getCurVersion,
  getLatestVersion: getLatestVersion,
  updateScript: updateScript,
  needUpdate: needUpdate
  // check:check
};
