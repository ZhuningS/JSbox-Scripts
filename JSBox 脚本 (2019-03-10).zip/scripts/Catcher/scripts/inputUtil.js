var ui = require("scripts/uiUtil");
var trans =  require("scripts/transUtil");

async function takeApart(input) { //分词操作
    return await $text.tokenize({
        text: input,
    })
}

function setInputTool(inputView, inputText) {
    function creatMatrix() {
        let picked = [];
        let pickedInOrder = [];
        return $ui.create({
            type: "matrix",
            props: {
                frame: $rect(0, 0, 0, 335),
                itemHeight: 26,
                spacing: 5,
                scrollEnabled: false,
                id: "matrix",
                template: {
                    views: [{
                        type: "label",
                        props: {
                            id: "label",
                            radius: 15,
                            font: $font(14),
                            textColor: $color("#333333"),
                            bgcolor: $color("#efefef"),
                            borderColor: $color("#dddddd"),
                            borderWidth: 0.5,
                            align: $align.center
                        },
                        layout: $layout.fill
                    }]
                }
            },
            events: {
                didSelect: async function (sender, indexPath, data) {
                        let results = await takeApart(inputView.text);
                        for (let i = 0; i < results.length; i++) {
                            console.info(i);
                            cell = $("matrix").cell($indexPath(0, i));
                            label = cell.get("label");
                            if (label.info) {
                                picked.push(label.text);
                            }
                        }



                        let thisCell = sender.cell(indexPath);
                        let thisLabel = thisCell.get("label");
                        if (thisLabel.info >= 0) {
                            pickedInOrder.splice([thisLabel.info], 1);
                            deselected(thisLabel);
                        } else {
                            selected(thisLabel, picked.length);
                            pickedInOrder.push(thisLabel.text);
                        }

                        $cache.set("pickedInOrder", pickedInOrder);

                        // console.info(cell.text)
                        // console.info(cell.views[0].titleColor)
                        // cell.remove()

                        // if(!cell.info){//还没被选中
                        //     cell.info = true;
                        //     cell.titleColor=$color("#efefef");
                        //     cell.bgcolor=$color("#333333");
                        // }else{
                        //     cell.info = false;
                        //     cell.titleColor=$color("#333333");
                        //     cell.bgcolor=$color("#efefef");
                        // }

                        // inputView.runtimeValue().$insertText("{{" + data.label.text + "}}");
                    },
                    itemSize: function (sender, indexPath) {
                        var data = sender.object(indexPath);
                        var size = $text.sizeThatFits({
                            text: data.label.text,
                            width: 320,
                            font: $font(14)
                        });
                        return $size(size.width + 27, 30);
                    },
                    touchesMoved: function (sender) {
                        // console.info(sender.contentOffset)
                        if (sender.contentOffset.y > 0) {
                            $("matrix").scrollEnabled = true
                        }
                    },
                    highlighted: function (view) {
                        // let label = view.get("label");

                        //     label.textColor = $color("white");
                        //     label.bgcolor = $color("lightGray");
                        //     label.borderColor = $color("gray");
                        //     label.borderWidth = 1;
                        //     label.info = true;

                    }
            }
        });
    }

    function selected(label, count) {
        label.textColor = $color("white");
        label.bgcolor = $color("lightGray");
        label.borderColor = $color("gray");
        label.borderWidth = 1;
        label.info = count;
    }

    function deselected(label) {
        label.textColor = $color("#333333");
        label.bgcolor = $color("#efefef");
        label.borderColor = $color("#dddddd");
        label.borderWidth = 0.5;
        label.info = undefined;
    }

    let participleBTN = {
        type: "button",
        props: {
            id: "participleBTN",
            title: $l10n("分词"),
            radius: 6,
            font: $font(14),
            titleColor: $color("#333333"),
            bgcolor: $color("#ffffff"),
            borderWidth: 0.5,
            borderColor: $color("#cccccc")
        },
        layout: function (make, view) {
            make.left.inset(10);
            make.size.equalTo($size(50, 30));
            make.centerY.equalTo(view.super);
        },
        events: {
            tapped: async function (sender) {
                if (inputView.runtimeValue().$inputView()) {

                    inputView.runtimeValue().$setInputView(null);
                    toolView.get("participleBTN").bgcolor = $color("#ffffff");
                    $("matrix").remove();
                } else {
                    let results = await takeApart(inputView.text);
                    var variableView = creatMatrix();
                    var data = results;
                    variableView.data = data.map(item => {
                        return {
                            label: {
                                text: item
                            }
                        };
                    });
                    inputView.runtimeValue().$setInputView(variableView);
                    toolView.get("participleBTN").bgcolor = $color("#cccccc");







                }
                inputView.runtimeValue().$reloadInputViews();
            }
        }
    }
    let lineUp = inputText.join("").replace(/\s/g, "");//成句 就连所有空格都要去掉
    // let lineUp = inputText.join(" ");//成句 保留本身存在的空格,而且上下连接之间也是利用空格
    let multiLine = inputText.join("\n");

    let lineUpBTN = {
        type: "button",
        props: {
            id: "lineUpBTN",
            title: $l10n("成句"),
            radius: 6,
            font: $font(14),
            titleColor: $color("#333333"),
            bgcolor: $color("#ffffff"),
            borderWidth: 0.5,
            borderColor: $color("#cccccc")
        },
        layout: function (make, view) {
            make.left.equalTo(view.prev.right).offset(6);
            make.size.equalTo($size(50, 30));
            make.centerY.equalTo(view.super);

            // make.left.inset(10);
            // make.size.equalTo($size(50, 30));
            // make.centerY.equalTo(view.super);
        },
        events: {
            tapped: function (sender) {
                if (sender.title === $l10n("成句")) {
                    $("text").text = lineUp;
                    sender.title = $l10n("多行");
                } else if (sender.title === $l10n("多行")) {
                    $("text").text = multiLine;
                    sender.title = $l10n("清空");
                } else if (sender.title === $l10n("清空")) {
                    $("text").text = "";
                    sender.title = $l10n("成句");
                }

                $delay(0.05, function () {
                    $("text").selectedRange = $range(0, 0);
                });
            }
        }
    };

    // let multiLineBTN = {
    //     type: "button",
    //     props: {
    //         id: "multiLineBTN",
    //         title: $l10n("多行"),
    //         radius: 6,
    //         font: $font(14),
    //         titleColor: $color("#333333"),
    //         bgcolor: $color("#ffffff"),
    //         borderWidth: 0.5,
    //         borderColor: $color("#cccccc")
    //     },
    //     layout: function (make, view) {
    //         make.left.equalTo(view.prev.right).offset(6);
    //         make.size.equalTo($size(50, 30));
    //         make.centerY.equalTo(view.super);
    //     },
    //     events: {
    //         tapped: function (sender) {

    //         }
    //     }
    // };

    let copyAllBTN = {
        type: "button",
        props: {
            id: "copyAllBTN",
            title: $l10n("复制"),
            radius: 6,
            font: $font(14),
            titleColor: $color("#333333"),
            bgcolor: $color("#ffffff"),
            borderWidth: 0.5,
            borderColor: $color("#cccccc")
        },
        layout: function (make, view) {
            make.left.equalTo(view.prev.right).offset(6);
            make.size.equalTo($size(50, 30));
            make.centerY.equalTo(view.super);
        },
        events: {
            tapped: function (sender) {
                // let picked = []
                // for (let i = 0; i < results.length; i++) {
                //     cell = $("matrix").cell($indexPath(0, i));
                //     label = cell.get("label");
                //     if (label.info) {
                //         picked.push(label.text);
                //     }
                // }

                let pickedInOrder = $cache.get("pickedInOrder");

                let range = $("text").selectedRange;
                if (range.length !== 0) { //复制选中区域
                    let clip = $("text").text.slice(range.location, range.location + range.length);
                    console.info(clip);
                    $clipboard.text = clip;
                    $ui.toast("已复制选中部分");
                } else if (pickedInOrder.length > 0) {
                    $clipboard.text = pickedInOrder.join("");
                    $ui.toast("已复制分词部分");
                } else { //复制全部
                    $clipboard.text = $("text").text;
                    $ui.toast("已复制全部");
                }

            }
        }
    };

    let transBTN = {
        type: "button",
        props: {
            id: "transBTN",
            title: $l10n("翻译"),
            radius: 6,
            font: $font(14),
            titleColor: $color("#333333"),
            bgcolor: $color("#ffffff"),
            borderWidth: 0.5,
            borderColor: $color("#cccccc")
        },
        layout: function (make, view) {
            make.left.equalTo(view.prev.right).offset(6);
            make.size.equalTo($size(50, 30));
            make.centerY.equalTo(view.super);
        },
        events: {
            tapped: async function (sender) {
               

                if (sender.title === $l10n("翻译")) {
                    trans.googleTrans(inputView, inputView);
                    sender.title = $l10n("原文");
                } else if (sender.title === $l10n("原文")) {
                    $("text").text = multiLine;
                    sender.title = $l10n("翻译");
                }
            }
        }
    };

    let hideKeyboardBTN = {
        type: "button",
        props: {
            title: $l10n("收起⤓"),
            font: $font("bold", 14),
            titleColor: $color("#333333"),
            bgcolor: $color("clear")
        },
        layout: function (make, view) {
            make.top.right.bottom.inset(0);
            make.width.equalTo(60);
        },
        events: {
            tapped: function (sender) { //收起
                ui.closeWin();
                inputView.blur();
                toolView.get("participleBTN").bgcolor = $color("#ffffff");
                inputView.runtimeValue().$setInputView(null);
            }
        }
    };



    var toolView = $ui.create({
        type: "view",
        props: {
            frame: $rect(0, 0, 0, 40),
            bgcolor: $color("#eeeeee"),
            borderWidth: 0.5,
            borderColor: $color("#cccccc"),
            // contentSize:$size(500,500)

        },
        views: [
            participleBTN,
            lineUpBTN,
            // multiLineBTN,
            transBTN,
            copyAllBTN,
            hideKeyboardBTN,

        ]
    });
    inputView.runtimeValue().$setInputAccessoryView(toolView);
    inputView.runtimeValue().$reloadInputViews();
}




module.exports = {
    setInputTool: setInputTool
}