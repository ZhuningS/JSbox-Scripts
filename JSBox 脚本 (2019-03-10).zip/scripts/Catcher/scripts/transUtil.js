async function baiduTrans(inputView, outpoutView) {
    let resp = await $http.post({
        url: "https://fanyi.baidu.com/basetrans",
        header: {
            "cookie": "Hm_lpvt_64ecd82404c51e03dc91cb9e8c025574=1533971954; Hm_lpvt_afd111fa62852d1f37001d1f980b6800=1533971953; Hm_lvt_64ecd82404c51e03dc91cb9e8c025574=1533971954; Hm_lvt_afd111fa62852d1f37001d1f980b6800=1533971953; locale=zh; SE_LAUNCH=5:25565980_0:25565980; BDORZ=AE84CDB3A529C0F8A2B9DCDD1D18B695; BIDUPSID=05BE4AB31EE3F53ABBB5ADAB70B0E392; BAIDUID=05BE4AB31EE3F53ABBB5ADAB70B0E392:FG=1",
            "User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 12_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/12.0 Mobile/15E148 Safari/604.1"
        },
        form: {
            "from": "auto",
            "query": inputView.text,
            "to": "en"
        }
    });
    var data = resp.data
    let tr = ""
    data.trans.forEach(e => {
        tr = tr.concat(e.dst + "\n")
    });

    try {
        outpoutView.text = tr;
    } catch (e) {
        console.warn("没有outpoutView");
    }

    return tr;
}

async function googleTrans(inputView, outpoutView) {
    let resp = await $http.post({
        url: "http://translate.google.cn/translate_a/single",
        header: {
            "User-Agent": "iOSTranslate",
            "Content-Type": "application/x-www-form-urlencoded"
        },
        body: {
            "dt": "t",
            "q": inputView.text,
            "tl": whichLan(inputView),
            "ie": "UTF-8",
            "sl": "auto",
            "client": "ia",
            "dj": "1"
        },

    })
    var data = resp.data
    let tr = ""
    data.sentences.forEach(e => {
        tr = tr.concat(e.trans + "");
    });

    try {
        outpoutView.text = tr;
    } catch (e) {
        console.warn("没有outpoutView");
    }

    return tr
}

async function caiyunTrans(inputView, outpoutView) {
    let resp = await $http.post({
        url: "https://api.interpreter.caiyunai.com/v1/translator",
        header: {
            "Accept": "*/*",
            "Accept-Encoding": "br, gzip, deflate",
            "Accept-Language": "zh-cn",
            "Connection": "keep-alive",
            "Content-Length": "85",
            "Content-Type": "application/json",
            "Host": "api.interpreter.caiyunai.com",
            "User-Agent": "caiyunInterpreter/3 CFNetwork/902.2 Darwin/17.7.0",
            "X-Authorization": "token ssdj273ksdiwi923bsd9",
        },
        body: caiyunJSON(inputView),
    })
    var data = resp.data;


    try {
        outpoutView.text = data.target;
    } catch (e) {
        console.warn("没有outpoutView");
    }

    return data.target;
}

function caiyunJSON(inputView) {
    let zx = whichLan(inputView)
    if (zx === "en") {
        caiyunurl = {
            "source": inputView.text.replace(/\n/g, "\t"),
            "request_id": 1783325475,
            "trans_type": "zh2en",
            "media": "text"
        }
    } else if (zx != "en") {
        caiyunurl = {
            "source": inputView.text.replace(/\n/g, "\t"),
            "request_id": 1783325475,
            "trans_type": "en2zh",
            "media": "text"
        }
    }
    return caiyunurl
}

async function youdaoTrans(inputView, outpoutView) {
    let resp = await $http.get({
        url: "https://api.m.sm.cn/rest?callback=&method=tools.translation&q=" + encodeURI(inputView.text),
        header: {
            "Cookie": "isg=BNDQjJmzvyB2HWMLbSW6pbbXqxoimbTjHiiIHcqhhCv-BXuvdqlac8Tz2QtGzmy7; sm_sid=c491ba687e57ccb1f4b1455ae49dfcb0; sm_uuid=c0b9754f499f40bc920612e9c891682f%7C%7C%7C1532964646; cna=tAXjE7egWV4CAbfr/zTj5p61; sm_diu=bdc017edf5ee7df054b108351526cb35%7C%7C12ede2ed494e05a1fa%7C1532762035",
            "Host": "api.m.sm.cn",
            "Referer": "https://m.sm.cn/s?q=%E6%9C%89%E9%81%93%E8%AF%8D%E5%85%B8%E5%9C%A8%E7%BA%BF%E7%BF%BB%E8%AF%91&by=suggest&snum=6",
            "User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 11_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15G77 CriOS/67.0 Mobile/15F79 Safari/604.1",
        },
    })
    var data = resp.data;
    try {
        outpoutView.text = data.data.translation[0];
    } catch (e) {
        console.warn("没有outpoutView");
    }

    return data.data.translation[0]
}

function whichLan(inputView) {
    let englishChar = inputView.text.match(/[a-zA-Z]/g);
    let englishNumber = !englishChar ? 0 : englishChar.length;
    let chineseChar = inputView.text.match(/[\u4e00-\u9fff\uf900-\ufaff]/g);
    let chineseNumber = !chineseChar ? 0 : chineseChar.length;

    return (chineseNumber * 2) >= englishNumber && chineseNumber ? "en" : englishNumber >= 8 ? "zh-CN" : "auto";

}

async function multiTrans(inputView, outpoutView) {
    let result;
    let g = googleTrans(inputView);
    let b = baiduTrans(inputView);
    let c = caiyunTrans(inputView);
    let y = youdaoTrans(inputView);
    let arr = [g, b, c, y];
    let sum = await Promise.all(arr);
    console.info(sum);


    let j = 1;
    let k = 0;
    let score = [0, 0, 0, 0];
    for (let i = 0; i < sum.length; i++) {
        for (let j = 1; i + j + 1 <= sum.length; j++) {

            s = await compare(sum[i], sum[i + j]);
            score[i] += s;
            score[i + j] += s;
        }
    }

    function max(arr) {
        let index = 0;
        let max = arr[0];

        for (let i = 0; i < arr.length - 1; i++) {

            if (max < arr[i + 1]) {
                max = arr[i + 1];
                index = i + 1;
            }
        }
        return {
            max: max,
            index: index,
        }
    }
    console.info(score);
    console.info(max(score));

    result = sum[max(score).index];
    console.info(result);
    outpoutView.text = result;
    return result;
}

async function compare(text_1, text_2) {
    let resp = await $http.get({
        url: `https://ai.baidu.com/weapp/rpc/2.0/nlp/v2/simnet?text_1=${encodeURI(text_1)}&text_2=${encodeURI(text_2)}`,
        header: {
            "sessionKey": "824aa0ee-e0da-4232-af09-0196b60ce72b=59db2b8b-df95-4522-a500-6b9a756affd3",
        }
    });
    return resp.data.score;
}

module.exports = {
    baiduTrans: baiduTrans,
    googleTrans: googleTrans,
    caiyunTrans: caiyunTrans,
    youdaoTrans: youdaoTrans,
    multiTrans: multiTrans,
}