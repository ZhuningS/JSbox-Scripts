// function setTempPic(image){
//     if(!$file.exists("shared://Catcher")){
//         $file.mkdir("shared://Catcher")
//     };
//     if(!$file.exists("shared://Catcher/cache")){
//         $file.mkdir("shared://Catcher/cache")
//     }
//     $file.write({
//         data: image.jpg(1.0),
//         path: "shared://Catcher/cache/temp.jpg"
//     });
// };

// function getTempPic(){
//     let temp = $file.read("shared://Catcher/cache/temp.jpg").image;
//     $file.delete("shared://Catcher/cache/temp.jpg");
//     return temp;
// }

function lottiePath() {
  let path = "shared://Catcher/lottie.min.js";
  let pathArr = path.split("/");
  pathArr.pop();
  let res = pathArr.join("/");
  if (!$file.exists(res)) {
    $file.mkdir(res);
  }
  return path;
}

function setTempPic(image) {
  $file.write({
    data: image.jpg(1.0),
    path: "catcherTempPic.jpg"
  });
}

function getTempPic() {
  let temp = $file.read("catcherTempPic.jpg").image;
  $file.delete("catcherTempPic.jpg");
  return temp;
}

async function getOnline() {
  Promise.all([getLottie()]);
}

async function getLottie() {
  let path = lottiePath();
  if (!$file.exists(path)) {
    console.info($l10n("本地没有lottie文件,正在下载"));
    $ui.toast($l10n("首次运行需配置环境,请稍候"), 10);
    let resp = await $http.download({
      // url: "https://cdn.jsdelivr.net/npm/lottie-web@5.3.3/build/player/lottie.min.js",//jsdelivr CDN 246 kb 会出现衔接问题
      url:
        "https://attachments-cdn.shimo.im/VeHmgU5qpywNMR1P/lottie.min.js?attname=lottie.min.js", //石墨CDN 242 kb
      // url:"https://www.lottiefiles.com/js/lottie.min.js",//lottie发放原地址 246 KB 会出现衔接问题
      timeout: 10,
      showsProgress: false
    });
    $ui.clearToast();
    let file = resp.data;
    $file.write({
      data: file,
      path: path
    });
  }
}

module.exports = {
  setTempPic: setTempPic,
  getTempPic: getTempPic,
  getLottie: getLottie,
  lottiePath: lottiePath,
  getOnline: getOnline
};
