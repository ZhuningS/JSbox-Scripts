var ui = require("scripts/uiUtil");
var handle = require("scripts/handleUtil");
var lco = require("scripts/lco");

async function ocr(sender, chosen) {
  if (chosen) {
    chosen = chosen.orientationFixedImage; //获得旋转方向修正了的图片
    console.info(chosen.info);
    let widthLimit = 5376;
    let heightLimit = 2484;
    if (chosen.info.width > widthLimit || chosen.info.height > heightLimit) {
      chosen = chosen.resized($size(widthLimit, heightLimit));
    }

    const quality = 0.0;

    if (!$("scanner")) {
      ui.loading($("mainView"));
    } else {
      ui.playLoading();
    }
    if ($("image")) {
      ui.fade($("image"));
    }
    if ($("jsboxBTN")) {
      ui.fade($("jsboxBTN"));
    }
    if ($("menuBlur")) {
      ui.fade($("menuBlur"));
    }
    if ($("picViewer")) {
      ui.fade($("picViewer"));
    }
    if ($("pickerView")) {
      ui.fade($("pickerView"));
    }
    if ($("menuBTN")) {
      ui.fade($("menuBTN"));
    }
    if ($("undoBTN")) {
      ui.fade($("undoBTN"));
    }
    if ($("collectBTN")) {
      ui.fade($("collectBTN"));
    }
    if ($("mark")) {
      ui.fade($("mark"));
    }
    $delay(1, async function () {
      //根据ui.fade的淡出时长0.3来设置此delay时间

      const undoBTN = ui.btnMaker({
        id: "undo",

        events: {
          tapped: sender => {
            lco.sfx("Facebook_Error_2");
            ui.press("undo", [70,42]);
            undo();
          },
          longPressed: sender => {
            ui.press("undo", [70,42]);
            invert($("pickerView"));
          }
        },
        lottieLayout:(make, view) => {
          make.center.equalTo(view.super);
          make.size.equalTo($size(180,180));
        },
        layout: (make, view) => {
          make.size.equalTo($size(35, 35));
          make.bottom.inset(90);
          make.right.inset(20);
        }
      });
      $("topView").add(undoBTN);
      const collectBTN = ui.btnMaker({
        id: "collect",
        scale:3,
        events: {
          tapped: sender => {
            // lco.sfx("Messenger_likePressEndLarge");//kiss的声音
            // lco.sfx("Messenger_reactions_reveal");
            lco.sfx("Messenger_payPress");
            $device.taptic(1);
            ui.press("collect", [90,188], 1.5);
            handle.editer($("pickerView"));
          }
        },
        lottieLayout:(make, view) => {
          make.center.equalTo(view.super);
          make.size.equalTo($size(180,180));
        },
        layout: (make, view) => {
          make.size.equalTo($size(35, 35));
          make.bottom.inset(35);
          make.right.inset(20);
        }
      });
      $("topView").add(collectBTN);

      const menuBlur = {
        //type:"view",
        type: "blur",
        props: {
          id: "menuBlur",
          style: 2,
          alpha: 0,
          userInteractionEnabled: true
          //bgcolor:$color('black')
        },
        layout: (make, view) => {
          make.center.equalTo(view.super);
          make.size.equalTo(view.super);
        },
        events: {
          tapped: sender => {
            clear();
            $delay(0.3, function () {
              ui.fade(sender);
            });
          }
        }
      };

      const menuBTN = ui.btnMaker({
        id: "menu",
        textSize: 12,
        events: {
          tapped: sender => {
            lco.sfx("Sorted3_Labeling");
            ui.press("menu", [73,45]);
            $device.taptic(1);
            $("topView").add(menuBlur);
            $ui.animate({
              duration: 0.3,
              animation: function () {
                $("menuBlur").alpha = 1;
              }
            });
            showMenu();
          },
          longPressed: sender => {}
        },
        // lottieLayout:(make, view) => {
        //   make.size.equalTo($size(25, 25));
        //   make.bottom.inset(90);
        //   make.left.inset(20);
        // },
        lottieLayout:(make, view) => {
          make.center.equalTo(view.super);
          make.size.equalTo($size(180,180));
        },
        layout: (make, view) => {
          make.size.equalTo($size(35, 35));
          make.bottom.inset(35);
          make.left.inset(20);
        }
      });
      $("topView").add(menuBTN);

      const picViewer = {
        type: "view",
        views: [{
          type: "image",
          props: {
            image: chosen,
            id: "image"
          },
          layout: $layout.fill
        }],
        props: {
          id: "picViewer",
          alpha: 0.0
        },
        layout: (make, view) => {
          make.height.equalTo(view);
          make.width.equalTo(view);
        }
      };

      sender.add(picViewer);

      let img = chosen.jpg(quality); //压缩图片

      // $quicklook.open(img);
      let base = $text.base64Encode(img);

      let resp = await baiduOCR(base); //有结果之后

      ui.stopLoading();

      console.info(resp.data);
      var data = resp.data.words_result;

      let results = [];
      data.forEach(e => {
        let sentence = e.words;
        sentence = sentence.replace(/\s/gm, "");
        results.push(sentence);
      });
      results = results.join("\n"); //结果无缝连接
      console.info(results);

      handle.sniffer(results);

      const mark = {
        type: "canvas",
        props: {
          id: "mark"
        },
        layout: (make, view) => {
          make.edges.equalTo(view.super);
          ui.viewsAddShadows(view);
        },
        events: {
          draw: function (view, ctx) {
            creatRectArray(ctx, data);
          }
        }
      };

      const pickerView = {
        type: "view",
        views: [],
        props: {
          id: "pickerView"
        },
        layout: function (make, view) {
          make.edges.equalTo(view.super);
        },
        events: {
          touchesBegan: (sender, location) => {
            $cache.set("count", 0);
            $cache.set("handler", true);
            slide(sender, location, $cache.get("count"), data);
          },
          touchesMoved: (sender, location) => {
            //        console.info(location);
            slide(sender, location, $cache.get("count"), data);

            // creatPath($("image"), location)
          },
          touchesEnded: (sender, location) => {
            // slide(sender, location, $cache.get("count"),data);
            $cache.set("count", 0);
            $cache.set("handler", true);
            collect(sender);
          },
          longPressed: sender => {
            // undo();
          },
          doubleTapped: sender => {
            // collectCopy(sender);
          }

          // doubleTapped: sender => {
          //   $ui.toast("双击");
          //   sender.super.updateLayout((make,view)=>{
          //     view.scale(3)
          //   });
          //   $delay(0.0, function() {
          //     $ui.animate({
          //       duration: 1,
          //       animation: function() {
          //         sender.super.relayout();
          //       },
          //     });
          //   });

          // }
        }
      };

      $("picViewer").add(mark);

      $("picViewer").add(pickerView);

      creatBTN($("pickerView"), data);

      $delay(0.0, function () {
        $("picViewer").updateLayout(function (make, view) {
          adaptByScale(make, view);
        });
        $("picViewer").relayout();
        $ui.animate({
          duration: 0.5,
          delay: 0,
          damping: 0,
          velocity: 0,
          options: 0,
          animation: function () {
            $("picViewer").alpha = 1;
          },
          completion: function () {}
        });

        ui.appear("collect", [0,90], 1);
        ui.appear("menu", [0,90], 1);

        $device.taptic(2);
        lco.sfx("snappingFingers");
        $delay(0.15, () => {
          $device.taptic(3);
        });
      });
    });
  }
}

function showMenu() {
  // const jsboxBTN = ui.btnMaker({
  //   id: "jsbox",
  //   textSize: 12,
  //   scale: 1.5,
  //   alpha: 0,
  //   circleColor: $color("clear"),
  //   events: {
  //     tapped: sender => {
  //       $app.close();
  //     },
  //     longPressed: sender => {}
  //   },
  //   layout: (make, view) => {
  //     // viewsAddShadows(view);
  //     make.size.equalTo($size(50, 50));
  //     make.top.inset(70);
  //     make.left.inset(40);
  //   },
  //   lottieEvents: {
  //     didFinish: function(sender, navigation) {
  //       $delay(0.0, function() {
  //         $ui.animate({
  //           duration: 0.3,
  //           delay: 0,
  //           damping: 0,
  //           velocity: 0,
  //           options: 0,
  //           animation: function() {
  //             $("jsboxBTN").alpha = 1;
  //           },
  //           completion: function() {}
  //         });
  //         ui.appear("jsbox", [0,128], 1, 55);
  //       });
  //     }
  //   }
  // });

  // $("topView").add(jsboxBTN);
  // $("jsboxBTN").alpha = 0;

  const lastPhoto = ui.btnMaker({
    id: "lastPhoto",
    textSize: 12,
    events: {
      tapped: sender => {
        last($("mainView"));
        lco.sfx("Teldio_pressed_down");
        $device.taptic(1);
        ui.press("lastPhoto", [54,90], 1);
        clear();
      },
      longPressed: sender => {}
    },
    layout: (make, view) => {
      make.size.equalTo($size(50, 50));
      make.bottom.inset(70);
      make.left.inset(40);
    },
    lottieEvents: {
      didFinish: function (sender, navigation) {

      }
    }
  });
  $("topView").add(lastPhoto);
  $delay(0.0, function () {
    ui.appear("lastPhoto", [0,100], 1, 60);
  });
  const pickPhoto = ui.btnMaker({
    id: "pickPhoto",
    textSize: 12,
    events: {
      tapped: sender => {
        pick($("mainView"));
        lco.sfx("Teldio_pressed_up");
        $device.taptic(1);
        ui.press("pickPhoto", [54,135], 1);
        clear();
      },
      longPressed: sender => {}
    },
    layout: (make, view) => {
      make.size.equalTo($size(50, 50));
      make.bottom.inset(70);
      make.centerX.equalTo(view.super);
    },
    lottieEvents: {
      didFinish: function (sender, navigation) {

      }
    }
  });
  $("topView").add(pickPhoto);
  $delay(0.1, function () {
    ui.appear("pickPhoto", [66,200], 1, 60);
  });
  const takePhoto = ui.btnMaker({
    id: "takePhoto",
    textSize: 12,
    events: {
      tapped: sender => {
        take($("mainView"));
        lco.sfx("Teldio_pressed_up");
        $device.taptic(1);
        ui.press("takePhoto", [54,90], 1);
        clear();
      },
      longPressed: sender => {}
    },
    layout: (make, view) => {
      make.size.equalTo($size(50, 50));
      make.bottom.inset(70);
      make.right.inset(40);
    },
    lottieEvents: {
    }
  });
  $("topView").add(takePhoto);
  $delay(0.2, function () {
    ui.appear("takePhoto", [0,128], 1, 60);
  });
}

function clear() {
  // let topArr = ["jsboxBTN"];
  // topArr.forEach(id => {
  //   $(id).updateLayout((make, view) => {
  //     make.top.inset(100);
  //   });
  // });

  let bottomArr = ["takePhotoBTN", "pickPhotoBTN", "lastPhotoBTN"];
  bottomArr.forEach(id => {
    $(id).updateLayout((make, view) => {
      make.bottom.inset(100);
    });
  });

  $ui.animate({
    duration: 0.2,
    delay: 0,
    damping: 1,
    velocity: 0,
    options: 0,
    animation: function () {
      // topArr.forEach(id => {
      //   $(id).relayout();
      // });
      bottomArr.forEach(id => {
        $(id).relayout();
      });
    },
    completion: function () {
      // topArr.forEach(id => {
      //   $(id).updateLayout((make, view) => {
      //     make.top.inset(-100);
      //   });
      // });

      bottomArr.forEach(id => {
        $(id).updateLayout((make, view) => {
          make.bottom.inset(-100);
        });
      });

      $ui.animate({
        duration: 0.4,
        delay: 0,
        damping: 0.9,
        velocity: 0,
        options: 0,
        animation: function () {
          // topArr.forEach(id => {
          //   $(id).relayout();
          // });
          bottomArr.forEach(id => {
            $(id).relayout();
          });
        },
        completion: function () {
          // topArr.forEach(id => {
          //   $(id).remove();
          // });
          bottomArr.forEach(id => {
            $(id).remove();
          });
        }
      });



      if ($("menuBTN")) {
        $("menuBTN_inside_lottie").speed = 1;
        $("menuBTN_inside_lottie").play({
            fromFrame: 42, // Optional
            toFrame: 70,
            handler: finished => {
            }
          });
      }
    }
  });
}

function take(sender) {
  $photo.take({
    handler: function (resp) {
      if (resp.image) {
        ocr(sender, resp.image);
      } else {
        showMenu();
      }
    }
  });
}

function pick(sender) {
  $photo.pick({
    handler: function (resp) {
      if (resp.image) {
        ocr(sender, resp.image);
      } else {
        showMenu();
      }
    }
  });
}

function last(sender) {
  
  $photo.fetch({
    count: 1,
    handler: function (images) {
      ocr(sender, images[0]);
    }
  });
}

async function baiduOCR(base) { //百度AI小程序方法
  return await $http.post({
    url: "https://ai.baidu.com/weapp/rest/2.0/ocr/v1/accurate", //general是能自动识别语言,accurate是准确识别
    showProcess: false,
    header: {
      "sessionKey": "efe9c802-eddd-48e9-afb0-3c59d92a8fdf=ee60b6ad-cbbe-4b1f-afcf-38c7a2378135",
      "Content-Type": "application/x-www-form-urlencoded"
    },
    body: {
      "caps_original": "true",
      "detect_direction": "true", //是否检测图像朝向，默认不检测，即：false。朝向是指输入图像是正常方向、逆时针旋转90/180/270度。可选值包括:- true：检测朝向；- false：不检测朝向。
      "probability": "true", //识别结果中每一行的置信度值，包含average：行置信度平均值，variance：行置信度方差，min：行置信度最小值
      // "detect_language":"true",//是否检测语言，默认不检测。当前支持（中文、英语、日语、韩语）
      // "vertexes_location": "true",//包含极其详细坐标信息
      "language_type": "CHN_ENG", //识别语言类型，默认为CHN_ENG。可选值包括：- CHN_ENG：中英文混合；- ENG：英文；- POR：葡萄牙语；- FRE：法语；- GER：德语；- ITA：意大利语；- SPA：西班牙语；- RUS：俄语；- JAP：日语；- KOR：韩语
      "image": base,
      // "url"://图片完整URL，URL长度不超过1024字节，URL对应的图片base64编码后大小不超过4M，最短边至少15px，最长边最大4096px,支持jpg/png/bmp格式，当image字段存在时url字段失效，不支持https的图片链接
    }
  });
}

// async function baiduOCR(base) {//自己API的方法
//   return await $http.post({
//     url:
//       "https://aip.baidubce.com/rest/2.0/ocr/v1/general?access_token=24.1b490921dce8040c1b3aebc174098fbe.2592000.1541740846.282335-14386464", //general是能自动识别语言,accurate是准确识别
//     showProcess: false,
//     header: {
//       // "Accept": "*/*",
//       // "Accept-Encoding": "br, gzip, deflate",
//       // "Accept-Language": "zh-Hans-CN;q=1, zh-Hant-CN;q=0.9, en-CN;q=0.8, ja-JP;q=0.7",
//       // "Connection": "keep-alive",
//       // "Host": "aip.baidubce.com",
//       // "User-Agent": "BaiMiao/2.2.2 (iPhone; iOS 12.0; Scale/3.00)",
//       "Content-Type": "application/x-www-form-urlencoded"
//     },
//     body: {
//       "caps_original": "true",
//       "detect_direction": "true",//是否检测图像朝向，默认不检测，即：false。朝向是指输入图像是正常方向、逆时针旋转90/180/270度。可选值包括:- true：检测朝向；- false：不检测朝向。
//       "probability":"true",//识别结果中每一行的置信度值，包含average：行置信度平均值，variance：行置信度方差，min：行置信度最小值
//       // "detect_language":"true",//是否检测语言，默认不检测。当前支持（中文、英语、日语、韩语）
//       // "vertexes_location": "true",//包含极其详细坐标信息
//       "language_type":"CHN_ENG",//识别语言类型，默认为CHN_ENG。可选值包括：- CHN_ENG：中英文混合；- ENG：英文；- POR：葡萄牙语；- FRE：法语；- GER：德语；- ITA：意大利语；- SPA：西班牙语；- RUS：俄语；- JAP：日语；- KOR：韩语
//       "image": base,
//       // "url"://图片完整URL，URL长度不超过1024字节，URL对应的图片base64编码后大小不超过4M，最短边至少15px，最长边最大4096px,支持jpg/png/bmp格式，当image字段存在时url字段失效，不支持https的图片链接
//     }
//   });
// }

function menu(sender) {
  $ui.menu({
    items: [$l10n("TAKE"), $l10n("PICK"), $l10n("LAST")],
    handler: function (title, idx) {
      switch (idx) {
        case 0:
          take(sender);
          break;
        case 1:
          pick(sender);
          break;
        case 2:
          last(sender);
          break;
        default:
          break;
      }
    },
    finished: function (cancelled) {
      if (cancelled) {
        $app.close(0.0);
      }
    }
  });
}

function creatRect(ctx, location) {
  let edge = 3;
  let x = location.left;
  let y = location.top;
  let width = location.width;
  let height = location.height;
  let rect = $rect(x, y, width, height);
  // ctx.addRect(rect);
  ctx.strokeColor = $color("tint"); //根据主题色的框
  ctx.setLineWidth(3);
  // ctx.setAlpha(0.7);
  ctx.strokeRect(rect); //对矩形进行描边。

  ctx.strokeColor = $color("white"); //外面的白框
  ctx.setLineWidth(3);
  let rectOut = $rect(x - edge, y - edge, width + edge * 2, height + edge * 2);
  ctx.strokeRect(rectOut);
  // ctx.fillRect(rect);//填充一个矩形。
}

function creatRectArray(ctx, data) {
  for (let i in data) {
    let location = data[i].location;
    creatRect(ctx, location);
  }
}

function creatBTN(SENDER, data) {
  for (let i in data) {
    let location = data[i].location;
    let markBTN = {
      type: "view",
      props: {
        id: data[i].words,
        alpha: 0,
        userInteractionEnabled: 1,
        info: false,
        bgcolor: $color("tint")
      },
      layout: (make, view) => {
        make.height.equalTo(location.height);
        make.width.equalTo(location.width);
        make.left.equalTo(location.left);
        make.top.equalTo(location.top);
      }
    };
    SENDER.add(markBTN);
  }
}

function creatPath(sender, location) {
  const path = {
    type: "canvas",
    layout: $layout.fill,
    props: {
      id: "path"
    },
    events: {
      draw: function (view, ctx) {
        ctx.strokeColor = $color("red");
        if ($cache.get("location")) {
          ctx.moveToPoint($cache.get("location").x, $cache.get("location").y);
        } else {
          ctx.moveToPoint(0, 0);
        }

        ctx.addLineToPoint(location.x, location.y);
        ctx.moveToPoint(location.x, location.y);
        $cache.set("location", location);
        ctx.setLineWidth(10);
        ctx.setLineCap(1); //butt:0,round:1,square:2
        ctx.setLineJoin(1); //butt:0,round:1,square:2
        ctx.strokePath();
      }
    }
  };
  if (!$("path")) {
    sender.add(path);
  } else {
    sender.add(path);
  }
}



function invert(sender) {
  let each = sender.views;
  for (let i in each) {
    turn(each[i]);
  }
}

function turnAll(sender, toggle) {
  let each = sender.views;
  if (toggle) {
    for (let i in each) {
      if (!each[i].info) {
        turn(each[i]);
      }
    }
  } else {
    for (let i in each) {
      if (each[i].info) {
        turn(each[i]);
      }
    }
  }
}

function collect(sender) {
  let sum = [];
  let each = sender.views;
  for (let i in each) {
    if (each[i].info) {
      sum.push(each[i].id);
    }
  }

  if (sum.length > 0) {
    ui.appear("undo", [0,38], 1);
  } else if (sum.length == 0) {
    if ($("undoText").alpha !== 0) {
      ui.disappear("undo", [42,70], 1);
    }
  }
}

function turn(sender) {
  if (!sender.info) {
    sender.info = true; //已经被选中,并点亮
    $device.taptic(0);
    $ui.animate({
      duration: 0.15,
      animation: function () {
        sender.alpha = 0.6;
      },
      completion: function () {}
    });
  } else {
    sender.info = false;
    $ui.animate({
      duration: 0.15,
      animation: function () {
        sender.alpha = 0;
      },
      completion: function () {}
    });
  }
}

function slide(sender, location, count, data) {
  let sense = 10;
  let each = sender.views;
  let n = location;

  // console.info(count)
  for (let i in each) {
    let l = data[i].location;
    let handler = $cache.get("handler");

    if (
      n.x > l.left - sense &&
      n.y > l.top - sense &&
      n.x < l.left + l.width + sense &&
      n.y < l.top + l.height + sense &&
      eval(handler)
    ) {
      if (count === 0) {
        if (each[i].info) {
          handler = "each[i].info !== false";
        } else {
          handler = "each[i].info !== true";
        }
        $cache.set("handler", handler);
      }

      turn(each[i]);
      count++;
      $cache.set("count", count);
      break;
    }
  }
}

function adaptByScale(make, view) {
  let rate;
  let height = view.frame.height;
  let width = view.frame.width;
  if (height / width > view.super.frame.height / view.super.frame.width) {
    rate = view.super.frame.height / height;
    view.scale(rate);
  } else {
    rate = view.super.frame.width / width;
    view.scale(rate);
  }
  // $ui.toast("rate:"+rate);
  make.center.equalTo(view.super);
}





function undo() {
  if ($("undoText").alpha !== 0) {
      $device.taptic(1);
      turnAll($("pickerView"), false);
      ui.disappear("undo", [42,70],1);

  }
}

module.exports = {
  menu: menu,
  ocr: ocr,
  showMenu: showMenu
  // take:take,
  // pick:pick,
  // last:last,
};