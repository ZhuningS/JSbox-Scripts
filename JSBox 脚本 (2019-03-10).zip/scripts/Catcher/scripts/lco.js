// lco 全称是 light core operation ,中文可以翻译成"轻核操作",初衷就是把一些很轻量的,但是也很核心的function封装起来方便自己使用


function doubleTaptic() { //震动两下
  $device.taptic(2);
  $delay(0.2, function () {
    $device.taptic(3)
  });
}

function singleTaptic(level) { //震动一下,默认强度是2
  let n = level ? level : 2
  $device.taptic(n);
}

async function fileTypes(name) { //file types根据后缀返回文件类型
  // let type = { //根据后缀来判断文件应该下载到哪个文件夹
  //     caf: 'audio',
  //     mp3: 'audio',
  //     ogg: 'audio',
  //     aiff: 'audio',
  //     png: 'pic',
  //     jpg: 'pic',
  //     html: 'html',
  // };

  // let content = await getCode('X4ORsoAz1rgRUyNa');
  // //eval(`var type = ${content }`)
  // let type = Function(`return ${content}`)()//Jay Zhao说后面这个好一点
  let type = $cache.get("fileTypes") ? $cache.get("fileTypes") : Function(`return` + await getCode('X4ORsoAz1rgRUyNa'))()

  let suffix = name.split('.').pop();

  return type[suffix]
}






// function ps(name,url) { //play sound,顾名思义,播放声音
//     if (url) {
//         let path = 'assets/' + fileTypes(name) + '/';
//         if ($file.exists(path + name)) {//检测是否有该文件
//             $audio.play({
//                 path: go(name)
//             });
//         } else {
//             let finalURL = getFinalUrl(url);
//             $file.mkdir(path) //创建对应分类的文件夹
//             $console.info('已创建' + path);
//             $http.download({
//                 url: finalURL,
//                 handler: function (resp) {
//                     $console.info(resp);
//                     let URL = resp.response.runtimeValue().$URL().$absoluteString().rawValue();
//                     let fileName = URL.split('/').pop(); //获取上传到石墨的文件本名
//                     $console.info(fileName);
//                     $file.write({
//                         data: resp.data,
//                         path: path + name
//                     })
//                     $console.info(name + '下载完成✅');
//                     $audio.play({
//                         path: path + name
//                     });
//                 }
//             })
//         };
//     } else {//只有名字的话,就会播放默认库

//     }
// }

async function update() {
  $cache.set("sfxDic", await getSFX('ERpBqOXKPpUoDICJ'));
  $cache.set("fileTypes", Function(`return` + await getCode('X4ORsoAz1rgRUyNa'))());
  // await getAttachment("Jh8qJ2Pu9Xc8pJUV");
  // $ui.toast("初始化完成");
  //  go("collect.json","http://t.cn/E7MYDAq");
  //  go("lastPhoto.json","http://t.cn/E7MTPS4");
  //  go("loading.json","http://t.cn/E7MT2kh");
  //  go("menu.json","http://t.cn/E7MT4Ak");
  //  go("pickPhoto.json","http://t.cn/E7MT51N");
  //  go("takePhoto.json","http://t.cn/E7MTVKG");
  //  go("undo.json","http://t.cn/E7MTxnk");
  //  go("scanner.json","http://t.cn/E7MT6Yx");
  //  go("jsbox.json","http://t.cn/E7MTCIs")


}

async function sfx(nameOrUrl) {//sound fx,顾名思义,播放声效
  let path = "shared://Catcher/assets/"
  let sfxDic = $cache.get("sfxDic") ? $cache.get("sfxDic") : Function(`return` + await getSFX('ERpBqOXKPpUoDICJ'))()

  let NAME = nameOrUrl;
  if (sfxDic[NAME]) {
    path = path + await fileTypes(sfxDic[NAME].name) + '/';
    await playOrGet(sfxDic[NAME].name, path, sfxDic[NAME].url)
  } else {
    $console.warn("库中找不到该音效:" + NAME);
    let URL = nameOrUrl;
    let finalURL = getFinalUrl(URL);
    let longURL = await $http.lengthen({ url: finalURL });
    let fileName = longURL.split('/').pop();
    path = path + await fileTypes(fileName) + '/';
    await playOrGet(fileName, path, longURL);
  };
}

async function playOrGet(fileName, path, urlOrTid) {
  if ($file.exists(path + fileName)) {
    $console.info('找到本地文件并播放');
    $audio.play({
      path: path + fileName
    });
  } else {
    $console.warn('找到不到本地文件,正准备从网上get');
    let finalURL = getFinalUrl(urlOrTid);
    let longURL = await $http.lengthen(finalURL);
    let fileName = longURL.split('/').pop();
    $file.mkdir(path)
    let resp = await $http.download(longURL);
    $file.write({
      data: resp.data,
      path: path + fileName
    })
    $audio.play({
      path: path + fileName
    });
  }
}

// async function sfx(nameOrUrl) {//sound fx,顾名思义,播放声效
//     // let sfxDic = {
//     //     DONE: 'RsbB4tq',
//     //     DELETE: 'RsA9GQk',
//     //     COPY: 'RsAy8Ot',
//     // }
//     let sfxDic = $cache.get("sfxDic")? $cache.get("sfxDic") : Function(`return`+await getCode('1XUsJDPRoXsvVQRC'))()

//     let NAME = nameOrUrl.toUpperCase();
//     if (sfxDic[NAME]) {
//         let path = 'assets/' + await fileTypes(sfxDic[NAME].name) + '/';
//         await playOrGet(sfxDic[NAME].name,path,sfxDic[NAME].tid)
//     } else {
//         let URL = nameOrUrl;
//         let finalURL = getFinalUrl(URL);
//         let longURL = await $http.lengthen({url:finalURL});
//         let fileName = longURL.split('/').pop();
//         let path = 'assets/' + await fileTypes(fileName) + '/';
//         await playOrGet(fileName,path,longURL);
//     };
// }

function getFinalUrl(url) { //所填写的网址可以是多种的
  if (url.match(/[a-zA-z]+:\/\/[^\s]*/)) { //识别为长url
    return url.match(/[a-zA-z]+:\/\/[^\s]*/)[0]
  } else if (url.match(/t\.cn[^\s]*/)) { //识别为微博短链
    return 'http://' + url.match(/t\.cn[^\s]*/)[0]
  } else { //都识别不了,那么应该就是短链的t.cn后面跟着那串ID了
    return 'http://t.cn/' + url
  }
}

async function tid(url) { //t.cn的id号
  if (url.match(/t\.cn/)) {
    return url.replace(/[a-zA-z]+:\/\/t\.cn\//, '');
  } else {
    let shorturl = await $http.shorten(url)
    return shorturl.replace(/[a-zA-z]+:\/\/t\.cn\//, '');
  }
}

async function untid(tid) {
  let shortURL = 'http://t.cn/' + tid;
  return await $http.lengthen({ url: shortURL });
}

//小白点,xiaobaidian

function at(mainView) {
  var ReplayKit = require('scripts/ReplayKit');

  // let notchAvoid = $device.isIphoneX ? 30 : 0
  // let homeIndicatorWidth = $device.isIphoneX ? 120 : 0
  // let homeIndicatorAvoid = $device.isIphoneX ? 10 : 0

  const atR = 30;//圆角圆弧半径其实等同于按钮的半径
  const atD = atR * 2;
  const activeAlpha = 1;
  const negativeAlpha = 0.5;
  const bleed = 9;
  const updownBleed = 9;
  const updownSense = 80;
  //const moveSense = 10;//感应移动的距离

  // let animator;
  // $delay(1, function () {
  //   animator = $('assistiveTouch').animator;
  // });


  let homeIndicatorWidth, homeIndicatorAvoid
  let screenHeight, screenWidth;
  let notchWidth, notchAvoid;

  $delay(0, function () {

    screenHeight = mainView.frame.height;
    screenWidth = mainView.frame.width;
    [notchWidth, notchAvoid] = screenWidth == 375 && screenHeight == 812 ? [200, 25] : [0, 0];//不是满屏就可以不用躲避
    [homeIndicatorWidth, homeIndicatorAvoid] = $device.isIphoneX ? [120, 10] : [0, 0];
  });


  const recordBTN = {
    type: "button",
    props: {
      id: 'recordBTN',
      icon: $icon("035", $color("white"), $size(40, 40)),
      bgcolor: $color('clear'),
      alpha: 0.5
    },
    layout: (make, view) => {
      make.center.equalTo($('assistiveTouch'))
    },
    events: {
      tapped: (sender) => {
        sfx('PullDown');
        ReplayKit.record();
      },
      touchesBegan: (sender, location) => {
        $device.taptic(0);
      },
      longPressed: (sender) => {
        $device.taptic(2);
        if ($app.env === $env.today) {
          $ui.toast("小挂件不能关闭程序");
        } else {
          $app.close(0);
        }
      }
    }
  }

  const touchBlur = {
    //type:"view",
    type: "blur",
    props: {
      id: 'touchBlur',
      style: 2,
      alpha: 1,
      //bgcolor:$color('black')
    },
    layout: (make, view) => {
      make.center.equalTo(view.super)
      make.size.equalTo(view.super)

    }
  }

  //openWin之后的阻隔层
  const blank = {
    type: 'view',
    props: {
      id: 'blank',
      bgcolor: $color('clear'),
      userInteractionEnabled: true,
    },
    layout: $layout.fill,
    events: {
      tapped: (sender) => {
        closeWin($('assistiveTouch'));
        BTN(0);
        sender.remove();
      }
    }
  }

  //const screenHeight = $device.info.screen.height;const screenWidth = $device.info.screen.width;





  const assistiveTouch = {
    type: "view",
    views: [touchBlur],
    props: {
      id: "assistiveTouch",
      alpha: negativeAlpha,
      bgcolor: $color("clear"),
      userInteractionEnabled: true,
      clipsToBounds: true//是否裁剪子 view
    },
    layout: (make, view) => {

      roundedCorner(view)
      let endLocation = $cache.get("endLocation");
      if (endLocation) {
        make.center.equalTo(endLocation);
      } else {
        $console.info("at:没有endLocation");
        make.center.equalTo(view.super);
      }
      make.width.height.equalTo(atD);
    },
    events: {
      tapped: (sender) => {
        sfx('bubble');

        mainView.add(blank);
        BTN(1);
        $delay(0, function () {
          openWin(sender);
        });


      },
      touchesBegan: (sender, location) => {

        getOffset(sender, location);
        active(sender);
      }
      ,
      touchesMoved: (sender, location) => {
        moveAT(sender, location);
      },
      touchesEnded: (sender, location) => {

        auto(sender, location);
        negative(sender);


      }
    }
  };



  //function shouldMove(sender, location){
  //  if(Math.abs( location.x - sender.frame.width/2 ) > moveSense || Math.abs( location.y - sender.frame.height/2  ) > moveSense){
  //    $cache.set("shouldMove", true);
  //  }
  //}

  function BTN(openOrClose) {
    if (openOrClose) {
      mainView.add(recordBTN);
      $ui.animate({
        duration: 0.4,
        delay: 0,
        damping: 0,
        velocity: 0,
        options: 0,
        animation: function () {
          ['recordBTN'].forEach(id => { $(id).alpha = 1 });

        },
        completion: function () {

        }
      });
    } else {
      $ui.animate({
        duration: 0.3,
        delay: 0,
        damping: 0,
        velocity: 0,
        options: 0,
        animation: function () {
          $('recordBTN').alpha = 0;
        },
        completion: function () {
          ['recordBTN'].forEach(id => { $(id).remove() });
        }
      });
    }
  }

  function getOffset(sender, location) {
    let x = location.x - sender.frame.width / 2;
    let y = location.y - sender.frame.height / 2;
    $cache.set("beganOffset", { x: x, y: y });
  }

  function active(sender) {
    $ui.animate({
      duration: 0.2,
      animation: () => {
        sender.alpha = activeAlpha;
      }
    })
  }

  function negative(sender) {
    $delay(4, function () {
      if (!$cache.get("hasOpened")) {
        $ui.animate({
          duration: .3,
          animation: () => {
            sender.alpha = negativeAlpha;
          }
        })
      }
    })
  }

  function roundedCorner(view) {
    //在layout中使用即可 给Views添加圆角
    let layer = view.runtimeValue().invoke("layer");
    layer.invoke("setCornerRadius", atR);
  }

  function viewsAddShadows(view) {
    //在layout中使用即可 给Views添加阴影
    let layer = view.runtimeValue().invoke("layer");
    layer.invoke("setCornerRadius", atR);
    layer.invoke("setShadowRadius", 10);
    layer.invoke("setShadowOpacity", 0.8);
    layer.invoke("setShadowOffset", $size(0, 3));
    layer.invoke(
      "setShadowColor",
      $color("gray")
        .runtimeValue()
        .invoke("CGColor")
    );
  }

  function magnet(sender, location) {
    let endLocation = {
      x: location.x - screenWidth / 2,
      y: location.y - screenHeight / 2
    }
    $cache.set("endLocation", endLocation);

    $delay(0, function () {
      sender.updateLayout(function (make, view) {
        make.centerX.equalTo(endLocation.x)
        make.centerY.equalTo(endLocation.y)
      })
      $ui.animate({
        duration: 0.2,
        damping: 0,
        velocity: 0,
        animation: () => {
          sender.relayout()
        }
      })
    });

  }

  function auto(sender, location) {
    let centerX = sender.frame.x + atR; //中心点x
    let centerY = sender.frame.y + atR; //中心点y
    //$console.info(centerX,centerY);
    //$console.info("at:开始运行auto");
    let position;
    if (centerY <= updownSense) {
      if (centerX < bleed + atR) {
        $console.info("at:左上");
        position = {
          x: bleed + atR,
          y: updownBleed + atR
        }
      } else if (centerX > screenWidth - atD - bleed) {
        $console.info("at:右上");
        position = {
          x: screenWidth - (bleed + atR),
          y: updownBleed + atR
        }
      } else {
        if (centerX > screenWidth / 2 - notchWidth / 2 - atR && centerX < screenWidth / 2 + notchWidth / 2 + atR) {
          $console.info("at:Notch躲避");
          position = {
            x: centerX,
            y: updownBleed + atR + notchAvoid
          }
        } else {
          $console.info("at:上");
          position = {
            x: centerX,
            y: updownBleed + atR
          }
        }
      }
    } else if (centerY > screenHeight - updownSense) {
      if (centerX < atD + bleed) {
        $console.info("at:左下");
        position = {
          x: bleed + atR,
          y: screenHeight - (updownBleed + atR)
        }
      } else if (centerX > screenWidth - atD - bleed) {
        $console.info("at:右下");
        position = {
          x: screenWidth - (bleed + atR),
          y: screenHeight - (updownBleed + atR)
        }
      } else {
        //home indicator位置躲避
        if (centerX > screenWidth / 2 - homeIndicatorWidth / 2 - atR && centerX < screenWidth / 2 + homeIndicatorWidth / 2 + atR) {
          $console.info("at:Home Indicator躲避");
          position = {
            x: centerX,
            y: screenHeight - (updownBleed + atR + homeIndicatorAvoid)
          }
        }
        else {
          $console.info("at:下");
          position = {
            x: centerX,
            y: screenHeight - (updownBleed + atR)
          }
        }
      }
    } else if (centerX <= screenWidth / 2) {
      $console.info("at:左");
      position = {
        x: bleed + atR,
        y: centerY
      }
    } else if (centerX > screenWidth / 2) {
      $console.info("at:右");
      position = {
        x: screenWidth - (bleed + atR),
        y: centerY
      }
    }
    magnet(sender, position)
  }

  function moveAT(sender, location) {
    let beganOffset = $cache.get("beganOffset");

    let { x, y } = sender.frame;
    x += location.x - beganOffset.x;
    y += location.y - beganOffset.y;

    sender.updateLayout(function (make, view) {
      make.centerX.equalTo(x - screenWidth / 2)
      make.centerY.equalTo(y - screenHeight / 2)
    })
    $ui.animate({
      duration: .001,
      damping: 0,
      velocity: 100,
      animation: () => {
        sender.relayout()
      }
    })

  }

  function openWin(sender) {
    $cache.set("hasOpened", true);

    let winSize = screenWidth < screenHeight ? screenWidth * 0.79 : screenHeight * 0.79;
    let centerY = sender.frame.y + atR; //中心点y

    let inset = updownBleed;//上下两边出血
    //上下两边限制
    let yMin = 0 + atR + inset + winSize / 2 + notchAvoid;
    let yMax = screenHeight - atR - inset - winSize / 2;

    let y = centerY < yMin ? yMin : (centerY > yMax ? yMax : centerY)

    sender.updateLayout(function (make, view) {
      make.centerX.equalTo(0);
      make.centerY.equalTo(y - screenHeight / 2)
      make.size.equalTo(winSize, winSize)
    })
    $ui.animate({
      duration: .4,
      damping: 1,
      velocity: 1,
      animation: () => {
        sender.relayout()
      }
    })
    active(sender)
  }

  function closeWin(sender) {
    sender.updateLayout(function (make, view) {
      make.size.equalTo($size(atD, atD))
      let endLocation = $cache.get("endLocation")//打开上次一次储存的位置缓存

      if (endLocation !== undefined) {
        make.centerX.equalTo(endLocation.x)
        make.centerY.equalTo(endLocation.y)
      }
      else {
        make.centerX.equalTo(view.super).offset(0)
        make.centerY.equalTo(view.super).offset(0)
      }
    })
    $ui.animate({
      duration: .4,
      damping: 5,
      velocity: 10,
      animation: () => {
        sender.relayout()
      }
    })
    $cache.set("hasOpened", false);
    negative(sender)
  }

  mainView.add(assistiveTouch)

  $delay(0.3, function () {
    let endLocation = $cache.get("endLocation");
    if (endLocation) {
      $
      auto($('assistiveTouch'))//初始化assistiveTouch的位置
    } else {
      //第一次使用at的动画提醒
      $ui.animate({
        duration: 0.8,
        delay: 0,
        damping: 0.3,
        velocity: 0,
        options: 0,
        animation: function () {
          $('assistiveTouch').scale(1.5)
        },
        completion: function () {
          $ui.animate({
            duration: 0.8,
            delay: 0,
            damping: 0.4,
            velocity: 0,
            options: 0,
            animation: function () {

              $('assistiveTouch').scale(1)
              $('assistiveTouch').updateLayout(function (make, view) {
                make.centerX.equalTo(screenWidth / 8)
                make.centerY.equalTo(screenHeight / 4)
              })
              $ui.animate({
                duration: .4,
                damping: 5,
                velocity: 10,
                animation: () => {
                  $('assistiveTouch').relayout()
                }
              })
              auto($('assistiveTouch'))
            },
            completion: function () {

            }
          });
        }
      });
    }
  });

}

//↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓以下全都是shimo的API↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓//



async function getCookie() {
  let cookie = await getCode('');
  let clearCookie = cookie.match(/\S+/)[0];
  return clearCookie;
}

async function creat(type, name, folder, cookieShimo) {
  let cookie = cookieShimo ? cookieShimo : await getCookie()
  let resp = await $http.post({
    url: "https://shimo.im/lizard-api/files",
    header: {
      'Content-Type': 'application/json',
      'Cookie': cookie,
      'Referer': 'https://shimo.im/dashboard/updated',
      'X-PUSH-CLIENT-ID': 'ad60616d-8f21-4954-b180-f9b4fdfe792f'
    },
    body: {
      "type": type,
      "name": name,
      "folder": folder
    }
  });
  let data = resp.data;


  if (data.error) {
    return {
      'operation': false,
      'feedback': data.error
    }
  }
  else {
    return {
      'operation': true,
      'feedback': data.url
    }
  }

}
async function getFolderList(folderID, cookieShimo) {
  let cookie = cookieShimo ? cookieShimo : await getCookie()
  let resp = await $http.get({
    url: "https://shimo.im/lizard-api/files?collaboratorCount=true&folder=" + folderID,
    header: {
      "Cookie": cookie,
      "Referer": 'https://shimo.im/folder/' + folderID
    }
  });
  return resp.data;
}
async function checkUpdate(fileID, cookieShimo) {
  let cookie = cookieShimo ? cookieShimo : await getCookie()
  var resp = await $http.get({
    url: "https://shimo.im/smapi/files/" + fileID + "/revisions",
    header: {
      "Cookie": cookie,
    }
  });

  var data = resp.data['data'];
  var verSumNew = data.length;

  try {
    var verSumOld = $cache.get("heartBeat");
  }
  catch (e) {
    var verSumOld = '0';
  }

  if (verSumNew > verSumOld) {//发现石墨已经保存了一个新的版本
    $device.taptic(2);
    $ui.toast("已同步", 1);
    $ui.popToRoot();
    run(fileID);
    $delay(1, function () {
      $device.taptic(2);
    });
  }
  $cache.set("heartBeat", verSumNew)
  return verSumNew;

}
async function getName(fileID) {

  let resp = await $http.get("https://api.shimo.im/files/" + fileID + "?content=true");
  if (!resp.data.content) {
    if ($cache.get("hasAlerted")) {

    } else {
      $ui.alert({
        title: "⚠️此文档不公开",
        message: "正在尝试为你开启...",
      });
      $cache.set("hasAlerted", true);
    }
    //$console.info("找不到脚本内容");
    shareEditable(fileID)
    //      $ui.alert({
    //        title: "⚠️请公开石墨文档",
    //        message: "即将自动转跳......",
    //      });
    //      //$ui.loading("⚠️\n请公开石墨文档\n"+"即将自动转跳......");
    //      $delay(1, function() {
    //        $ui.loading(false);
    //        $app.openURL("shimo://docs/"+fileID);
    //        var resumeAction = 3;
    //        $thread.background({
    //               delay: 0.1,
    //               handler: function() {
    //                 if(resumeAction == 3) {
    //                   resumeAction = 0
    //                   $ui.toast("未安装石墨APP")
    //                 }
    //            }
    //      });
    // });
    return {
      result: false,
      name: 'none'
    }

  }
  else {

    return {
      result: true,
      name: resp.data.name
    }
  }
}

async function getCode(fileID) {
  getName(fileID)
  let respGetCode = await $http.get("https://api.shimo.im/files/" + fileID + "?content=true");

  var scriptCode = "";
  var orig = JSON.parse(respGetCode.data.content);

  for (var i = 0; i < orig.length; i++) {
    scriptCode += orig[i][1];
  }

  return scriptCode;
}

async function getAttachment(fileID) {//获取全部附件,整理成一份列表
  getName(fileID)
  $http.get({
    url:"https://api.shimo.im/files/" + fileID + "?content=true",
    handler:(resp)=>{
      var attachmentsList = [];
      var orig = JSON.parse(resp.data.content);
      for (var i = 0; i < orig.length; i++) {
        let attachment = orig[i][1].attachment
        if (attachment) {
          attachmentsList.push(attachment);
          var name = attachment.name;
          var url = attachment.url;
          go(name, url);
        }
      }
    }
  });


 
}

async function go(name, url) { //GO的完整写法是getAssetsFromShimo,也可以理解成是get object,只写name的话会返回path
  let root = 'shared://Catcher/assets/';
  // let path = root + await fileTypes(name) + '/';
  let path = root + await fileTypes(name) + '/';
    if ($file.exists(path + name)) {
      $console.info(name + '存在，不用下载✅');
    } else {
      $console.info(name + '不存在，正在下载💾');
      let finalURL = getFinalUrl(url);
      $console.info("final URL为:" + finalURL);
      if (!$file.exists(root)) { //默认检测是否存在assets文件夹
        $file.mkdir(root);
        $console.info('已创建assets');
      }
      if (!$file.exists(path)) { //默认检测是否存在对应类型的文件夹
        $file.mkdir(path);
        $console.info('已创建' + path);
      }
      $http.download({
        url: finalURL,
        handler:(resp)=>{
          $console.info(resp);
          let URL = resp.response.runtimeValue().$URL().$absoluteString().rawValue();
          let fileName = URL.split('/').pop(); //获取上传到石墨的文件本名
          $console.info(fileName);
          $file.write({
            data: resp.data,
            path: path + name
          })
          $console.info(name + '下载完成✅');
        }
      })
    }
}

async function getSFX(fileID) {//获取全部附件
  getName(fileID)
  let respGetCode = await $http.get("https://api.shimo.im/files/" + fileID + "?content=true");

  var DIC = {};
  var attachmentsList = [];
  var orig = JSON.parse(respGetCode.data.content);

  for (var i = 0; i < orig.length; i++) {
    var attachment = orig[i][1].attachment
    if (attachment) {
      attachmentsList.push(attachment);
      var name = attachment.name;
      var url = attachment.url;
      var NAME = name.split('.');
      var suffix = NAME.pop();
      NAME = NAME.join('.');
      //var dic = `{${NAME}:{name:'${name}',url:'${url}'}}`;
      DIC[NAME] = { name: name, url: url };
    }
  }
  return DIC;
}

async function setup(fileID) {

  let scriptName = await getName(fileID);
  if (scriptName.result) {
    let hasSave = await $addin.save({
      name: scriptName.name,
      data: $data({ string: await getCode(fileID) }),
      handler: async function (success) {
        if (succes) {
          $device.taptic(2);
          $delay(0.2, function () {
            $device.taptic(3)
          });

        }
        return scriptName.name
      }
    });

  } else {
    return false
  }
}
async function runLocal(fileID) {
  let json = await getName(fileID);
  let name = json["name"];
  $addin.run(name);
}
async function RUN(fileID) {
  let name = await setup(fileID);

  if (name) {
    $ui.toast(name + "已安装到本地");
    //runLocal(fileID)
  }
}
async function run(fileID) {
  // setup(fileID)
  // runLocal(fileID)
  let code = await getCode(fileID)
  // eval(code.script());                                
  //new Function()($addin.eval(code.script()))            
  //new Function()($addin.eval(code.replace('$' + 'ui.render', '$' + 'ui.push')))    
  // $addin.eval(code)                                   
  //new Function(code.script())()                        
  //$addin.eval(code.replace('$' + 'ui.render', '$' + 'ui.push'))
  //new Function($addin.eval(code.replace("$" + "ui.render", "$" + "ui.push")))()
  new Function($addin.compile(code.replace("$" + "ui.render", "$" + "ui.push")))()
}
async function shareEditable(fileID, cookieShimo) {
  let cookie = cookieShimo ? cookieShimo : await getCookie()
  let resp = await $http.request({
    method: "PATCH",
    url: "https://shimo.im/smapi/files/" + fileID,
    header: {
      'Cookie': cookie
    },
    body: {
      'shareMode': 'editable'
    },
  });
  let data = resp.data;

  return data
}
async function shareReadonly(fileID, cookieShimo) {
  let cookie = cookieShimo ? cookieShimo : await getCookie()
  let resp = await $http.request({
    method: "PATCH",
    url: "https://shimo.im/smapi/files/" + fileID,
    header: {
      'Cookie': cookie
    },
    body: {
      'shareMode': 'readonly'
    },
  });
  let data = resp.data;
  return data
}
async function sharePrivate(fileID, cookieShimo) {
  let cookie = cookieShimo ? cookieShimo : await getCookie()
  let resp = await $http.request({
    method: "PATCH",
    url: "https://shimo.im/smapi/files/" + fileID,
    header: {
      'Cookie': cookie
    },
    body: {
      'shareMode': 'private'
    },
  });
  let data = resp.data;
  return data
}

async function getToken() {
  if ($app.env == $env.action) {
    var tokenCache = $cache.get("shimoToken")
    if (tokenCache) {
      $console.info("sm:已发现token缓存并加载");
      return tokenCache
    }
  } else {
    try {
      var resp = await $http.post({
        url: "https://shimo.im/api/upload/token",
        header: {
          'Cookie': await getCookie(),
        },
      });
      $cache.set("shimoToken", resp.data.data.accessToken);
      $console.info("sm:拿到新的token并缓存");
      return resp.data.data.accessToken;
    } catch (e) {
      $console.warn("sm:拿不到新的token，只能使用缓存token");
      tokenCache = $cache.get("shimoToken")
      if (tokenCache) {
        $console.info("sm:已发现token缓存并加载");
        return tokenCache
      } else {
        $console.warn("sm:找不到缓存token");
        $input.text({
          type: $kbType.default,
          placeholder: "请手动填写token",
          text: "",
          handler: function (text) {
            $cache.set("shimoToken", text);
            return text
          }
        });
      }
    }
  }
}
//↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑以上全都是shimo的API↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑//










module.exports = {
  dt: doubleTaptic,
  st: singleTaptic,
  go: go,
  tid: tid,
  sfx: sfx,
  untid: untid,
  update: update,
  at: at,

  creat: creat,
  getFolderList: getFolderList,
  checkUpdate: checkUpdate,
  getName: getName,
  getCode: getCode,
  getAttachment: getAttachment,
  setup: setup,
  runLocal: runLocal,
  RUN: RUN,
  run: run,
  shareEditable: shareEditable,
  shareReadonly: shareReadonly,
  sharePrivate: sharePrivate,
  getToken: getToken,
  getSFX: getSFX


}