By [JunM](https://t.me/jun_m)

功能：<br><br>
聚合搜索。<br><br>


使用说明：

直接在 JSBox 中运行或从选中文本后从分享菜单中运行。<br><br>





安装链接：

[JSBox 安装链接](https://xteko.com/redir?name=1Search&url=https%3A%2F%2Fgithub.com%2Fmjyspace%2FJSBox%2Fblob%2Fmaster%2F1Search%2F.output%2F1Search.box%3Fraw%3Dtrue&author=JunM)