console.clear()
console.log('开始调试...')

const _indexView = require('scripts/indexView')

_indexView.render()
