var app = require("scripts/app");
require("scripts/actionInputTool");

$app.autoKeyboardEnabled = true;

var actionInputTool = $objc("ActionInputTool")
  .$alloc()
  .$init();

$app.listen({
  ready: function() {
    actionInputTool.$addObserver();
  },
  exit: function() {
    actionInputTool.$removeObserver();
  }
});

app.show();


