var helper = require("./helper");

class Flow {
  constructor(data) {
    this.variables = {};
    data = data || [];
    this.actions = data.map(values => {
      var Action = require("./actions/action_" + values.action);
      var action = new Action(values);
      return action;
    });
  }

  exchangeAction(index1, index2) {
    helper.exchange(this.actions, index1, index2);
  }

  insertAction(index, action) {
    this.actions.splice(index, 0, action);
  }

  removeAction(action) {
    var index = this.actions.indexOf(action);
    if (index > -1) {
      this.actions.splice(index, 1);
    }
    return index;
  }

  update() {
    this.actions.forEach(action => {
      action.update();
    });
  }

  getData() {
    var data = [];
    this.actions.forEach(action => {
      var actionData = {
        action: action.values.action,
        variableName: action.values.variableName,
        params: {}
      };
      for (var param in action.config.params) {
        if (action.config.params[param] == "Flow") {
          actionData.params[param] = action.values.params[param].getData();
        } else {
          actionData.params[param] = action.values.params[param];
        }
      }
      data.push(actionData);
    });
    return data;
  }

  dealloc() {
    this.actions.forEach(action => {
      for (var key in action.config.params) {
        if (action.config.params[key] == "Flow") {
          var flow = action.values.params[key];
          flow.dealloc();
        }
      }
    });
    this.actions.length = 0;
  }
}

module.exports = Flow;
