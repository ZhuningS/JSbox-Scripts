var Flow = require("./flow");
var Action = require("./action");
var Worker = require("./worker");
var FlowView = require("./flowView");
var settings = require("./settings");
var notificationCenter = require("scripts/notificationCenter");

$objc("UIImageView");

function changeSaveButtonState(isSave) {
  var icon = $icon("064", $color("#ffffff"), $size(22, 22));
  var btn = $("saveButton");
  btn.title = isSave ? "Save" : "";
  btn.icon = isSave ? null : icon;
}

class WorkflowEditor {
  constructor(workflow) {
    this.workflow = workflow;

    this.worker = new Worker();

    this.worker.workEnded = this.workEnded.bind(this);
    this.worker.flowBegin = this.flowBegin.bind(this);
    this.worker.flowEnded = this.flowEnded.bind(this);
    this.worker.actionBegin = this.actionBegin.bind(this);

    notificationCenter.addObserver(
      this,
      Action.eventIds.toChildFlow,
      this.actionEventHandler.bind(this)
    );

    notificationCenter.addObserver(
      this,
      Action.eventIds.changedHeight,
      this.actionEventHandler.bind(this)
    );

    notificationCenter.addObserver(
      this,
      Action.eventIds.tappedInsertButton,
      this.actionEventHandler.bind(this)
    );

    notificationCenter.addObserver(
      this,
      Action.eventIds.tappedRemoveButton,
      this.actionEventHandler.bind(this)
    );

    this.childFlowViews = [];
  }

  actionEventHandler(name, userInfo) {
    switch (name) {
      case Action.eventIds.toChildFlow:
        var flowView = new FlowView(userInfo);
        this.push(flowView);
        break;
      case Action.eventIds.tappedInsertButton:
        this.currentFlowView.insert(userInfo);
        break;
      case Action.eventIds.tappedRemoveButton:
        this.currentFlowView.remove(userInfo);
        break;
      case Action.eventIds.changedHeight:
        this.currentFlowView.refreshHeight();
        break;
    }
  }

  start() {
    $("mainView").userInteractionEnabled = false;
    $("mainScrollView").userInteractionEnabled = false;
    $("saveButton").hidden = true;
    $("settingsButton").hidden = true;
    $("workButton").icon = $icon("016", $color("#ffffff"), $size(26, 26));
    this.workflow.flow.update();
    this.popToRoot(
      function() {
        this.currentFlowView.listView.scrollToOffset($zero.point);
        this.worker.work(this.workflow.flow);
        $("mainView").userInteractionEnabled = true;
      }.bind(this)
    );
  }

  async workEnded(worker, flow, output) {
    $("saveButton").hidden = false;
    $("settingsButton").hidden = false;
    $("workButton").icon = $icon("049", $color("#ffffff"), $size(26, 26));
    $("mainScrollView").userInteractionEnabled = true;
  }

  async flowBegin(flow) {
    return new Promise(
      function(resolve, reject) {
        if (this.currentFlowView.flow != flow) {
          var flowView = new FlowView(flow);
          this.push(flowView);
        }
        $delay(1, () => {
          resolve();
        });
      }.bind(this)
    );
  }

  async flowEnded(flow) {
    return new Promise(
      function(resolve, reject) {
        this.pop();
        $delay(1, () => {
          resolve();
        });
      }.bind(this)
    );
  }

  async actionBegin(flow, action) {
    var index = this.currentFlowView.flow.actions.indexOf(action);
    if (index > -1) {
      this.currentFlowView.listView.scrollTo({
        indexPath: $indexPath(0, index)
      });
    }
  }

  //获取当前工作流
  get currentFlowView() {
    return this.childFlowViews[this.childFlowViews.length - 1];
  }

  //显示工作流
  push(flowView) {
    var mainScrollView = $("mainScrollView");
    mainScrollView.runtimeValue().$addSubview(flowView.view);
    this.childFlowViews.push(flowView);
    mainScrollView.scrollToOffset(
      $point((this.childFlowViews.length - 1) * mainScrollView.frame.width, 0)
    );

    if (this.childFlowViews.length > 1 && !this.worker.working) {
      changeSaveButtonState(false);
    }
  }

  //退出工作流
  pop() {
    var mainScrollView = $("mainScrollView");
    if (this.childFlowViews.length > 1) {
      var flowView = this.childFlowViews.pop();
      flowView.flow.update();
      mainScrollView.scrollToOffset(
        $point((this.childFlowViews.length - 1) * mainScrollView.frame.width, 0)
      );

      $thread.main({
        delay: 0.5,
        handler: () => {
          flowView.view.remove();
        }
      });

      if (this.childFlowViews.length == 1) {
        changeSaveButtonState(true);
      }
    }
  }

  //退出到根工作流
  popToRoot(completion) {
    var mainScrollView = $("mainScrollView");
    mainScrollView.scrollToOffset($point(0, 0));
    $thread.main({
      delay: 0.5,
      handler: function() {
        while (this.childFlowViews.length > 1) {
          var flowView = this.childFlowViews.pop();
          flowView.flow.update();
          flowView.view.remove();
        }
        completion();
      }.bind(this)
    });
    changeSaveButtonState(true);
  }

  //显示主视图
  show() {
    var self = this;
    $ui.push({
      type: "view",
      props: {
        id: "mainView",
        title: self.workflow.name
      },
      events: {
        dealloc: () => {
          self.childFlowViews.forEach(flowView => {
            flowView.flow.dealloc();
            flowView.flow = null;
          });
          self.workflow.flow.dealloc();
          notificationCenter.removeObserver(self);
        }
      },
      views: [
        {
          type: "view",
          props: {
            bgcolor: $color("tint")
          },
          layout: (make, view) => {
            make.left.top.right.inset(0);
            make.height.equalTo(45);
          },
          views: [
            {
              type: "button",
              props: {
                id: "dataTableButton",
                icon: $icon("067", $color("#ffffff"), $size(22, 22))
              },
              layout: (make, view) => {
                make.size.equalTo($size(45, 45));
                make.top.inset(0);
                make.left.inset(10);
              },
              events: {
                tapped: sender => {
                  self.workflow.dataTable.show();
                }
              }
            },
            {
              type: "button",
              props: {
                id: "settingsButton",
                icon: $icon("002", $color("#ffffff"), $size(22, 22))
              },
              layout: (make, view) => {
                make.size.equalTo($size(45, 45));
                make.top.inset(0);
                make.left.equalTo(view.prev.right).offset(10);
              },
              events: {
                tapped: sender => {
                  settings.show(self.workflow, () => {
                    $("mainView")
                      .runtimeValue()
                      .$nextResponder()
                      .$nextResponder()
                      .$setTitle(self.workflow.name);
                  });
                }
              }
            },
            {
              type: "button",
              props: {
                id: "workButton",
                icon: $icon("049", $color("#ffffff"), $size(26, 26))
              },
              layout: (make, view) => {
                make.size.equalTo($size(45, 45));
                make.center.equalTo(view.super);
              },
              events: {
                tapped: sender => {
                  //开始运行或退出
                  if (self.worker.working) {
                    self.worker.exit();
                  } else {
                    self.start();
                  }
                }
              }
            },
            {
              type: "button",
              props: {
                id: "saveButton",
                title: "Save"
              },
              layout: (make, view) => {
                make.size.equalTo($size(45, 45));
                make.right.inset(10);
                make.centerY.equalTo(view.super);
              },
              events: {
                tapped: sender => {
                  if (self.childFlowViews.length == 1) {
                    self.workflow.save();
                    $ui.toast("(✌ﾟ∀ﾟ)☞ Saved");
                  } else {
                    self.pop();
                  }
                }
              }
            }
          ]
        },
        {
          type: "scroll",
          props: {
            id: "mainScrollView",
            alwaysBounceVertical: false,
            showsHorizontalIndicator: false,
            alwaysBounceHorizontal: true,
            pagingEnabled: true,
            bgcolor: $color("#dddddd"),
            scrollEnabled: false
          },
          layout: (make, view) => {
            make.left.right.bottom.inset(0);
            make.top.equalTo(view.prev.bottom);
          },
          events: {
            layoutSubviews: sender => {
              //更新视图位置和滚动范围
              var x = 0;
              for (var i in sender.views) {
                var view = sender.views[i];
                if (
                  !view
                    .runtimeValue()
                    .$isKindOfClass(UIImageView.invoke("class"))
                ) {
                  view.frame = $rect(
                    x,
                    0,
                    sender.frame.width,
                    sender.frame.height
                  );
                  x += sender.frame.width;
                }
              }
              sender.contentSize = $size(x, 0);
            }
          }
        }
      ]
    });

    //显示主工作流
    var mainFlowView = new FlowView(this.workflow.flow);
    this.push(mainFlowView);
  }
}

module.exports = WorkflowEditor;
