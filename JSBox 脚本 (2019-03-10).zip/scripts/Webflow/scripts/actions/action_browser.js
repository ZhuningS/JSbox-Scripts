var Action = require("../action");
var Browser = require("../browser");
var helper = require("../helper");

function showBrowser(browser, showed) {
  helper.showView(
    "Browser",
    {
      type: "runtime",
      props: {
        view: browser.webView
      },
      layout: $layout.fill
    },
    function() {
      browser.webView.runtimeValue().$removeFromSuperview();
    }
  );
}

class Action_browser extends Action {
  constructor(values) {
    super(values);
    this.browser = new Browser();
  }

  get config() {
    return {
      title: "Browser",
      privateVaribaleName: "$Browser",
      params: {
        "URL": "String",
        "UA": "Custom",
        "Show Browser": "Bool",
        "Flow": "Flow"
      }
    };
  }

  updateParam(param) {
    if (param == "UA") {
      var valueView = $(this.id)
        .get(param)
        .get("valueView");
      var value = valueView.items[valueView.index];
      this.values.params[param] = value;
    } else {
      super.updateParam(param);
    }
  }

  getParamChildViewObjects(param) {
    if (param == "UA") {
      var value = this.values.params[param];
      return Action.createTabViewObjects(param, value, ["PC", "Mobile"]);
    }

    return super.getParamChildViewObjects(param);
  }

  getParamViewHeight(param) {
    if (param == "UA") {
      return 50;
    }
    return super.getParamViewHeight(param);
  }

  getParamViewTappedHandler(param) {
    if (param == "Show Browser") {
      return function() {
        showBrowser(this.browser);
        var actionView = $(this.id);
        var url = actionView.get("URL").get("valueView").text;
        var urls = $detector.link(url);
        if (urls.length > 0) {
          var ua = actionView.get("UA").get("valueView").index;
          this.browser.setPC(ua == 0);
          this.browser.open(urls[0]);
        }
      }.bind(this);
    }
    return super.getParamViewTappedHandler(param);
  }

  async handler(worker, flow, input, params) {
    var isShowBrowser = params["Show Browser"];
    if (isShowBrowser) {
      showBrowser(this.browser);
    }

    var ua = params["UA"];
    this.browser.setPC(ua == "PC");

    var urls = $detector.link(params["URL"]);
    if (urls.length > 0) {
      await this.browser.open(urls[0]);
    }

    var browserFlow = params["Flow"];

    for (var key in flow.variables) {
      browserFlow.variables[key] = flow.variables[key];
    }
    browserFlow.variables[this.config.privateVaribaleName] = this.browser;

    await worker.flowBegin(browserFlow);

    var i = 0;
    var count = browserFlow.actions.length;
    var self = this;
    var output = await worker.runFlow(browserFlow, null, async action => {
      i++;
      var p = i / count;
      if (p < 1) {
        await self.progressUpdate(worker, flow, p);
      }
    });

    var parentVariableKeys = Object.keys(flow.variables);
    for (var key in browserFlow.variables) {
      if (parentVariableKeys.indexOf(key) > -1) {
        flow.variables[key] = browserFlow.variables[key];
      }
    }

    await worker.flowEnded(browserFlow);

    return output;
  }
}

module.exports = Action_browser;
