var Action = require("../action");

class Action_getItemOfList extends Action {
  get config() {
    return {
      title: "Get Item Of List",
      params: {
        "Get": "Custom",
        "Index": "Number"
      }
    };
  }

  updateParam(param) {
    if (param == "Get") {
      var valueView = $(this.id)
        .get(param)
        .get("valueView");
      this.values.params[param] = valueView.title;
    } else {
      super.updateParam(param);
    }
  }

  getParamChildViewObjects(param) {
    if (param == "Get") {
      var value = this.values.params[param];
      return Action.createButtonViewObjects(
        param,
        value || "First Item",
        buttonTapped.bind(this)
      );
    }
    return super.getParamChildViewObjects(param);
  }

  getParamViewHeight(param) {
    if (param == "Index") {
      var actionView = $(this.id);
      var option;
      if (actionView) {
        option = actionView.get("Get").get("valueView").title;
      } else {
        option = this.values.params["Get"];
      }
      if (option != "Item At Index") {
        return -1;
      }
    }
    return 50;
  }

  async handler(worker, flow, input, params) {
    if (!input || !Array.isArray(input) || input.length <= 0) {
      return;
    }

    var option = params["Get"];
    switch (option) {
      case "First Item":
        return input[0];
      case "Last Item":
        return input[input.length - 1];
      case "Random Item":
        return input[Math.floor(Math.random() * input.length)];
      case "Item At Index":
        var index = params["Index"];
        if (index >= 0 && index < input.length) {
          return input[index];
        }
    }
  }
}

function buttonTapped(sender) {
  $ui.menu({
    items: ["First Item", "Last Item", "Random Item", "Item At Index"],
    handler: function(title, idx) {
      sender.title = title;
      this.updateParamViewHeightLayout("Index");
    }.bind(this)
  });
}

module.exports = Action_getItemOfList;
