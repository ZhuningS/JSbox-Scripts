var Action = require("../action");
var Browser = require("../browser");
var Element = require("../element");
var Workflow = require("scripts/workflow");

class Action_getElementsOfBrowser extends Action {
  get config() {
    return {
      title: "Get Elements Of Browser",
      params: {
        "From": "Custom",
        "Selectors": "String"
      }
    };
  }

  updateParam(param) {
    if (param == "From") {
      var valueView = $(this.id)
        .get(param)
        .get("valueView");
      this.values.params[param] = valueView.title;
    } else {
      super.updateParam(param);
    }
  }

  getParamChildViewObjects(param) {
    var value = this.values.params[param];
    if (param == "From") {
      return Action.createButtonViewObjects(
        param,
        value || "Document",
        fromButtonTapped.bind(this)
      );
    }
    return super.getParamChildViewObjects(param);
  }

  getParamViewHeight(param) {
    if (["From", "Selectors"].indexOf(param) > -1) {
      return 50;
    }
    return super.getParamViewHeight(param);
  }

  async handler(worker, flow, input, params) {
    var browser = flow.variables["$Browser"];
    if (!browser) {
      return;
    }

    var element = params["From"];
    if (element == "Document" || element == browser) {
      element = await browser.getBodyElement();
    }
    if (!element) {
      return;
    }

    var selectors = params["Selectors"];

    return await element.query(selectors);
  }
}

function fromButtonTapped(sender) {
  var variableNames = Workflow.getVariableNames(this.id);
  $ui.menu({
    items: ["Document"].concat(variableNames),
    handler: function(title, idx) {
      if (idx > 0) {
        title = "{{" + title + "}}";
      }
      sender.title = title;
    }
  });
}

module.exports = Action_getElementsOfBrowser;
