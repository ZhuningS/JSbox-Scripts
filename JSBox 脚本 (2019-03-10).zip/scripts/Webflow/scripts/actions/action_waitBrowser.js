var Action = require("../action");
var Element = require("../element");

class Action_waitBrowser extends Action {
  get config() {
    return {
      title: "Wait Browser"
    };
  }

  async handler(worker, flow, input, params) {
    var browser = flow.variables["$Browser"];
    if (!browser) {
      return;
    }

    await browser.wait();
  }
}

module.exports = Action_waitBrowser;
