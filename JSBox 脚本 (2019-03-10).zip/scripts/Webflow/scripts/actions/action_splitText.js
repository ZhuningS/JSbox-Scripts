var Action = require("../action");

class Action_splitText extends Action {
  get config() {
    return {
      title: "Split Text",
      params: {
        "Separator": "String",
        "Regular Expression": "Bool"
      }
    };
  }

  async handler(worker, flow, input, params) {
    var text = input ? input.toString() : "";
    var isExpression = params["Regular Expression"];
    var separator = params["Separator"];
    if (isExpression) {
      separator = new RegExp(separator);
    }
    return text.split(separator);
  }
}

module.exports = Action_splitText;
