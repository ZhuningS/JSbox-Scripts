var Action = require("../action");

class Action_jscode extends Action {
  constructor(values) {
    if (!values) {
      values = {
        params: {
          "Script": `var value = $vars.variableName;
JSBox.console.info(value, $input);
return value;`
        }
      };
    }
    super(values);
  }

  get config() {
    return {
      title: "Js Code",
      params: {
        "Script": "Custom",
        "Environment": "Custom"
      }
    };
  }

  async handler(worker, flow, input, params) {
    var script = params["Script"];
    if (!script) {
      return input;
    }

    var env = params["Environment"];
    if (env == "Browser") {
      var browser = flow.variables["$Browser"];
      if (!browser) {
        return input;
      }

      return await browser.eval(script);
    } else {
      try {
        var js = "(async function(){";
        js += script;
        js += "})()";
        var result = await excJs(js, input, flow.variables);
        return result;
      } catch (e) {
        await $ui.alert({
          title: "Js Code Error",
          message: e.toString(),
          actions: ["Ok"]
        });
        worker.exit();
      }
    }
  }

  updateParam(param) {
    var valueView = $(this.id)
      .get(param)
      .get("valueView");
    if (param == "Environment") {
      var value = valueView.items[valueView.index];
      this.values.params[param] = value;
    } else {
      this.values.params[param] = valueView.text || "";
    }
  }

  getParamChildViewObjects(param) {
    var value = this.values.params[param];

    if (param == "Environment") {
      return Action.createTabViewObjects(param, value, ["System", "Browser"]);
    }

    var codeView = $objc("HOCodeView")
      .$alloc()
      .$initWithFrame_lang_style_showLineNumber_numberOfLines(
        { x: 0, y: 0, width: 0, height: 0 },
        "javaScript",
        "atom-one-light",
        1,
        0
      );
    codeView.$render(value);
    codeView.$setEditable(true);
    //    var block = $block("void, HOCodeView *", function(sender) {
    //  this.values.params[param] = sender.$text().rawValue();
    //}.bind(this));
    //    codeView.invoke("setBk_didEndEditingBlock", block)
    return [
      {
        type: "runtime",
        props: {
          id: "valueView",
          view: codeView
        },
        layout: function(make, view) {
          make.edges.inset(0);
          make.height.equalTo(150);
        }
      }
    ];
  }

  getParamViewHeight(param) {
    if (param == "Environment") {
      return 50;
    }
    return 150;
  }
}

async function excJs(script, $input, $vars) {
  return await eval(script);
}

module.exports = Action_jscode;
