var Action = require("../action");

class Action_text extends Action {
  get config() {
    return {
      title: "Text",
      params: {
        "Value": "Text"
      }
    };
  }

  async handler(worker, flow, input, params) {
    return params["Value"];
  }
}

module.exports = Action_text;
