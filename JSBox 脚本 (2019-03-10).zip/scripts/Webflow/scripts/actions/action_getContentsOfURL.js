var Workflow = require("scripts/workflow");
var Action = require("../action");
var helper = require("../helper");

$objc("UITableView");
$objc("UITableViewCell");

class Action_getContentsOfURL extends Action {
  constructor(values) {
    super(values);
  }

  get config() {
    return {
      title: "Get Contents of URL",
      params: {
        "Method": "Custom",
        "Headers": "Custom",
        "Content Type": "Custom",
        "Request Body": "Custom"
      }
    };
  }

  getParamChildViewObjects(param) {
    var value = this.values.params[param];
    switch (param) {
      case "Method":
        value = value || "GET";
        return Action.createButtonViewObjects(
          param,
          value,
          showMethodMenu.bind(this)
        );
      case "Content Type":
        return Action.createTabViewObjects(
          "Request Body",
          value,
          ["JSON", "Form"],
          contentTypeChanged.bind(this)
        );
      case "Headers":
        return createHeaderViewObjects(this);
      case "Request Body":
        return createBodyViewObjects(this);
    }
  }

  updateParam(param) {
    var value;
    var paramView = $(this.id).get(param);
    switch (param) {
      case "Method":
        value = paramView.get("valueView").title;
        break;
      case "Content Type":
        var view = paramView.get("valueView");
        value = view.items[view.index];
        break;
      case "Headers":
        var listView = paramView.get("headerListView");
        var listViewData = listView.data.map((item, i) => {
          var cell = listView.cell($indexPath(0, i));
          return {
            keyInput: cell.get("keyInput"),
            valueInput: cell.get("valueInput"),
            valueButton: cell.get("valueButton")
          };
        });
        value = listViewData2Data(listViewData);
        break;
      case "Request Body":
        var jsonListView = paramView.get("jsonListView");
        var formListView = paramView.get("formListView");
        var jsonListViewData = jsonListView.data.map((item, i) => {
          var cell = jsonListView.cell($indexPath(0, i));
          return {
            keyInput: cell.get("keyInput"),
            valueInput: cell.get("valueInput"),
            valueButton: cell.get("valueButton")
          };
        });
        var formListViewData = formListView.data.map((item, i) => {
          var cell = formListView.cell($indexPath(0, i));
          return {
            keyInput: cell.get("keyInput"),
            valueInput: cell.get("valueInput"),
            valueButton: cell.get("valueButton")
          };
        });
        value = {
          json: listViewData2Data(jsonListViewData),
          form: listViewData2Data(formListViewData)
        };
        break;
    }
    this.values.params[param] = value;
  }

  get viewHeight() {
    var height = super.viewHeight;
    if (this.min) {
      return height;
    }
    var actionView = $(this.id);
    var method;
    if (actionView) {
      method = actionView.get("Method").get("valueView").title;
    } else {
      method = this.values.params["Method"] || "GET";
    }
    if (method == "GET") {
      height -= this.getParamViewHeight("Content Type");
      height -= this.getParamViewHeight("Request Body");
      height -= 2;
    }
    return height;
  }

  getParamViewHeight(param) {
    var height = 0;
    var actionView = $(this.id);
    switch (param) {
      case "Headers":
        if (actionView) {
          var headerListView = actionView.get("Headers").get("headerListView");
          height = headerListView.data.length * 40;
        } else {
          var value = this.values.params[param] || [];
          height = value.length * 40;
        }
        height += 40;
        break;
      case "Request Body":
        if (actionView) {
          var contentTypeTabView = actionView
            .get("Content Type")
            .get("valueView");
          var listView;
          if (contentTypeTabView.index == 0) {
            listView = actionView.get("Request Body").get("jsonListView");
          } else {
            listView = actionView.get("Request Body").get("formListView");
          }
          height = listView.data.length * 40;
        } else {
          var contentType = this.values.params["Content Type"] || "JSON";
          var value = this.values.params[param] || {
            json: [],
            form: []
          };
          var data = contentType == "JSON" ? value.json : value.form;
          height = data.length * 40;
        }
        height += 40;
        break;
      default:
        height = 50;
        break;
    }
    return height;
  }

  async handler(worker, flow, input, params) {
    var urls = $detector.link(input);
    if (urls.length <= 0) {
      $ui.alert({
        title: "NO URL Specified",
        message: "Make sure to pass a URL to the Get Contents of URL action"
      });
      worker.exit();
      return;
    }
    var method = params["Method"];
    var contentType = params["Content Type"];
    var headers = params["Headers"];
    var requestBody = params["Request Body"];

    var header = {};
    if (method != "GET") {
      header["Content-Type"] =
        contentType == "JSON"
          ? "application/json"
          : "application/x-www-form-urlencoded";
    }
    headers.forEach(item => {
      if (item.key) {
        header[item.key] = item.value;
      }
    });

    var body = null;
    var form = null;
    var files = null;
    if (contentType == "JSON") {
      body = {};
      requestBody.json.forEach(item => {
        if (item.key) {
          body[item.key] = getDataValue(item.value);
        }
      });
    } else {
      form = {};
      files = [];
      requestBody.form.forEach(item => {
        if (item.key) {
          if (item.type == "Text") {
            form[item.key] = item.value;
          } else {
            files.push({
              name: item.key,
              data: item.value
            });
          }
        }
      });
    }

    var resp = await $http.request({
      method: method,
      url: urls[0],
      showsProgress: false,
      header: header,
      body: body,
      form: form,
      files: files,
      progress: (bytesWritten, totalBytes) => {
        var percentage = (bytesWritten * 1.0) / totalBytes;
        $console.info(percentage);
      }
    });
    if (resp.response.MIMEType.indexOf("image/") == 0) {
    }
    return resp;
  }
}

function getDataValue(data) {
  switch (data.type) {
    case "Text":
      return data.value.toString();
    case "Number":
      var value = parseInt(data.value);
      return value == "NaN" ? 0 : value;
    case "Boolean":
      return value.toString() == "true";
    case "Array":
      var array = [];
      data.value.forEach(item => {
        array.push(getDataValue(item));
      });
      return array;
    case "Dictionary":
      var json = {};
      data.value.forEach(item => {
        if (item.key) {
          json[item.key] = getDataValue(item);
        }
      });
      return json;
    case "File":
      return data.valuw;
  }
}

async function showMethodMenu(sender) {
  var select = await $ui.menu({
    items: ["GET", "POST", "PUT", "PATCH", "DELETE"]
  });
  sender.title = select.title;
  this.refreshActionViewHeight();
}

function contentTypeChanged() {
  var jsonView = $(this.id)
    .get("Request Body")
    .get("jsonView");
  var formView = $(this.id)
    .get("Request Body")
    .get("formView");
  var contentTypeTabView = $(this.id)
    .get("Content Type")
    .get("valueView");
  jsonView.hidden = contentTypeTabView.index == 1;
  formView.hidden = contentTypeTabView.index == 0;
  this.updateParamViewHeightLayout("Request Body");
}

function createBodyViewObjects(action) {
  var body = action.values.params["Request Body"] || {
    json: [],
    form: []
  };
  var contentType = action.values.params["Content Type"] || "JSON";
  var jsonData = data2ListViewData(body.json);
  var fromData = data2ListViewData(body.form);

  var jsonView = createJsonViewObject(action, jsonData, () => {
    action.updateParamViewHeightLayout("Request Body");
  });
  jsonView.props.hidden = contentType != "JSON";

  return [
    jsonView,
    {
      type: "view",
      props: {
        id: "formView",
        hidden: contentType == "JSON"
      },
      views: [
        {
          type: "list",
          props: {
            id: "formListView",
            selectable: false,
            scrollEnabled: false,
            rowHeight: 40,
            template: createFieldTemplate(action),
            data: fromData,
            actions: [
              {
                title: "Delete",
                color: $color("red"),
                handler: function(sender, indexPath) {
                  action.updateParamViewHeightLayout("Request Body");
                }
              }
            ]
          },
          layout: function(make, view) {
            make.left.right.inset(10);
            make.top.inset(0);
          }
        },
        createAddButtonObject("Add new field", async sender => {
          var result = await $ui.menu({
            items: ["Text", "File"]
          });
          if (!result) {
            return;
          }
          var listView = $(action.id)
            .get("Request Body")
            .get("formListView");
          listView.insert({
            index: listView.data.length,
            value: data2ListViewData([{ type: result.title }])[0]
          });
          action.updateParamViewHeightLayout("Request Body");
        })
      ],
      layout: $layout.fill
    }
  ];
}

function createJsonViewObject(action, data, updateLayout) {
  return {
    type: "view",
    props: {
      id: "jsonView"
    },
    views: [
      {
        type: "list",
        props: {
          id: "jsonListView",
          selectable: false,
          scrollEnabled: false,
          rowHeight: 40,
          template: createFieldTemplate(action),
          data: data,
          actions: [
            {
              title: "Delete",
              color: $color("red"),
              handler: function(sender, indexPath) {
                if (updateLayout) {
                  updateLayout();
                }
              }
            }
          ]
        },
        layout: function(make, view) {
          make.left.right.inset(10);
          make.top.inset(0);
        }
      },
      createAddButtonObject("Add new field", async sender => {
        var result = await $ui.menu({
          items: ["Text", "Number", "Boolean", "Array", "Dictionary"]
        });
        if (!result) {
          return;
        }
        var listView = sender.prev;
        listView.insert({
          index: listView.data.length,
          value: data2ListViewData([{ type: result.title }])[0]
        });
        if (updateLayout) {
          updateLayout();
        }
      })
    ],
    layout: $layout.fill
  };
}

function createArrayViewObject(action, data) {
  return {
    type: "view",
    props: {
      id: "arrayView"
    },
    views: [
      {
        type: "list",
        props: {
          id: "arrayListView",
          selectable: false,
          rowHeight: 40,
          template: createItemTemplate(action),
          data: data,
          actions: [
            {
              title: "Delete",
              color: $color("red"),
              handler: function(sender, indexPath) {}
            }
          ]
        },
        layout: function(make, view) {
          make.left.right.inset(10);
          make.top.inset(0);
        }
      },
      createAddButtonObject("Add new item", async sender => {
        var result = await $ui.menu({
          items: ["Text", "Number", "Boolean", "Array", "Dictionary"]
        });
        if (!result) {
          return;
        }
        var listView = sender.prev;
        listView.insert({
          index: listView.data.length,
          value: data2ListViewData([{ type: result.title }])[0]
        });
      })
    ],
    layout: $layout.fill
  };
}

function createAddButtonObject(title, tapped) {
  return {
    type: "button",
    props: {
      title: title,
      icon: $icon("104", $color("green"), $size(20, 20)),
      bgcolor: $color("clear"),
      titleColor: $color("#888888"),
      contentHorizontalAlignment: 1,
      titleEdgeInsets: $insets(0, 5, 0, 0),
      contentEdgeInsets: $insets(0, 10, 0, 0)
    },
    layout: (make, view) => {
      make.left.right.bottom.inset(0);
      make.top.equalTo(view.prev.bottom);
      make.height.equalTo(40);
    },
    events: {
      tapped: tapped
    }
  };
}

function createHeaderViewObjects(action) {
  var value = action.values.params["Headers"] || [];
  var data = data2ListViewData(value);
  return [
    {
      type: "list",
      props: {
        id: "headerListView",
        selectable: false,
        scrollEnabled: false,
        rowHeight: 40,
        template: createFieldTemplate(action),
        data: data,
        actions: [
          {
            title: "Delete",
            color: $color("red"),
            handler: (sender, indexPath) => {
              action.updateParamViewHeightLayout("Headers");
            }
          }
        ]
      },
      layout: (make, view) => {
        make.left.right.inset(10);
        make.top.inset(0);
      }
    },
    createAddButtonObject("Add new header", async sender => {
      var headerListView = $(action.id)
        .get("Headers")
        .get("headerListView");
      headerListView.insert({
        index: headerListView.data.length,
        value: data2ListViewData([{ type: "Text" }])[0]
      });
      action.updateParamViewHeightLayout("Headers");
    })
  ];
}

function createFieldTemplate(action) {
  return {
    views: [
      {
        type: "input",
        props: {
          id: "keyInput",
          bgcolor: $color("clear"),
          align: $align.left,
          placeholder: "Key",
          info: {
            actionId: action.id
          }
        },
        layout: (make, view) => {
          make.left.top.bottom.inset(0);
        },
        events: {
          returned: sender => {
            sender.blur();
          }
        }
      },
      {
        type: "view",
        props: {
          bgcolor: $color("#dddddd")
        },
        layout: function(make, view) {
          make.top.bottom.inset(0);
          make.left.equalTo(view.prev.right);
          make.centerX.equalTo(view.super);
          make.width.equalTo(0.5);
        }
      },
      {
        type: "input",
        props: {
          id: "valueInput",
          bgcolor: $color("clear"),
          info: {
            actionId: action.id
          }
        },
        layout: (make, view) => {
          make.left.equalTo(view.prev.right);
          make.top.bottom.inset(0);
          make.right.inset(10);
        },
        events: {
          returned: sender => {
            sender.blur();
          }
        }
      },
      {
        type: "button",
        props: {
          id: "valueButton",
          bgcolor: $color("clear"),
          titleColor: $color("tint"),
          contentHorizontalAlignment: 1,
          titleEdgeInsets: $insets(0, 10, 0, 0)
        },
        layout: (make, view) => {
          make.edges.equalTo(view.prev);
        },
        events: {
          tapped: fieldButtonTapped.bind(action)
        }
      }
    ]
  };
}

function createItemTemplate(action) {
  return {
    views: [
      {
        type: "input",
        props: {
          id: "valueInput",
          bgcolor: $color("clear"),
          info: {
            actionId: action.id
          }
        },
        layout: (make, view) => {
          make.left.inset(0);
          make.top.bottom.inset(0);
          make.right.inset(10);
        },
        events: {
          returned: sender => {
            sender.blur();
          }
        }
      },
      {
        type: "button",
        props: {
          id: "valueButton",
          bgcolor: $color("clear"),
          titleColor: $color("tint"),
          contentHorizontalAlignment: 1,
          titleEdgeInsets: $insets(0, 10, 0, 0)
        },
        layout: (make, view) => {
          make.edges.equalTo(view.prev);
        },
        events: {
          tapped: fieldButtonTapped.bind(action)
        }
      }
    ]
  };
}

function listViewData2Data(listViewData) {
  return listViewData.map(item => {
    var data = {};
    if (item.keyInput) {
      data.key = item.keyInput.text;
    }
    if (!item.valueInput.hidden) {
      data.type = item.valueInput.info.type;
    } else {
      data.type = item.valueButton.info.type;
    }
    switch (data.type) {
      case "Text":
      case "Number":
        data.value = item.valueInput.text;
        break;
      case "Boolean":
      case "File":
        if (item.valueButton.title != "Choose Variable") {
          data.value = item.valueButton.title;
        } else {
          data.value = "";
        }
        break;
      case "Array":
      case "Dictionary":
        data.value = item.valueButton.info.data;
        break;
    }
    return data;
  });
}

function data2ListViewData(data) {
  return data.map(item => {
    var listViewData = {
      keyInput: { text: item.key },
      valueInput: { hidden: true },
      valueButton: { hidden: true }
    };
    switch (item.type) {
      case "Text":
      case "Number":
        listViewData.valueInput = {
          hidden: false,
          text: item.value,
          placeholder: item.type,
          type: item.type == "Text" ? $kbType.default : $kbType.number,
          info: {
            type: item.type
          }
        };
        break;
      case "Boolean":
      case "File":
        var title;
        if (item.type == "File") {
          title = item.value || "Choose Variable";
        } else {
          title = item.value || "true";
        }
        listViewData.valueButton = {
          title: title,
          hidden: false,
          info: {
            type: item.type
          }
        };
        break;
      case "Array":
      case "Dictionary":
        var value = item.value || [];
        listViewData.valueButton = {
          title: value.length + " items",
          hidden: false,
          info: {
            type: item.type,
            data: value
          }
        };
        break;
    }
    return listViewData;
  });
}

function fieldButtonTapped(sender) {
  var currentCell = helper.findSuperView(
    sender,
    UITableViewCell.invoke("class")
  );
  var currentListView = helper.findSuperView(
    currentCell,
    UITableView.invoke("class")
  );
  var indexPath = currentListView
    .runtimeValue()
    .$indexPathForCell(currentCell)
    .rawValue();
  var data = listViewData2Data(currentListView.data);
  var currentData = data[indexPath.row];
  switch (currentData.type) {
    case "Dictionary":
    case "Array":
      var view;
      if (currentData.type == "Array") {
        view = createArrayViewObject(
          this,
          data2ListViewData(currentData.value)
        );
      } else {
        view = createJsonViewObject(this, data2ListViewData(currentData.value));
        view.views[0].props.scrollEnabled = true;
      }
      var contaierView = helper.showView(currentData.type, view, () => {
        var listView = contaierView.get("contentView").views[0].views[0];
        var listViewData = listView.data.map((item, i) => {
          var cell = listView.cell($indexPath(0, i));
          return {
            keyInput: cell.get("keyInput"),
            valueInput: cell.get("valueInput"),
            valueButton: cell.get("valueButton")
          };
        });
        currentData.value = listViewData2Data(listViewData);
        currentListView.data = data2ListViewData(data);
      });
      break;
    case "Boolean":
      var variableNames = Workflow.getVariableNames(this.id);
      $ui.menu({
        items: ["true", "false"].concat(variableNames),
        handler: function(title, idx) {
          if (idx > 1) {
            title = "{{" + title + "}}";
          }
          sender.title = title;
        }
      });
      break;
    case "File":
      var variableNames = Workflow.getVariableNames(this.id);
      if (helper.isVariableName(sender.title)) {
        variableNames.push("$Clear");
      }
      $ui.menu({
        items: variableNames,
        handler: function(title, idx) {
          if (title == "$Clear") {
            sender.title = "Choose Variable";
          } else {
            sender.title = "{{" + title + "}}";
          }
        }
      });
      break;
  }
}

module.exports = Action_getContentsOfURL;
