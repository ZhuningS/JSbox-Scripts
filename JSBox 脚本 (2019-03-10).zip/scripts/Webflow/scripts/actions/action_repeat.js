var Action = require("../action");

class Action_repeat extends Action {
  get config() {
    return {
      title: "Repeat",
      privateVaribaleName: "$RepeatIndex",
      params: {
        "Count": "StepNumber",
        "Flow": "Flow"
      }
    };
  }

  async handler(worker, flow, input, params) {
    var count = params["Count"];
    if (!count || !count.toString().match(/^\d+$/)) {
      count = 0;
    } else {
      count = Number(count);
    }

    var results = [];

    var repeatFlow = params["Flow"];

    for (var key in flow.variables) {
      repeatFlow.variables[key] = flow.variables[key];
    }

    await worker.flowBegin(repeatFlow);

    for (var i = 0; i < count; i++) {
      repeatFlow.variables[this.config.privateVaribaleName] = i;
      var output = await worker.runFlow(repeatFlow);

      if (output) {
        results.push(output);
      }

      var p = i / count;
      if (p < 1) {
        await this.progressUpdate(worker, flow, p);
      }
    }

    var parentVariableKeys = Object.keys(flow.variables);
    for (var key in repeatFlow.variables) {
      if (parentVariableKeys.indexOf(key) > -1) {
        flow.variables[key] = repeatFlow.variables[key];
      }
    }

    await worker.flowEnded(repeatFlow, output);

    return results;
  }
}

module.exports = Action_repeat;
