var Action = require("../action");

class Action_getAttributeOfElement extends Action {
  get config() {
    return {
      title: "Get Attribute Of Element",
      params: {
        "Attribute": "String"
      }
    };
  }

  async handler(worker, flow, input, params) {
    var attribute = params["Attribute"];

    if (attribute && input && input.getAttribute) {
      return await input.getAttribute(attribute);
    }

    return;
  }
}

module.exports = Action_getAttributeOfElement;
