var Action = require("../action");

class Action_count extends Action {
  get config() {
    return {
      title: "Count"
    };
  }

  async handler(worker, flow, input, params) {
    if (!input) {
      return 0;
    }
    return input.length;
  }
}

module.exports = Action_count;
