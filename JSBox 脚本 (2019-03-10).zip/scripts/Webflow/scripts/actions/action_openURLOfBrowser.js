var Action = require("../action");

class Action_openURLOfBrowser extends Action {
  get config() {
    return {
      title: "Open URL Of Browser",
      params: {
        "URL": "String"
      }
    };
  }

  async handler(worker, flow, input, params) {
    var browser = flow.variables["$Browser"];
    if (!browser) {
      return input;
    }

    var urls = $detector.link(params["URL"]);
    if (urls.length > 0) {
      await browser.open(urls[0]);
    }

    return input;
  }
}

module.exports = Action_openURLOfBrowser;
