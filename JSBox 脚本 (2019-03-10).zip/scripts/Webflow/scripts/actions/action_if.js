var Action = require("../action");

class Action_if extends Action {
  get config() {
    return {
      title: "If",
      params: {
        "Conditions": "Custom",
        "Logic": "Custom",
        "True Flow": "Flow",
        "False Flow": "Flow"
      }
    };
  }

  async handler(worker, flow, input, params) {
    var result = false;
    params["Conditions"].every(item => {
      switch (item.compare) {
        case "in":
          result = item.value2.indexOf(item.value1) > -1;
          break;
        case "=":
          result = item.value1 == item.value2;
          break;
        case "<":
          result = item.value1 < item.value2;
          break;
        case ">":
          result = item.value1 > item.value2;
          break;
        case ">=":
          result = item.value1 >= item.value2;
          break;
        case "<=":
          result = item.value1 <= item.value2;
          break;
      }
      if (
        (params["Logic"] == "And" && !result) ||
        (params["Logic"] == "Or" && result)
      ) {
        return false;
      }
      return true;
    });

    var ifFlow = result ? params["True Flow"] : params["False Flow"];

    for (var key in flow.variables) {
      ifFlow.variables[key] = flow.variables[key];
    }

    await worker.flowBegin(ifFlow);

    var i = 0;
    var count = ifFlow.actions.length;
    var self = this;
    var output = await worker.runFlow(ifFlow, null, async action => {
      i++;
      var p = i / count;
      if (p < 1) {
        await self.progressUpdate(worker, flow, p);
      }
    });

    var parentVariableKeys = Object.keys(flow.variables);
    for (var key in ifFlow.variables) {
      if (parentVariableKeys.indexOf(key) > -1) {
        flow.variables[key] = ifFlow.variables[key];
      }
    }

    await worker.flowEnded(ifFlow);

    return output;
  }

  updateParam(param) {
    var view = $(this.id)
      .get(param)
      .get("valueView");
    switch (param) {
      case "Conditions":
        var data = view.data;
        var conditions = [];
        data.forEach((item, i) => {
          var cell = view.cell($indexPath(0, i));
          conditions.push({
            value1: cell.get("valueInput1").text,
            value2: cell.get("valueInput2").text,
            compare: cell.get("compareButton").title
          });
        });
        this.values.params[param] = conditions;
        break;
      case "Logic":
        this.values.params[param] = view.items[view.index];
        break;
    }
  }

  getParamViewHeight(param) {
    switch (param) {
      case "Conditions":
        var height = 40;
        var actionView = $(this.id);
        if (actionView) {
          var conditionView = actionView.get(param).get("valueView");
          height += conditionView.data.length * 40;
        } else {
          var value = this.values.params[param] || [1];
          height += value.length * 40;
        }
        return height;
      default:
        return super.getParamViewHeight(param);
    }
  }

  getParamChildViewObjects(param) {
    var self = this;
    var value = this.values.params[param];
    switch (param) {
      case "Conditions":
        if (!value || value.length <= 0) {
          value = [
            {
              compareButton: {
                title: "in"
              }
            }
          ];
        } else {
          value = value.map(item => {
            return {
              valueInput1: {
                text: item.value1
              },
              valueInput2: {
                text: item.value2
              },
              compareButton: {
                title: item.compare
              }
            };
          });
        }
        return [
          {
            type: "list",
            props: {
              id: "valueView",
              selectable: false,
              scrollEnabled: false,
              rowHeight: 40,
              template: createConditionTemplate(self),
              data: value,
              actions: [
                {
                  title: "Delete",
                  color: $color("red"),
                  handler: function(sender, indexPath) {
                    self.updateParamViewHeightLayout("Conditions");
                  }
                }
              ]
            },
            layout: function(make, view) {
              make.left.right.inset(10);
              make.top.inset(0);
            }
          },
          {
            type: "button",
            props: {
              title: "Add Condition",
              icon: $icon("104", $color("green"), $size(20, 20)),
              bgcolor: $color("clear"),
              titleColor: $color("#888888"),
              contentHorizontalAlignment: 1,
              titleEdgeInsets: $insets(0, 5, 0, 0),
              contentEdgeInsets: $insets(0, 10, 0, 0)
            },
            layout: (make, view) => {
              make.left.right.inset(0);
              make.top.equalTo(view.prev.bottom);
              make.bottom.inset(0);
              make.height.equalTo(40);
            },
            events: {
              tapped: sender => {
                var conditionView = $(self.id)
                  .get(param)
                  .get("valueView");
                conditionView.insert({
                  index: conditionView.data.length,
                  value: {
                    compareButton: {
                      title: "in"
                    }
                  }
                });
                self.updateParamViewHeightLayout("Conditions");
              }
            }
          }
        ];
      case "Logic":
        var index = ["And", "Or"].indexOf(value);
        if (index < 0) {
          index = 0;
        }
        return [
          {
            type: "tab",
            props: {
              id: "valueView",
              items: ["And", "Or"],
              index: index
            },
            layout: (make, view) => {
              make.edges.inset(10);
              make.height.equalTo(30);
            }
          }
        ];
      default:
        return super.getParamChildViewObjects(param);
    }
  }
}

function createConditionTemplate(action) {
  return {
    views: [
      {
        type: "input",
        props: {
          id: "valueInput1",
          bgcolor: $color("clear"),
          align: $align.left,
          placeholder: "Value",
          info: {
            actionId: action.id
          }
        },
        layout: (make, view) => {
          make.left.top.bottom.inset(0);
        },
        events: {
          returned: sender => {
            sender.blur();
          }
        }
      },
      {
        type: "button",
        props: {
          id: "compareButton",
          title: "in",
          titleColor: $color("tint"),
          bgcolor: $color("clear")
        },
        layout: function(make, view) {
          make.left.equalTo(view.prev.right);
          make.centerY.equalTo(view.super);
          make.size.equalTo($size(30, 30));
        },
        events: {
          tapped: sender => {
            $ui.menu({
              items: ["in", "=", ">", "<", ">=", "<="],
              handler: (title, index) => {
                sender.title = title;
              }
            });
          }
        }
      },
      {
        type: "input",
        props: {
          id: "valueInput2",
          bgcolor: $color("clear"),
          align: $align.right,
          placeholder: "Value",
          info: {
            actionId: action.id
          }
        },
        layout: (make, view) => {
          make.left.equalTo(view.prev.right);
          make.top.bottom.inset(0);
          make.right.inset(10);
          make.width.equalTo(view.prev.prev);
        },
        events: {
          returned: sender => {
            sender.blur();
          }
        }
      }
    ]
  };
}

module.exports = Action_if;
