var Action = require("../action");
var helper = require("../helper");

class Action_submitAlert extends Action {
  get config() {
    return {
      title: "Submit Alert",
      params: {
        "Find Button Title": "String"
      }
    };
  }

  async handler(worker, flow, input, params) {
    var title = params["Find Button Title"];
    if (!title) {
      return;
    }

    var window = $objc("UIApplication")
      .$sharedApplication()
      .$keyWindow()
      .rawValue();

    var result = helper.findSubview(
      window,
      $objc("_UIAlertControllerView").invoke("class")
    );

    if (result) {
      var alertController = result.runtimeValue().$alertController();
      var actions = alertController.$actions().rawValue();

      var action;
      for (var i = 0; i < actions.length; i++) {
        if (
          actions[i]
            .runtimeValue()
            .$title()
            .rawValue() == title
        ) {
          action = actions[i].runtimeValue();
          break;
        }
      }

      if (action) {
        action.$handler()();
        alertController.$dismissViewControllerAnimated_completion(true, null);
      }
    }
  }
}

module.exports = Action_submitAlert;
