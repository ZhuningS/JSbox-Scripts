var Action = require("../action");
var Element = require("../element");

class Action_fireElementEvent extends Action {
  get config() {
    return {
      title: "Fire Element Event",
      params: {
        "Event": "Custom"
      }
    };
  }

  updateParam(param) {
    var valueView = $(this.id)
      .get(param)
      .get("valueView");
    this.values.params[param] = valueView.title;
  }

  getParamChildViewObjects(param) {
    var value = this.values.params[param];
    return Action.createButtonViewObjects(
      param,
      value || "click",
      buttonTapped.bind(this)
    );
  }

  getParamViewHeight(param) {
    return 50;
  }

  async handler(worker, flow, input, params) {
    var event = params["Event"];
    if (input && input instanceof Element) {
      input.fireElementEvent(event);
    }
  }
}

function buttonTapped(sender) {
  $ui.menu({
    items: ["click", "mouseover", "change", "submit"],
    handler: function(title, idx) {
      sender.title = title;
    }.bind(this)
  });
}

module.exports = Action_fireElementEvent;
