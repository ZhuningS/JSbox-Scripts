var Action = require("../action");
var Element = require("../element");

class Action_setAttributeOfElement extends Action {
  get config() {
    return {
      title: "Set Attribute Of Element",
      params: {
        "Attribute": "String",
        "Value": "String"
      }
    };
  }

  async handler(worker, flow, input, params) {
    var attribute = params["Attribute"];
    var value = params["Value"];

    if (attribute && input && input instanceof Element) {
      await input.setAttribute(attribute, value);
    }
  }
}

module.exports = Action_setAttributeOfElement;
