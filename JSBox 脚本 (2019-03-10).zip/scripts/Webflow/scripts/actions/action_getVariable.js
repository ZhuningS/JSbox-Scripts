var Action = require("../action");
var Workflow = require("scripts/workflow");

class Action_getVariable extends Action {
  get config() {
    return {
      title: "Get Variable",
      params: {
        "Variable": "Custom"
      }
    };
  }

  updateParam(param) {
    var valueView = $(this.id)
      .get(param)
      .get("valueView");
    if (valueView.title == "Choose Variable") {
      this.values.params[param] = "";
    } else {
      this.values.params[param] = valueView.title;
    }
  }

  getParamChildViewObjects(param) {
    var value = this.values.params[param];
    return Action.createButtonViewObjects(
      param,
      value || "Choose Variable",
      buttonTapped.bind(this)
    );
  }

  getParamViewHeight(param) {
    return 50;
  }

  async handler(worker, flow, input, params) {
    return params["Variable"];
  }
}

function buttonTapped(sender) {
  var variableNames = Workflow.getVariableNames(this.id);
  if (sender.title != "Choose Variable") {
    variableNames.push("$Clear");
  }
  $ui.menu({
    items: variableNames,
    handler: function(title, idx) {
      if (title == "$Clear") {
        title = "Choose Variable";
      } else {
        title = "{{" + title + "}}";
      }
      sender.title = title;
    }
  });
}

module.exports = Action_getVariable;
