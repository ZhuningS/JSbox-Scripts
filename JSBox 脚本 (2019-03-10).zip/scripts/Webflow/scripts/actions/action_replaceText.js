var Action = require("../action");

class Action_replaceText extends Action {
  get config() {
    return {
      title: "Replace Text",
      params: {
        "Find Text": "String",
        "Replace With": "String",
        "Regular Expression": "Bool"
      }
    };
  }

  async handler(worker, flow, input, params) {
    var text = input ? input.toString() : "";
    var isExpression = params["Regular Expression"];
    var findText = params["Find Text"];
    var replaceWith = params["Replace With"];
    if (isExpression) {
      findText = new RegExp(findText);
    }
    return text.replace(findText, replaceWith);
  }
}

module.exports = Action_replaceText;
