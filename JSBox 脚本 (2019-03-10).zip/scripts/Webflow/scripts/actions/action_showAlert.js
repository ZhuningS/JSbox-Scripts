var Action = require("../action");

class Action_showAlert extends Action {
  constructor(values) {
    if (!values) {
      values = {
        params: {
          "Title": "Alert",
          "Message": "Do you want to continue?",
          "Show Cancel Button": true
        }
      };
    }
    super(values);
  }

  get config() {
    return {
      title: "Show Alert",
      params: {
        "Title": "String",
        "Message": "Text",
        "Show Cancel Button": "Bool"
      }
    };
  }

  async handler(worker, flow, input, params) {
    await this.progressUpdate(worker, flow, 0.5);
    var result = await $ui.alert({
      title: params["Title"],
      message: params["Message"],
      actions: params["Show Cancel Button"] ? ["Cancel", "OK"] : ["OK"]
    });

    if (result.title == "Cancel") {
      worker.exit();
    }
    return input;
  }
}

module.exports = Action_showAlert;
