var Action = require("../action");

class Action_wait extends Action {
  get config() {
    return {
      title: "Wait",
      params: {
        "Milliseconds": "Number"
      }
    };
  }

  async handler(worker, flow, input, params) {
    var milliseconds = params["Milliseconds"];
    await new Promise(function(resolve, reject) {
      $delay(milliseconds / 1000, function() {
        resolve();
      });
    });
    return input;
  }
}

module.exports = Action_wait;
