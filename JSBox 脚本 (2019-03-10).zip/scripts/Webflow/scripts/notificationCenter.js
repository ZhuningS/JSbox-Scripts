var notificationCenter = {
  observers: [],

  post: (name, userInfo) => {
    var results = notificationCenter.observers.filter(
      item => item.name == name
    );
    results.forEach(item => {
      item.call(name, userInfo);
    });
  },

  addObserver: (observer, name, call) => {
    var results = notificationCenter.observers.filter(
      item => item.observer == observer && item.name == name
    );
    if (results.length > 0) {
      results[0].call = call;
    } else {
      notificationCenter.observers.push({
        observer,
        name,
        call
      });
    }
  },

  removeObserver: observer => {
    notificationCenter.observers = notificationCenter.observers.filter(
      item => item.observer != observer
    );
  }
};

module.exports = notificationCenter;
