class Element {
  constructor(browser, html, selectors, index = 0) {
    this.browser = browser;
    this.html = html;
    this.selectors = selectors;
    this.index = index;
  }

  async eval(js) {
    return new Promise(
      function(resolve, reject) {
        if (!this.html) {
          resolve([]);
          return;
        }

        var tag = this.selectors == "html" ? "html" : "div";
        var html = btoa(encodeURIComponent(this.html));
        var js1 = `
        var html = decodeURIComponent(atob("${html}"));
        //var parser = new DOMParser();
        //element = parser.parseFromString(html, "text/html");
        var temp = document.createElement("${tag}");
　　     temp.innerHTML = html;
        var element;
        if (temp.tagName == "HTML") {
          element = temp;
        } else {
          element = temp.firstElementChild;
        }
     
        if (element) {
           ${js}
        }
      `;

        $browser.exec({
          script: js1,
          handler: function(result) {
            resolve(result);
          },
          console: function(msg) {
            $console.info(msg);
          }
        });
      }.bind(this)
    );
  }

  async getText() {
    var js = `
        switch(element.tagName) {
          case "INPUT":
          case "SELECT":
             return element.value;
        }
        return element.innerText;
    `;
    return await this.eval(js);
  }

  async getAttribute(name) {
    if (!name) {
      return;
    }
    var js = `
        return element["${name}"];
    `;
    return await this.eval(js);
  }

  async click() {
    await this.browser.clickElement(this.selectors, this.index);
  }
  
  async fireElementEvent(event) {
    await this.browser.fireElementEvent(this.selectors, this.index, event);
  }

  async setAttribute(name, value) {
    if (!name) {
      return;
    }
    var js = `
        element["${name}"] = "${value}";
        return element.outerHTML;
    `;
    this.html = await this.eval(js);
    await this.browser.setElementAttribute(
      this.selectors,
      this.index,
      name,
      value
    );
  }

  async query(selectors) {
    var js = `
        var results = element.querySelectorAll("${selectors}");
        var htmls = [];
        for (var i = 0; i < results.length; i++) {
          htmls.push(results[i].outerHTML);
        }
        return htmls;
    `;
    var results = await this.eval(js);
    var elements = [];
    for (var i = 0; i < results.length; i++) {
      elements.push(new Element(this.browser, results[i], selectors, i));
    }

    return elements;
  }
}

module.exports = Element;
