var Workflow = require("scripts/workflow");

$define({
  type: "ActionInputTool: NSObject",
  events: {
    addObserver: function() {
      $objc("NSNotificationCenter")
        .$defaultCenter()
        .$addObserver_selector_name_object(
          self,
          "didBeginEditing:",
          "UITextFieldTextDidBeginEditingNotification",
          null
        );

      $objc("NSNotificationCenter")
        .$defaultCenter()
        .$addObserver_selector_name_object(
          self,
          "didBeginEditing:",
          "UITextViewTextDidBeginEditingNotification",
          null
        );

      $objc("NSNotificationCenter")
        .$defaultCenter()
        .$addObserver_selector_name_object(
          self,
          "didEndedEditing:",
          "UITextFieldTextDidEndEditingNotification",
          null
        );

      $objc("NSNotificationCenter")
        .$defaultCenter()
        .$addObserver_selector_name_object(
          self,
          "didEndedEditing:",
          "UITextViewTextDidEndEditingNotification",
          null
        );

      $objc_retain(self);
    },

    removeObserver: function() {
      $objc("NSNotificationCenter")
        .$defaultCenter()
        .$removeObserver(self);
      $objc_release(self);
    },

    didBeginEditing: function(notification) {
      var view = notification.$object().rawValue();
      if (view.info && view.info.actionId) {
        setInputTool(view.info.actionId, view);
      }
    },

    didEndedEditing: function(notification) {
      var view = notification.$object().rawValue();
      if (view.info && view.info.actionId) {
        view.runtimeValue().$setInputView(null);
      }
    }
  }
});

function setInputTool(actionId, inputView) {
  var variableView = $ui.create({
    type: "matrix",
    props: {
      frame: $rect(0, 0, 0, 250),
      itemHeight: 26,
      spacing: 5,
      scrollEnabled: false,
      template: {
        views: [
          {
            type: "label",
            props: {
              radius: 14,
              font: $font(14),
              titleColor: $color("#333333"),
              bgcolor: $color("#efefef"),
              borderWidth: 0.5,
              borderColor: $color("#dddddd"),
              align: $align.center
            },
            layout: $layout.fill
          }
        ]
      }
    },
    events: {
      didSelect: function(sender, indexPath, data) {
        inputView.runtimeValue().$insertText("{{" + data.label.text + "}}");
      },
      itemSize: function(sender, indexPath) {
        var data = sender.object(indexPath);
        var size = $text.sizeThatFits({
          text: data.label.text,
          width: 320,
          font: $font(14)
        });
        return $size(size.width + 20, 30);
      }
    }
  });
  var toolView = $ui.create({
    type: "view",
    props: {
      frame: $rect(0, 0, 0, 40),
      bgcolor: $color("#eeeeee"),
      borderWidth: 0.5,
      borderColor: $color("#cccccc")
    },
    views: [
      {
        type: "button",
        props: {
          id: "varibaleButton",
          title: "Variables",
          radius: 6,
          font: $font(14),
          titleColor: $color("#333333"),
          bgcolor: $color("#ffffff"),
          borderWidth: 0.5,
          borderColor: $color("#cccccc")
        },
        layout: function(make, view) {
          make.left.inset(10);
          make.size.equalTo($size(80, 30));
          make.centerY.equalTo(view.super);
        },
        events: {
          tapped: function(sender) {
            if (inputView.runtimeValue().$inputView()) {
              inputView.runtimeValue().$setInputView(null);
              toolView.get("varibaleButton").bgcolor = $color("#ffffff");
            } else {
              var data = Workflow.getVariableNames(actionId);
              variableView.data = data.map(item => {
                return {
                  label: {
                    text: item
                  }
                };
              });
              inputView.runtimeValue().$setInputView(variableView);
              toolView.get("varibaleButton").bgcolor = $color("#cccccc");
            }
            inputView.runtimeValue().$reloadInputViews();
          }
        }
      },
      {
        type: "button",
        props: {
          title: "Done",
          font: $font("bold", 14),
          titleColor: $color("#333333"),
          bgcolor: $color("clear")
        },
        layout: function(make, view) {
          make.top.right.bottom.inset(0);
          make.width.equalTo(80);
        },
        events: {
          tapped: function(sender) {
            inputView.blur();
            inputView.runtimeValue().$setInputView(null);
          }
        }
      }
    ]
  });
  inputView.runtimeValue().$setInputAccessoryView(toolView);
  inputView.runtimeValue().$reloadInputViews();
}
