var Workflow = require("scripts/workflow");
var WorkflowEditor = require("./workflowEditor");
var notificationCenter = require("scripts/notificationCenter");
var Worker = require("./worker");

function show() {
  $ui.render({
    props: {
      id: "mainView"
    },
    views: [
      {
        type: "matrix",
        props: {
          id: "workflowMatrix",
          columns: 2,
          itemHeight: 80,
          spacing: 10,
          reorder: false,
          template: {
            props: {
              radius: 8,
              bgcolor: $color("#efefef"),
              borderWidth: 0.5,
              borderColor: $color("#dddddd")
            },
            views: [
              {
                type: "image",
                layout: (make, view) => {
                  make.size.equalTo($size(30, 30));
                  make.centerX.equalTo(view.super);
                  make.centerY.equalTo(view.super).offset(-10);
                }
              },
              {
                type: "label",
                props: {
                  autoFontSize: true,
                  textColor: $color("#666666"),
                  font: $font(16),
                  align: $align.center
                },
                layout: (make, view) => {
                  make.left.right.inset(10);
                  make.top.equalTo(view.prev.bottom).offset(10);
                }
              }
            ]
          }
        },
        layout: $layout.fill,
        events: {
          didSelect: (sender, indexPath, data) => {
            var workflow;
            if (data.label.info.id) {
              workflow = Workflow.getWorkflow(data.label.info.id);
            } else {
              workflow = new Workflow();
            }
            Workflow.currentWorkflow = workflow;
            var workflowEditor = new WorkflowEditor(workflow);
            workflowEditor.show();
          },
          didLongPress: function(sender, indexPath, data) {
            if (!data.label.info.id) {
              return;
            }
            $ui.menu({
              items: ["Run", "Delete"],
              handler: function(title, idx) {
                if (idx == 1) {
                  Workflow.remove(data.label.info.id);
                  sender.delete(indexPath);
                }
              }
            });
          },
          reorderBegan: function(indexPath) {},
          reorderMoved: function(fromIndexPath, toIndexPath) {},
          reorderFinished: function(data) {}
        }
      }
    ],
    events: {
      appeared: function() {
        var workflowDatas = Workflow.getWorkflowDatas();
        var data = workflowDatas.map(item => {
          return {
            image: {
              icon: $icon(item.data.icon, $color("#666666"), $size(30, 30))
            },
            label: {
              text: item.data.name,
              info: item
            }
          };
        });
        data.push({
          image: {
            icon: $icon("104", $color("#aaaaaa"), $size(30, 30))
          },
          label: {
            text: "Add Workflow",
            info: {}
          }
        });
        $("workflowMatrix").data = data;
      }
    }
  });
}

module.exports = {
  show: show
};
