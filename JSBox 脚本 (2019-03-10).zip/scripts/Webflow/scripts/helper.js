$objc("NSUUID");

function exchange(array, index1, index2) {
  var value1 = array[index1];
  var value2 = array[index2];
  array[index1] = value2;
  array[index2] = value1;
}

function getGUID() {
  return NSUUID.$UUID()
    .$UUIDString()
    .rawValue();
}

function splitVariableName(content) {
  return content.split(/(\{\{[$a-zA-Z][_a-zA-Z0-9]*\}\})/g) || [];
}

function verifyVaribaleName(variableName) {
  if (
    !variableName ||
    variableName.toString().match(/^([a-zA-Z][_a-zA-Z0-9]*)$/)
  ) {
    return true;
  }
  return false;
}

function isVariableName(value) {
  if (value && value.toString().match(/^(\{\{[$a-zA-Z][_a-zA-Z0-9]*\}\})$/)) {
    return true;
  }
  return false;
}

function findSuperView(view, runtimeClass) {
  var superView = view.super;
  while (superView) {
    if (superView.runtimeValue().$isKindOfClass(runtimeClass)) {
      return superView;
    } else {
      superView = superView.super;
    }
  }
}

function findSubview(view, viewClass) {
  for (var i in view.views) {
    if (view.views[i].runtimeValue().$isKindOfClass(viewClass)) {
      return view.views[i];
    } else {
      var result = findSubview(view.views[i], viewClass);
      if (result) {
        return result;
      }
    }
  }
}

function showView(title, viewObject, done) {
  var window = $ui.window.runtimeValue();
  var windowBounds = $ui.window.bounds;
  var width = windowBounds.width - 40;
  var height = windowBounds.height - 40;
  var maskView = $("window_maskView");
  if (!maskView) {
    maskView = $ui.create({
      type: "view",
      props: {
        id: "window_maskView",
        bgcolor: $color("#000000"),
        alpha: 0,
        frame: windowBounds,
        info: 0
      }
    });
    window.$addSubview(maskView);
  }
  maskView.info++;

  var contaierView = $ui.create({
    type: "view",
    props: {
      alpha: 0,
      bgcolor: $color("#ffffff"),
      radius: 8,
      borderWidth: 0.5,
      borderColor: $color("#dddddd"),
      frame: $rect(20, windowBounds.height, width, height)
    },
    views: [
      {
        type: "view",
        layout: (make, view) => {
          make.left.top.right.inset(0);
          make.height.equalTo(40);
        },
        views: [
          {
            type: "label",
            props: {
              text: title,
              font: $font(16),
              textColor: $color("#333333")
            },
            layout: (make, view) => {
              make.left.inset(10);
              make.top.bottom.inset(0);
            }
          },
          {
            type: "button",
            props: {
              title: "Done",
              titleColor: $color("tint"),
              bgcolor: $color("clear")
            },
            layout: (make, view) => {
              make.left.equalTo(view.prev.right).offset(10);
              make.right.inset(0);
              make.centerY.equalTo(view.super);
              make.size.equalTo($size(60, 40));
            },
            events: {
              tapped: sender => {
                if (done) {
                  done();
                }
                $ui.animate({
                  duration: 0.3,
                  animation: () => {
                    contaierView.frame = $rect(
                      20,
                      windowBounds.height,
                      width,
                      height
                    );
                  },
                  completion: () => {
                    contaierView.remove();
                    maskView.info--;
                    if (maskView.info == 0) {
                      $ui.animate({
                        duration: 0.3,
                        delay: 0,
                        animation: function() {
                          maskView.alpha = 0;
                        },
                        completion: function() {
                          maskView.remove();
                        }
                      });
                    }
                  }
                });
              }
            }
          }
        ]
      },
      {
        type: "view",
        props: {
          bgcolor: $color("#dddddd")
        },
        layout: (make, view) => {
          make.top.equalTo(view.prev.bottom);
          make.left.right.inset(10);
          make.height.equalTo(0.5);
        }
      },
      {
        type: "view",
        props: {
          id: "contentView"
        },
        layout: (make, view) => {
          make.top.equalTo(view.prev.bottom);
          make.left.right.bottom.inset(0);
        },
        views: [viewObject]
      }
    ]
  });
  window.$addSubview(contaierView);
  $ui.animate({
    duration: 0.6,
    damping: 0.7,
    velocity: 0.1,
    animation: function() {
      maskView.alpha = 0.5;
      contaierView.alpha = 1;
      contaierView.frame = $rect(
        20,
        20 + maskView.info * 5,
        width,
        height - maskView.info * 5
      );
    }
  });
  return contaierView;
}

module.exports = {
  exchange,
  getGUID,
  splitVariableName,
  verifyVaribaleName,
  isVariableName,
  findSubview,
  findSuperView,
  showView
};
