var helper = require("./helper");
var Flow = require("./flow");
var DataTable = require("./dataTable");

class Workflow {
  constructor(id, config) {
    this.id = id || helper.getGUID();
    if (config) {
      this.name = config.name;
      this.icon = config.icon;
      this.types = config.types;
      this.flow = new Flow(config.flow);
    } else {
      this.name = "Untitled Workflow";
      this.icon = "";
      this.types = [];
      this.flow = new Flow();
    }
    this.dataTable = new DataTable();
  }
  
  save() {
    this.flow.update();
    var data = {
      name: this.name,
      icon: this.icon,
      types: this.types,
      flow: this.flow.getData()
    };
    var exists = $file.exists("shared://workflows/");
    if (!exists) {
      var success = $file.mkdir("shared://workflows/");
    }
    var success = $file.write({
      data: $data({ string: JSON.stringify(data) }),
      path: "shared://workflows/" + this.id + ".workflow"
    });
    return success;
  }

  remove() {
    Workflow.remove(this.id);
  }
}

Workflow.currentWorkflow = null;
Workflow.getVariableNames = function(actionId) {
  if (!Workflow.currentWorkflow) {
    return [];
  }
  Workflow.currentWorkflow.flow.update();
  return getVariableNames(Workflow.currentWorkflow.flow, actionId).result;
};

Workflow.remove = function(id) {
  $file.delete("shared://workflows/" + id + ".workflow");
};

Workflow.getWorkflow = function(id) {
  var content = $file.read("shared://workflows/" + id + ".workflow").string;
  var data = JSON.parse(content);
  var workflow = new Workflow(id, data);
  return workflow;
};

Workflow.getWorkflowDatas = function() {
  var files = $file.list("shared://workflows/");
  var datas = (files || []).map(file => {
    if (!$file.isDirectory(file)) {
      var id = file.substring(file.lastIndexOf("/") + 1);
      id = id.substring(0, id.lastIndexOf("."));
      var content = $file.read("shared://workflows/" + id + ".workflow").string;
      var data = JSON.parse(content);
      return {
        id,
        data
      };
    }
  });
  return datas;
};

function getVariableNames(flow, actionId) {
  var result = [];
  var find = false;
  flow.actions.every(item => {
    if (item.id == actionId) {
      find = true;
      return false;
    } else {
      if (item.values.variableName) {
        result.push(item.values.variableName);
      }

      var flowResult;
      for (var param in item.config.params) {
        if (item.config.params[param] == "Flow") {
          flowResult = getVariableNames(item.values.params[param], actionId);
          if (flowResult.find) {
            break;
          }
        }
      }

      if (flowResult && flowResult.find) {
        if (
          flowResult.result.indexOf(item.config.privateVaribaleName) < 0 &&
          item.config.privateVaribaleName
        ) {
          flowResult.result.push(item.config.privateVaribaleName);
        }
        find = true;
        result = result.concat(flowResult.result);
        return false;
      }
    }
    return true;
  });
  return {
    result: result,
    find: find
  };
}

module.exports = Workflow;
