var Action = require("scripts/action");

function show(selected) {
  var data = $file.list("scripts/actions/").map(function(item) {
    return item.replace("action_", "").replace(".js", "");
  });
  $ui.push({
    type: "view",
    views: [
      {
        type: "list",
        props: {
          data: data
        },
        layout: $layout.fill,
        events: {
          didSelect: (sender, indexPath, data) => {
            var action = Action.getAction(data);
            selected(action);
            $ui.pop();
          }
        }
      }
    ]
  });
}

module.exports = {
  show
};
