var helper = require("./helper");

class Worker {
  constructor() {
    this._exit = false;
    this._working = false;
    this.workBegin = function() {};
    this.workEnded = function() {};
    this.flowBegin = function() {};
    this.flowEnded = function() {};
    this.actionBegin = function() {};
    this.actionEnded = function() {};
  }

  exit() {
    this._exit = true;
  }

  get working() {
    return this._working;
  }

  async work(flow) {
    this._exit = false;
    this._working = true;
    flow.variables = {};

    await this.workBegin(this, flow);

    await this.flowBegin(flow);

    var output = await this.runFlow(flow);

    await this.flowEnded(flow, output);

    await this.workEnded(this, flow, output);

    this._working = false;

    return output;
  }

  async runFlow(flow, beginHandler, endedHandler) {
    var output;
    for (var i = 0; i < flow.actions.length; i++) {
      if (this._exit) {
        this._exit = false;
        break;
      }
      var action = flow.actions[i];
      await action.willBegin(this, flow);
      await this.actionBegin(flow, action);
      if (beginHandler) {
        await beginHandler(action);
      }

      var params = replaceVariable(action, flow.variables);
      output = await action.handler(this, flow, output, params);

      if (action.values.variableName) {
        flow.variables[action.values.variableName] = output;
      }

      await action.progressUpdate(this, flow, 1);

      await this.actionEnded(flow, action);
      if (endedHandler) {
        await endedHandler(action);
      }
      await action.didEnded(this, flow);
    }
    return output;
  }
}

function replaceVariable(action, variables) {
  var params = {};
  for (var key in action.values.params) {
    var type = action.config.params[key];
    var value = action.values.params[key];
    switch (type) {
      case "String":
      case "Text":
        value = replaceStringParam(value.toString(), variables);
        if (value) {
          params[key] = value ? value.toString() : "";
        }
        break;
      case "Number":
      case "StepNumber":
        value = parseInt(replaceStringParam(value.toString(), variables));
        params[key] = value == "NaN" ? 0 : value;
        break;
      case "Bool":
        value = replaceStringParam(value.toString(), variables);
        params[key] = value != "false";
        break;
      case "Custom":
        params[key] = replaceValue(value, variables);
        break;
      default:
        params[key] = action.values.params[key];
    }
  }
  return params;
}

function replaceStringParam(str, variables) {
  var contents = helper.splitVariableName(str);
  var value = "";
  contents = contents.filter(content => content);
  contents.forEach(content => {
    if (helper.isVariableName(content)) {
      var variableName = content.replace(/[{}]/g, "");
      var variableValue = variables[variableName];
      if (contents.length == 1) {
        value = variableValue;
      } else {
        value += variableValue || "";
      }
    } else {
      value += content;
    }
  });
  return value;
}

function replaceValue(value, variables) {
  if (value) {
    if (typeof value == "string") {
      value = replaceStringParam(value, variables);
    } else if (Array.isArray(value)) {
      value = replaceArrayParam(value, variables);
    } else if (typeof value == "object") {
      value = replaceObjectParam(value, variables);
    }
  }
  return value;
}

function replaceObjectParam(object, variables) {
  var result = {};
  for (var key in object) {
    var value = object[key];
    result[key] = replaceValue(value, variables);
  }
  return result;
}

function replaceArrayParam(array, variables) {
  var result = array;
  array.forEach((value, i) => {
    result[i] = replaceValue(value, variables);
  });
  return result;
}

module.exports = Worker;
