class DataTable {
  constructor() {
    this.head = [];
    this.data = [];
  }
  
  addNewData() {
    var newData = this.head.map(item => {
      return "";
    });
    this.data.push(newData);
    this.updateData();
    return this.data.length - 1;
  }
  
  setData(rows, columns, value) {
    if (rows < this.data.length) {
      var d = this.data[rows];
      if (columns < d.length) {
        d[columns] = value
      }
    }
    this.updateData();
  }

  updateColumn() {
    var head = [];
    var data = this.data.map(item => {
      return [];
    });
    var list = $("coulmnList");
    if (!list) return;
    list.data.forEach((item, i) => {
      var cell = list.cell($indexPath(0, i));
      var name = cell.get("nameInput").text;
      var width = parseInt(cell.get("widthInput").text);
      width = width == "NaN" || width < 50 || width > 500 ? 100 : width;
      if (name) {
        head.push({
          name: name,
          width: width
        });
        var index = -1;
        this.head.every((h, j) => {
          if (h.name == name) {
            index = j;
            return false;
          }
          return true;
        });

        if (index == -1) {
          data.forEach(dataItem => {
            dataItem.push("");
          });
        } else {
          data.forEach((dataItem, di) => {
            dataItem.push(this.data[di][index + 1]);
          });
        }
      }
    });
    this.head = head;
    this.data = data;
    $ui.pop();
    this.updateData();
  }

  updateData() {
    var headView = $("headView");
    var dataList = $("dataList");
    var scrollView = $("scrollView");
    if(!dataList) return;
    
    var width = 0;
    var count = this.data.length;
    var numSize = $text.sizeThatFits({
      text: count.toString(),
      width: 320,
      font: $font(16)
    });
    var head = this.head.slice(0);
    head.unshift({
      name: "",
      width: numSize.width + 30
    });
    var headData = head.map(item => {
      width += item.width + 1;
      return {
        label: {
          text: item.name,
          info: item.width
        }
      };
    });
   
    var data = this.data.map((item, i) => {
      item = item.slice(0);
      item.unshift((i + 1).toString());
      return {
        matrix: {
          data: item.map((value, j) => {
            return {
              label: {
                text: value,
                info: head[j].width
              }
            };
          })
        }
      };
    });

    headView.data = headData;
    dataList.data = data;

    scrollView.contentSize = $size(width, 0);
    headView.updateLayout((make, view) => {
      if (width < view.super.frame.width) {
        make.width.equalTo(view.super.frame.width);
      } else {
        make.width.equalTo(width);
      }
    });
    dataList.updateLayout((make, view) => {
      if (width < view.super.frame.width) {
        make.width.equalTo(view.super.frame.width);
      } else {
        make.width.equalTo(width);
      }
    });
  }
  
  showSettings() {
    var self = this;
    var data = this.head.map(item => {
      return {
        nameInput: {
          text: item.name
        },
        widthInput: {
          text: item.width.toString()
        }
      };
    });
    $ui.push({
      props: {
        title: "Data Table Settings"
      },
      views: [
        {
          type: "list",
          props: {
            id: "coulmnList",
            data: data,
            actions: [
              {
                title: "Delete",
                color: $color("red")
              }
            ],
            template: {
              views: [
                {
                  type: "input",
                  props: {
                    id: "nameInput",
                    bgcolor: $color("clear"),
                    align: $align.left,
                    placeholder: "Name"
                  },
                  layout: (make, view) => {
                    make.left.top.bottom.inset(0);
                  },
                  events: {
                    returned: sender => {
                      sender.blur();
                    }
                  }
                },
                {
                  type: "view",
                  props: {
                    bgcolor: $color("#dddddd")
                  },
                  layout: function(make, view) {
                    make.top.bottom.inset(0);
                    make.left.equalTo(view.prev.right);
                    make.centerX.equalTo(view.super);
                    make.width.equalTo(0.5);
                  }
                },
                {
                  type: "input",
                  props: {
                    id: "widthInput",
                    bgcolor: $color("clear"),
                    type: $kbType.number
                  },
                  layout: (make, view) => {
                    make.left.equalTo(view.prev.right);
                    make.top.bottom.inset(0);
                    make.right.inset(10);
                  },
                  events: {
                    returned: sender => {
                      sender.blur();
                    }
                  }
                }
              ]
            }
          },
          layout: function(make, view) {
            make.top.left.right.inset(0);
          }
        },
        {
          type: "button",
          props: {
            title: "Add Column",
            icon: $icon("104", $color("green"), $size(20, 20)),
            bgcolor: $color("clear"),
            titleColor: $color("#888888"),
            contentHorizontalAlignment: 1,
            titleEdgeInsets: $insets(0, 5, 0, 0),
            contentEdgeInsets: $insets(0, 10, 0, 0)
          },
          layout: (make, view) => {
            make.left.right.inset(0);
            make.top.equalTo(view.prev.bottom);
            make.height.equalTo(40);
          },
          events: {
            tapped: sender => {
              var list = $("coulmnList");
              list.insert({
                indexPath: $indexPath(0, list.data.length),
                value: {
                  nameInput: {
                    text: ""
                  },
                  widthInput: {
                    text: "100"
                  }
                }
              });
            }
          }
        },
        {
          type: "button",
          props: {
            title: "Save"
          },
          layout: (make, view) => {
            make.left.right.inset(20);
            make.bottom.inset(10);
            make.top.equalTo(view.prev.bottom).offset(10);
          },
          events: {
            tapped: sender => {
              self.updateColumn();
            }
          }
        }
      ]
    });
  }

  show() {
    var self = this;
    $ui.push({
      props: {
        title: "Data Table"
      },
      views: [
        {
          type: "view",
          props: {
            bgcolor: $color("tint")
          },
          layout: (make, view) => {
            make.left.right.top.inset(0);
            make.height.equalTo(40);
          },
          views: [
            {
              type: "button",
              props: {
                id: "settingsButton",
                icon: $icon("002", $color("#ffffff"), $size(22, 22))
              },
              layout: (make, view) => {
                make.size.equalTo($size(40, 40));
                make.top.inset(0);
                make.left.inset(10);
              },
              events: {
                tapped: sender => {
                  self.showSettings();
                }
              }
            }
          ]
        },
        {
          type: "scroll",
          props: {
            id: "scrollView",
            bounces: false
          },
          layout: (make, view) => {
            make.top.equalTo(view.prev.bottom);
            make.left.right.bottom.inset(0);
          },
          views: [
            {
              type: "matrix",
              props: {
                id: "headView",
                bgcolor: $color("tint"),
                scrollEnabled: false,
                spacing: 0.5,
                template: {
                  views: [
                    {
                      type: "label",
                      props: {
                        textColor: $color("#ffffff")
                      },
                      layout: (make, view) => {
                        make.left.right.inset(10);
                        make.top.bottom.inset(0);
                      }
                    }
                  ]
                }
              },
              layout: (make, view) => {
                make.top.left.inset(0);
                make.height.equalTo(40);
              },
              events: {
                itemSize: function(sender, indexPath) {
                  var data = sender.object(indexPath);
                  var w = data.label.info;
                  return $size(w, 40);
                }
              }
            },
            {
              type: "list",
              props: {
                id: "dataList",
                alwaysBounceVertical: true,
                alwaysBounceHorizontal: false,
                showsVerticalIndicator: false,
                separatorHidden: true,
                rowHeight: 40,
                template: {
                  views: [
                    {
                      type: "matrix",
                      props: {
                        scrollEnabled: false,
                        template: {
                          props: {
                            bgcolor: $color("#ffffff"),
                            borderWidth: 0.25,
                            borderColor: $color("#cccccc")
                          },
                          views: [
                            {
                              type: "label",
                              layout: (make, view) => {
                                make.left.right.inset(10);
                                make.top.bottom.inset(0);
                              }
                            }
                          ]
                        }
                      },
                      events: {
                        itemSize: function(sender, indexPath) {
                          var data = sender.object(indexPath);
                          var w = data.label.info;
                          return $size(w, 40);
                        }
                      },
                      layout: $layout.fill
                    }
                  ]
                }
              },
              layout: (make, view) => {
                make.top.equalTo(view.prev.bottom);
                make.left.inset(0);
                make.height.equalTo(view.super).offset(-40);
              }
            }
          ]
        }
      ]
    });
    
    $thread.main({
      delay: 0.01,
      handler: function() {
        this.updateData();
      }.bind(this)
    });
    
  }
}

module.exports = DataTable;
