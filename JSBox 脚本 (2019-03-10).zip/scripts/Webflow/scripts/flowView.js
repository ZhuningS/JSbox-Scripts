var helper = require("./helper");
var Action = require("./action");
var actionPicker = require("./actionPicker");

class FlowView {
  constructor(flow) {
    this.flow = flow;

    this.actionViews = [];
    flow.actions.forEach((action, i) => {
      this.createActionView(i, action);
    });

    this.view = this.createListView();
    this.listView = this.view.get("listView");
    this.listView.data = flow.actions.map(() => {
      return {};
    });
  }

  createListView() {
    var self = this;
    return $ui.create({
      type: "view",
      views: [
        {
          type: "list",
          props: {
            id: "listView",
            reorder: true,
            selectable: false,
            separatorHidden: true,
            bgcolor: $color("clear"),
            contentInset: $insets(0, 0, 10, 0),
            template: {
              props: {
                bgcolor: $color("clear")
              }
            },
            header: {
              type: "view",
              views: [
                {
                  type: "button",
                  props: {
                    title: "+",
                    radius: 6,
                    borderWidth: 0.5,
                    borderColor: $color("#cccccc"),
                    titleColor: $color("#888888"),
                    bgcolor: $color("#efefef"),
                    font: $font("HelveticaNeue-UltraLight", 30),
                    titleEdgeInsets: $insets(0, 0, 6, 0)
                  },
                  layout: (make, view) => {
                    make.top.left.right.inset(10);
                    make.bottom.inset(0);
                    make.height.equalTo(60);
                  },
                  events: {
                    tapped: sender => {
                      self.insert(self.listView, null);
                    }
                  }
                }
              ]
            }
          },
          events: {
            forEachItem: (view, indexPath) => {
              var actionView = self.actionViews[indexPath.row];
              setActionViewInCellView(actionView, view);
            },
            rowHeight: (sender, indexPath) => {
              var action = self.flow.actions[indexPath.row];
              return action.viewHeight;
            },
            reorderMoved: (fromIndexPath, toIndexPath) => {
              self.flow.exchangeAction(fromIndexPath.row, toIndexPath.row);
              helper.exchange(
                self.actionViews,
                fromIndexPath.row,
                toIndexPath.row
              );
            }
          },
          layout: $layout.fill
        }
      ]
    });
  }

  createActionView(index, action) {
    var actionView = Action.createActionView(action);
    this.actionViews.splice(index, 0, actionView);
  }

  refreshHeight() {
    var listView = this.listView.runtimeValue();
    listView.$beginUpdates();
    listView.$endUpdates();
  }

  remove(action) {
    var index = this.flow.removeAction(action);
    this.actionViews.splice(index, 1);
    this.listView.delete(index);
  }

  insert(action) {
    var index = this.flow.actions.indexOf(action);
    index++;
    actionPicker.show(
      function(action) {
        this.flow.insertAction(index, action);
        this.createActionView(index, action);
        this.listView.insert({
          index: index,
          value: action
        });
        $thread.main({
          delay: 0.3,
          handler: function() {
            this.listView.scrollTo({
              indexPath: $indexPath(0, index)
            });
          }.bind(this)
        });
      }.bind(this)
    );
  }
}

function setActionViewInCellView(actionView, cellView) {
  for (var i in cellView.views) {
    var view = cellView.views[i].runtimeValue();
    view.$removeFromSuperview();
  }
  cellView.runtimeValue().$addSubview(actionView);
  actionView.updateLayout(make => {
    make.edges.inset(0);
  });
  actionView.relayout();
}

module.exports = FlowView;
