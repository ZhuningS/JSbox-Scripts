var Element = require("./element");

let PC_UA =
  "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_0) AppleWebKit/535.11 (KHTML, like Gecko) Chrome/17.0.963.56 Safari/535.11";

class Browser {
  constructor() {
    this.webView = createWebView(
      this.didFinish.bind(this),
      this.didFail.bind(this)
    );
    this.openPromiseResolve = null;
    this.openPromiseReject = null;
  }

  didFinish() {
    if (this.openPromiseResolve) {
      this.openPromiseResolve();
      this.openPromiseResolve = null;
    }
  }

  didFail(error) {
    if (this.openPromiseReject) {
      this.openPromiseReject(error);
      this.openPromiseReject = null;
    }
  }

  async wait() {
    await new Promise(function(resolve, reject) {
      $delay(0.3, function() {
        resolve();
      });
    });

    if (this.webView.progress < 1) {
      return new Promise(
        function(resolve, reject) {
          this.openPromiseResolve = resolve;
          this.openPromiseReject = reject;
        }.bind(this)
      );
    }
  }

  async getBodyElement() {
    var html = await this.eval("document.documentElement.innerHTML;");
    if (html) {
      return new Element(this, html, "html", 0);
    }
  }

  async clickElement(selectors, index) {
    var js = `
        var elements = document.querySelectorAll("${selectors}"); 
        var index = ${index};
        if (index < elements.length) {
          elements[index].click();
        }
    `;
    await this.eval(js);
  }

  async fireElementEvent(selectors, index, event) {
    var js = `
        var elements = document.querySelectorAll("${selectors}"); 
        var index = ${index};
        var event = "${event}";
        if (index < elements.length) {
          var evt
          if (event == "click" || event == "mouseover") {
             evt = document.createEvent('UIEvents');
          } else {
             evt = document.createEvent('HTMLEvents');
          }
          evt.initEvent(event,true,true);
          elements[index].dispatchEvent(evt);
        }
    `;
    await this.eval(js);
  }

  async setElementAttribute(selectors, index, name, value) {
    if (!name) {
      return;
    }
    value = btoa(encodeURIComponent(value));
    var js = `
        var elements = document.querySelectorAll("${selectors}"); 
        var value = decodeURIComponent(atob("${value}"));
        var index = ${index};
        if (index < elements.length) {
          var element = elements[index];
          element["${name}"] = value;
        }
    `;
    await this.eval(js);
  }

  async open(url) {
    return new Promise(
      function(resolve, reject) {
        this.openPromiseResolve = resolve;
        this.openPromiseReject = reject;
        this.webView.url = url;
      }.bind(this)
    );
  }

  async eval(script) {
    return new Promise(
      function(resolve, reject) {
        this.webView.eval({
          script: script,
          handler: function(result, error) {
            if (error) {
              reject(error);
            } else {
              resolve(result);
            }
          }
        });
      }.bind(this)
    );
  }

  setPC(isPC) {
    this.webView.ua = isPC ? PC_UA : "";
  }
}

function createWebView(didFinish, didFail) {
  return $ui.create({
    type: "web",
    props: {
      id: "webView",
      bgcolor: $color("#eeeeee")
    },
    layout: $layout.fill,
    events: {
      didFinish: (sender, navigation) => {
        if (!sender.loading) {
          didFinish();
        }
      },
      didFail: (sender, navigation, error) => {
        didFail(error);
      }
    }
  });
}

module.exports = Browser;
