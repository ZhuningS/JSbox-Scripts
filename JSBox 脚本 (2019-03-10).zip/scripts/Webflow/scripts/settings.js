function show(workflow, completed) {
  var icon = "";
  $ui.push({
    props: {
      title: "Settings",
      id: "settings"
    },
    views: [
      {
        type: "input",
        props: {
          id: "nameInput",
          text: workflow.name
        },
        layout: (make, view) => {
          make.top.left.right.inset(20);
          make.height.equalTo(40);
        }
      },
      {
        type: "button",
        props: {
          id: "iconButton",
          bgcolor: $color("clear"),
          icon: $icon(workflow.icon, $color("#aaaaaa"), $size(30, 30))
        },
        layout: (make, view) => {
          make.top.equalTo(view.prev.bottom).offset(20);
          make.size.equalTo($size(30, 30));
          make.centerX.equalTo(view.super);
        },
        events: {
          tapped: async sender => {
            icon = await $ui.selectIcon();
            icon = icon.substring(icon.lastIndexOf("_") + 1);
            icon = icon.substring(0, icon.lastIndexOf("."));
            $("iconButton").icon = $icon(
              icon,
              $color("#aaaaaa"),
              $size(30, 30)
            );
          }
        }
      },
      {
        type: "button",
        props: {
          title: "Done"
        },
        layout: (make, view) => {
          make.top.equalTo(view.prev.bottom).offset(20);
          make.left.right.inset(20);
          make.centerX.equalTo(view.super);
          make.height.equalTo(40);
        },
        events: {
          tapped: sender => {
            workflow.name = $("nameInput").text;
            workflow.icon = icon;
            completed();
            $ui.pop();
          }
        }
      }
    ]
  });
}

module.exports = {
  show
};
