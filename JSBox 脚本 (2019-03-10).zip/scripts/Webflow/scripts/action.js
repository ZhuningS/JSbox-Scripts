var helper = require("./helper");
var Workflow = require("scripts/workflow");
var Flow = require("./flow");
var notificationCenter = require("scripts/notificationCenter");

class Action {
  
  constructor(values) {
    this._id = "id_" + helper.getGUID();
    this.min = false;
    this.values = values || {
      params: {}
    };
    
    for (var key in this.config.params) {
      if (this.config.params[key] == "Flow") {
        this.values.params[key] = new Flow(this.values.params[key]);
      }
    }
  }

  get id() {
    return this._id;
  }

  get config() {
    return {
      title: "Action",
      privateVaribaleName: "",
      params: {
        param: "String"
      }
    };
  }

  async willBegin(worker, flow) {
    Action.actionWorking(this, true);
  }

  async didEnded(worker, flow) {
    Action.actionWorking(this, false);
  }

  async progressUpdate(worker, flow, p) {
    Action.updateActionProgress(this, p);
  }

  async handler(worker, flow, input, params) {
    return null;
  }

  getParamViewTappedHandler(param) {
    var type = this.config.params[param];
    switch (type) {
      case "Number":
      case "StepNumber":
      case "Bool":
        return function() {
          var paramView = $(this.id).get(param);
          var variableNames = Workflow.getVariableNames(this.id);
          if (paramView.get("valueView").hidden) {
            variableNames.push("$Clear");
          }
          $ui.menu({
            items: variableNames,
            handler: function(title, idx) {
              if (title == "$Clear") {
                paramView.get("variableNameLabel").hidden = true;
                paramView.get("valueView").hidden = false;
                paramView.get("variableNameLabel").text = "";
                if (type == "StepNumber") {
                  paramView.get("valueView").prev.text =
                    param + "：" + paramView.get("valueView").value;
                }
              } else {
                paramView.get("variableNameLabel").hidden = false;
                paramView.get("valueView").hidden = true;
                paramView.get("variableNameLabel").text = "{{" + title + "}}";
                if (type == "StepNumber") {
                  paramView.get("valueView").prev.text = param;
                }
              }
            }
          });
        }.bind(this);
    }
    return null;
  }

  updateParamViewHeightLayout() {
    var actionView = $(this.id);
    if (actionView) {
      for (var i = 0; i < arguments.length; i++) {
        var param = arguments[i];
        var paramView = actionView.get(param);
        var height = this.getParamViewHeight(param);
        paramView.updateLayout((make, view) => {
          make.height.equalTo(height);
        });
        $ui.animate({
          duration: 0.3,
          animation: function() {
            paramView.relayout();
          }
        });
      }
    }
    this.refreshActionViewHeight();
  }

  refreshActionViewHeight() {
    notificationCenter.post(Action.eventIds.changedHeight, this);
  }

  update() {
    var actionView = $(this.id);
    if (!actionView) {
      return;
    }
    this.values.variableName = actionView.get("variableName").text;
    for (var param in this.config.params) {
      this.updateParam(param);
      if (this.config.params[param] == "Flow") {
        this.values.params[param].update();
      }
    }
  }

  updateParam(param) {
    var type = this.config.params[param];
    var paramView = $(this.id).get(param);
    var valueView = paramView.get("valueView");
    var variableNameLabel = paramView.get("variableNameLabel");
    switch (type) {
      case "String":
      case "Text":
        this.values.params[param] = valueView.text || "";
        break;
      case "Number":
        if (variableNameLabel.text) {
          this.values.params[param] = variableNameLabel.text;
        } else {
          this.values.params[param] = valueView.text || 0;
        }
        break;
      case "StepNumber":
        if (variableNameLabel.text) {
          this.values.params[param] = variableNameLabel.text;
        } else {
          this.values.params[param] = valueView.value;
        }
        break;
      case "Bool":
        if (variableNameLabel.text) {
          this.values.params[param] = variableNameLabel.text;
        } else {
          this.values.params[param] = valueView.on;
        }
        break;
    }
  }

  get viewHeight() {
    if (this.min) {
      return Action.actionViewMinHeight;
    }
    var height = Action.actionViewMinHeight;
    for (var param in this.config.params) {
      height += this.getParamViewHeight(param);
      height += 0.5;
    }
    if (height > Action.actionViewMinHeight) {
      height += 10;
    }
    return height;
  }

  get viewObject() {
    if (!this.config.params) {
      return null;
    }

    var paramViewObjects = [];

    for (var param in this.config.params) {
      if (paramViewObjects.length > 0) {
        paramViewObjects.push(Action.creareSeparatorViewObject());
      }

      var paramViewObject = this.getParamViewObject(param);
      paramViewObjects.push(paramViewObject);
    }

    return {
      type: "view",
      views: paramViewObjects,
      layout: $layout.fill
    };
  }

  getParamViewObject(param) {
    var childViewObjects = this.getParamChildViewObjects(param);
    var tappedHandler = this.getParamViewTappedHandler(param);
    var touchesBegan = null;
    var touchesEnded = null;
    if (tappedHandler) {
      touchesBegan = (sender, location) => {
        sender.bgcolor = $color("#e0e0e0");
        sender.animator.makeBackground($color("#ffffff")).animate(0.3);
      };
      touchesEnded = (sender, location) => {
        tappedHandler();
      };
    }

    var height = this.getParamViewHeight(param);
    return {
      type: "view",
      props: {
        id: param,
        clipsToBounds: true
      },
      views: childViewObjects,
      layout: (make, view) => {
        if (view.prev) {
          make.top.equalTo(view.prev.bottom);
        } else {
          make.top.inset(0);
        }
        make.left.right.inset(0);
        make.height.equalTo(height);
      },
      events: {
        touchesBegan: touchesBegan,
        touchesEnded: touchesEnded
      }
    };
  }

  getParamChildViewObjects(param) {
    var viewObjects = Action.createParamViewObjects(this, param);
    return viewObjects;
  }

  getParamViewHeight(param) {
    var type = this.config.params[param];
    switch (type) {
      case "String":
      case "Bool":
      case "Number":
      case "StepNumber":
        return 50;
      case "Text":
        return 100;
    }
    return 50;
  }
}

Action.creareSeparatorViewObject = function() {
  return {
    type: "view",
    props: {
      bgcolor: $color("#dddddd")
    },
    layout: function(make, view) {
      make.left.right.inset(10);
      make.top.equalTo(view.prev.bottom);
      make.height.equalTo(0.5);
    }
  };
};

Action.getAction = function(actionName) {
  var Action = require("./actions/action_" + actionName);
  var action = new Action();
  action.values.action = actionName;
  return action;
};

Action.createParamViewObjects = function(action, param) {
  var type = action.config.params[param];
  var value = action.values.params[param];
  var variableValue = helper.isVariableName(value) ? value : null;
  var viewObjects = [
    {
      type: "label",
      props: {
        id: "paramTitleLabel",
        font: $font("bold", 16),
        text: param
      },
      layout: function(make, view) {
        make.top.bottom.inset(0);
        make.left.inset(10);
        make.width.equalTo(400).priority(1);
      }
    }
  ];
  switch (type) {
    case "Flow":
      var imageLeft =
        $text.sizeThatFits({
          text: param,
          width: 300,
          font: $font(16)
        }).width *
          2 +
        20;
      viewObjects = [
        {
          type: "button",
          props: {
            title: param,
            font: $font(16),
            icon: $icon("030", $color("#eeeeee"), $size(20, 20)),
            bgcolor: $color("clear"),
            titleColor: $color("#333333"),
            imageEdgeInsets: $insets(0, imageLeft, 0, 0),
            titleEdgeInsets: $insets(0, 0, 0, 40)
          },
          layout: (make, view) => {
            make.edges.inset(0);
          },
          events: {
            tapped: sender => {
              sender.bgcolor = $color("#e0e0e0");
              sender.animator.makeBackground($color("#ffffff")).animate(0.3);
              var flow = action.values.params[param];
              notificationCenter.post(Action.eventIds.toChildFlow, flow);
            }
          }
        }
      ];
      break;
    case "String":
    case "Number":
      var kbType = $kbType.default;
      if (type == "Number") {
        kbType = $kbType.number;
        if (!value || variableValue) {
          value = "0";
        }
      }
      viewObjects.push({
        type: "input",
        props: {
          id: "valueView",
          align: $align.right,
          bgcolor: $color("clear"),
          text: (value || "").toString(),
          type: kbType,
          hidden: type == "Number" && variableValue != null,
          info: {
            actionId: type != "Number" ? action.id : null
          }
        },
        layout: (make, view) => {
          make.left.equalTo(view.prev.right).offset(5);
          make.top.right.inset(10);
          make.centerY.equalTo(view.super);
          make.width.greaterThanOrEqualTo(100);
        },
        events: {
          returned: sender => {
            sender.blur();
          },
          didEndEditing: sender => {
            if (sender.type == $kbType.number) {
              if (!sender.text.match(/^\d*$/)) {
                sender.text = "0";
              }
            }
          }
        }
      });
      break;
    case "Text":
      viewObjects = [
        {
          type: "text",
          props: {
            id: "valueView",
            text: value,
            info: {
              actionId: action.id
            }
          },
          layout: (make, view) => {
            make.edges.inset(0);
          }
        }
      ];
      break;
    case "StepNumber":
      if (variableValue) {
        value = 1;
      } else {
        viewObjects[0].props.text = param + " : " + (value || 1);
      }
      viewObjects.push({
        type: "stepper",
        props: {
          id: "valueView",
          value: value || 1,
          min: 0,
          hidden: variableValue != null
        },
        layout: (make, view) => {
          make.left.equalTo(view.prev.right).offset(5);
          make.right.inset(10);
          make.centerY.equalTo(view.prev);
        },
        events: {
          changed: sender => {
            sender.prev.text = param + " : " + sender.value;
          }
        }
      });
      break;
    case "Bool":
      if (variableValue) {
        value = true;
      }
      viewObjects.push({
        type: "switch",
        props: {
          id: "valueView",
          on: value,
          hidden: variableValue != null
        },
        layout: (make, view) => {
          make.left.equalTo(view.prev.right).offset(5);
          make.right.inset(10);
          make.centerY.equalTo(view.prev);
        }
      });
      break;
  }

  switch (type) {
    case "Number":
    case "StepNumber":
    case "Bool":
      viewObjects.push({
        type: "label",
        props: {
          id: "variableNameLabel",
          text: variableValue,
          hidden: !variableValue
        },
        layout: (make, view) => {
          make.right.inset(10);
          make.centerY.equalTo(view.super);
        }
      });
      break;
  }
  return viewObjects;
};

Action.createButtonViewObjects = function(title, value, buttonTapped) {
  return [
    {
      type: "label",
      props: {
        id: "paramTitleLabel",
        font: $font("bold", 16),
        text: title
      },
      layout: (make, view) => {
        make.top.bottom.inset(0);
        make.left.inset(10);
        make.width.equalTo(400).priority(1);
      }
    },
    {
      type: "button",
      props: {
        id: "valueView",
        bgcolor: $color("clear"),
        titleColor: $color("tint"),
        title: value
      },
      layout: (make, view) => {
        make.top.bottom.inset(0);
        make.right.inset(10);
      },
      events: {
        tapped: sender => {
          if (buttonTapped) {
            buttonTapped(sender);
          }
        }
      }
    }
  ];
};

Action.createTabViewObjects = function(title, value, items, tabChanged) {
  value = value || items[0];
  var index = items.indexOf(value);
  return [
    {
      type: "label",
      props: {
        id: "paramTitleLabel",
        font: $font("bold", 16),
        text: title
      },
      layout: (make, view) => {
        make.top.bottom.inset(0);
        make.left.inset(10);
        make.width.equalTo(400).priority(1);
      }
    },
    {
      type: "tab",
      props: {
        id: "valueView",
        items: items,
        index: index
      },
      layout: (make, view) => {
        make.centerY.equalTo(view.super);
        make.right.inset(10);
      },
      events: {
        changed: sender => {
          if (tabChanged) {
            tabChanged();
          }
        }
      }
    }
  ];
};

Action.createActionView = function(action) {
  var actionView = action.viewObject;
  var views = [
    {
      type: "view",
      props: {
        id: action.id,
        bgcolor: $color("#efefef"),
        radius: 6,
        borderWidth: 0.5,
        borderColor: $color("#cccccc")
      },
      views: [
        {
          type: "button",
          props: {
            id: "nameButton",
            font: $font(16),
            bgcolor: $color("clear"),
            titleColor: $color("#333333"),
            contentHorizontalAlignment: 1,
            title: "# " + action.config.title
          },
          layout: (make, view) => {
            make.left.inset(15);
            make.top.inset(0);
            make.height.equalTo(40);
          },
          events: {
            tapped: sender => {
              action.min = !action.min;
              action.refreshActionViewHeight();
            }
          }
        },
        {
          type: "input",
          props: {
            id: "variableName",
            align: $align.left,
            bgcolor: $color("#ffffff"),
            text: action.values.variableName,
            hidden: true,
            borderColor: $color("red"),
            placeholder: "Variable Name"
          },
          layout: function(make, view) {
            make.right.equalTo(-90);
            make.centerY.equalTo(view.prev);
            make.size.equalTo($size(150, 30));
          },
          events: {
            didBeginEditing: sender => {
              sender.hidden = false;
              sender.next.hidden = true;
            },
            returned: sender => {
              sender.blur();
            },
            didEndEditing: sender => {
              sender.next.hidden = false;
              sender.hidden = true;
              if (!helper.verifyVaribaleName(sender.text)) {
                sender.text = "";
                sender.borderWidth = 1;
                sender.focus();
              } else {
                sender.borderWidth = 0;
              }
            }
          }
        },
        {
          type: "button",
          props: {
            title: "Var",
            titleColor: $color("#888888"),
            bgcolor: $color("clear"),
            font: $font("HelveticaNeue-Light", 16),
            titleEdgeInsets: $insets(0, 0, 0, 0)
          },
          layout: (make, view) => {
            make.left.equalTo($("nameButton").right);
            make.top.inset(0);
            make.size.equalTo($size(40, 40));
          },
          events: {
            tapped: sender => {
              sender.prev.focus();
            }
          }
        },
        {
          type: "button",
          props: {
            title: "+",
            titleColor: $color("#888888"),
            bgcolor: $color("clear"),
            font: $font("HelveticaNeue-UltraLight", 30),
            titleEdgeInsets: $insets(0, 0, 6, 0)
          },
          layout: (make, view) => {
            make.left.equalTo(view.prev.right);
            make.top.inset(0);
            make.size.equalTo($size(40, 40));
          },
          events: {
            tapped: sender => {
              notificationCenter.post(
                Action.eventIds.tappedInsertButton,
                action
              );
            }
          }
        },
        {
          type: "button",
          props: {
            id: "removeButton",
            title: "x",
            titleColor: $color("#888888"),
            bgcolor: $color("clear"),
            font: $font("HelveticaNeue-UltraLight", 26),
            titleEdgeInsets: $insets(0, 0, 4, 0)
          },
          layout: (make, view) => {
            make.left.equalTo(view.prev.right);
            make.top.inset(0);
            make.right.inset(5);
            make.size.equalTo($size(40, 40));
          },
          events: {
            tapped: sender => {
              notificationCenter.post(
                Action.eventIds.tappedRemoveButton,
                action
              );
            }
          }
        },
        {
          type: "view",
          props: {
            bgcolor: $color("#ffffff"),
            radius: 4,
            borderWidth: 0.1,
            borderColor: $color("#cccccc")
          },
          layout: (make, view) => {
            make.top.equalTo(40);
            make.left.right.bottom.inset(10);
          },
          views: [actionView]
        },
        {
          type: "view",
          props: {
            id: "progressView",
            bgcolor: $color("tint"),
            alpha: 0.2,
            userInteractionEnabled: false
          }
        }
      ],
      layout: (make, view) => {
        make.bottom.inset(0);
        make.top.left.right.inset(10);
      }
    }
  ];

  return $ui.create({
    type: "view",
    views: views
  });
};

Action.updateActionProgress = function(action, p) {
  var actionView = $(action.id);
  if (!actionView) {
    return;
  }

  var progressView = actionView.get("progressView");
  progressView.frame = $rect(
    0,
    0,
    progressView.frame.width,
    progressView.super.frame.height
  );

  var rect = $rect(
    0,
    0,
    progressView.super.frame.width * p,
    progressView.super.frame.height
  );

  if (p == 1) {
    $ui.animate({
        duration: 0.4,
        async: true,
        animation: () => {
          progressView.frame = rect;
        }
      }).then(() => {
        return $ui.animate({
          duration: 1,
          async: true,
          animation: function() {
            progressView.alpha = 0;
          }
        });
      }).then(() => {
        progressView.frame = $zero.rect;
        progressView.alpha = 0.2;
      });
  } else {
    $ui.animate({
      duration: 0.4,
      animation: () => {
        progressView.frame = rect;
      }
    });
  }
};

Action.actionWorking = function(action, working) {
  var actionView = $(action.id);
  if (!actionView) {
    return;
  }
  var btn = actionView.get("removeButton");
  if (working) {
    btn.startLoading();
    btn.title = "";
  } else {
    btn.stopLoading();
    btn.title = "x";
  }
};

Action.actionViewMinHeight = 50;

Action.eventIds = {
  toChildFlow: "toChildFlow",
  tappedInsertButton: "tappedInsertButton",
  tappedRemoveButton: "tappedRemoveButton",
  changedHeight: "changedHeight"
};

module.exports = Action;
