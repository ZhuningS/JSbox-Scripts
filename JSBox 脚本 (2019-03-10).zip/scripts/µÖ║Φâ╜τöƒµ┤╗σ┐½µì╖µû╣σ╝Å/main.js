const data = [{
  title: {
    text: "门禁系统"
  },
  icon: {
    src: "assets/jb.png"
  },
  url:"JiabaoLifePro://opendoor"
},
{
  title: {
    text: "支付宝扫码"
  },
  icon: {
    src: "assets/15.png"
  },
  url:"alipayqr://platformapi/startapp?saId=10000007"
},
{
  title: {
    text: "支付宝付款码"
  },
  icon: {
    src: "assets/16.png"
  },
  url:"alipayqr://platformapi/startapp?saId=20000056"
},
{
  title: {
    text: "微信扫码"
  },
  icon: {
    src: "assets/14.png"
  },
  url:"weixin://scanqrcode"
},
{
  title: {
    text: "小米空气净化器"
  },
  icon: {
    src: "assets/4.png"
  },
  url:"mihome://open"
},
{
  title: {
    text: "畅呼吸空气净化器"
  },
  icon: {
    src: "assets/13.png"
  },
  url:"aircleaner2405://open"
},
{
    title: {
    text: "Surge 开启"
  },
  icon: {
    src: "assets/5.png"
  },
  url:"surge:///start"
},
{
    title: {
    text: "Surge 关闭"
  },
  icon: {
    src: "assets/55.png"
  },
  url:"surge:///stop"
},
{
    title: {
    text: "X.cat"
  },
  icon: {
    src: "assets/2.png"
  },
  url:"XcatPro://"
},
{
    title: {
    text: "Thor 开启"
  },
  icon: {
    src: "assets/7.png"
  },
  url:"thor://sniffer.gui/launch?filter_name="
},
{
    title: {
    text: "Thor 关闭"
  },
  icon: {
    src: "assets/77.png"
  },
  url:"thor://sniffer.gui/shutdown"
},
{
    title: {
    text: "Ai search2"
  },
  icon: {
    src: "assets/12.png"
  },
  url:"aisearch2://clipboard"
},]

$ui.render({
  props: {
    title: "智能生活"
  },
  views: [{
    type: "matrix",
    props: {
      columns: 3,
      itemHeight: 55,
      spacing: 5,
      template: [{
  type: "blur",
  props: {
    radius: 10.0,  
    style: 1 // 0 ~ 5
  },
  layout: $layout.fill
},
        {
          type: "label",
          props: {
            id: "title",
            textColor: $color("black"),
            bgcolor: $color("clear"),
            font: $font(13)
          },
          layout(make, view) {
            make.bottom.inset(0)
            make.centerX.equalTo(view.super)
            make.height.equalTo(30)
          }
        },
        {
          type: "image",
          props: {
            id: "icon",
            bgcolor: $color("clear")
          },
          layout(make, view) {
            make.top.inset(7)
            make.centerX.equalTo(view.super)
            make.size.equalTo(17)
          }
        }
      ],
      data: data
    },
    layout: $layout.fill,
    events:{
      didSelect(sender,indexPath,data){
        $app.openURL(data.url)
      }
    }
  }]
})