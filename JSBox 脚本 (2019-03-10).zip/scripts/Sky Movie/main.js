var buyMeaCoffee = require('scripts/coffee')
buyMeaCoffee.showcoffee()

if ($app.env == $env.today) {
  var labelHeight = 15
} else {
  var labelHeight = 90 * $device.info.screen.height / 812
}

$ui.render({
  props: {
    id: "mainView",
    navBarHidden: 1,
    statusBarStyle: 0,
    homeIndicatorHidden: 1
  },
  views: [{
    type: "label",
    props: {
      id: "searchlabel",
      text: $l10n("SEARCH"),
      align: $align.center,
      font: $font("HelveticaNeue-Bold", 30)
    },
    layout: function (make, view) {
      make.top.inset(labelHeight)
      make.left.inset(15)
    },
    events: {
      tapped: function (sender) {
        $app.close()
      }
    }
  }, {
    type: "button",
    props: {
      icon: $icon("002", $color("black")),
      bgcolor: $color("clear")
    },
    layout: function (make, view) {
      make.centerY.equalTo($("searchlabel").centerY)
      make.right.inset(15)
    },
    events: {
      tapped: function (sender) {
        var settings = require("scripts/settings")
        settings.settingView("mainView")
      },
      longPressed: function (sender) {
        $cache.clear()
        history.historyDataUpdate()
        $device.taptic(2)
      }
    }
  }, {
    type: "input",
    props: {
      text: $clipboard.text,
      bgcolor: $color("white"),
      borderWidth: 1.2,
      borderColor: $color("#662f0a"),
      placeholder: $l10n("KEYWORDS")
    },
    layout: function (make, view) {
      make.left.inset(30)
      make.top.equalTo($("searchlabel").bottom).inset(55)
      make.height.equalTo(30)
      make.right.inset(115)
    },
    events: {
      returned: function (sender) {
        $("input").blur()
      }
    }
  }, {
    type: "button",
    props: {
      id: "searchBt",
      src: "assets/popcorn.png"
    },
    layout: function (make, view) {
      make.left.equalTo($("input").right).inset(10)
      make.top.equalTo($("searchlabel").bottom).inset(49)
      make.size.equalTo($size(40, 40))
    },
    events: {
      tapped: function (sender) {
        $("input").blur()
        search($("input").text, "skyMovie", "mainView")
      },
      longPressed: function (sender) {
        alert("Coming Soon")
      }
    }
  }, {
    type: "button",
    props: {
      id: "cokeBt",
      src: "assets/coke.png"
    },
    layout: function (make, view) {
      make.left.equalTo($("searchBt").right).inset(5)
      make.top.equalTo($("searchlabel").bottom).inset(49)
      make.size.equalTo($size(40, 40))
    },
    events: {
      tapped: function (sender) {
        $("input").blur()
        search($("input").text, "douban", "mainView")
      },
      longPressed: function (sender) {
        alert("Coming Soon")
      }
    }
  }, {
    type: "matrix",
    props: {
      id: "historyMatrix",
      columns: 2,
      itemHeight: 305,
      spacing: 5,
      bgcolor: $color("clear"),
      template: {
        props: {
          bgcolor: $color("clear")
        },
        views: [
          {
            type: "view",
            props: {
              clipsToBounds: false,
              bgcolor: $color("#EFEFF4")
            },
            layout: function (make, view) {
              make.edges.insets($insets(10, 0, 10, 0))
              shadow(view)
            },
            views: [{
              type: "image",
              props: {
                id: "historyCover",
                radius: 5
              },
              layout: function (make, view) {
                make.top.left.right.inset(0)
                make.centerX.equalTo(view.super.centerX)
                make.height.equalTo(235)
              },
              views: [{
                type: "label",
                props: {
                  id: "historyMovieTitle",
                  textColor: $color("white"),
                  bgcolor: $color("orange"),
                  align: $align.left,
                  font: $font("HelveticaNeue-Bold", 10),
                  radius: 3,
                  alpha: 0.9
                },
                layout: function (make, view) {
                  make.top.left.inset(5)
                }
              }, {
                type: "label",
                props: {
                  id: "historyScore",
                  textColor: $color("white"),
                  bgcolor: $color("black"),
                  align: $align.left,
                  font: $font("HelveticaNeue-Bold", 13),
                  radius: 3,
                  alpha: 0.9
                },
                layout: function (make, view) {
                  make.bottom.right.inset(5)
                }
              }]
            }, {
              type: "label",
              props: {
                id: "historyName",
                textColor: $color("darkGray"),
                align: $align.left,
                font: $font("HelveticaNeue-Bold", 15),
                radius: 3,
                alpha: 0.9
              },
              layout: function (make, view) {
                make.top.equalTo($("historyCover").bottom).inset(5)
                make.left.inset(0)
                make.right.inset(5)
              }
            }, {
              type: "label",
              props: {
                id: "historyTags",
                textColor: $color("gray"),
                align: $align.left,
                font: $font("HelveticaNeue-Bold", 13),
                radius: 3,
                alpha: 0.9
              },
              layout: function (make, view) {
                make.top.equalTo($("historyName").bottom).inset(5)
                make.left.inset(5)
                make.right.inset(5)
              }
            }]
          }
        ]
      }
    },
    events: {
      didSelect: function (sender, indexPath, data) {
        var details = require("scripts/details")
        var historyType = data.historyMovieTitle.text.match(/\d{4}/)
        if (historyType) {
          details.resultDetails(data.historyName.info, "mainView", "douban")
        } else {
          details.resultDetails(data.historyName.info, "mainView", "skyMovie")
        }
        $delay(2, function () {
          history.history(data)
        })
      },
      didLongPress: function (sender, indexPath, data) {
        history.delHistory(data.historyName.info)
        $device.taptic(2)
      }
    },
    layout: function (make, view) {
      make.top.equalTo($("input").bottom).inset(55)
      make.left.right.bottom.inset(0)
    }
  }]
})

function search(keywords, type, viewId) {
  if (keywords) {
    var search = require("scripts/search")
    search.search(keywords, type, viewId)
  }
}

function shadow(view) {
  var layer = view.runtimeValue().invoke("layer")
  layer.invoke("setCornerRadius", 5)
  layer.invoke("setShadowOffset", $size(3, 3))
  layer.invoke("setShadowColor", $color("gray").runtimeValue().invoke("CGColor"))
  layer.invoke("setShadowOpacity", 0.3)
  layer.invoke("setShadowRadius", 5)
}

var history = require("scripts/history")
history.historyDataUpdate()

if ($context.text) {
  $("input").text = $context.text
}