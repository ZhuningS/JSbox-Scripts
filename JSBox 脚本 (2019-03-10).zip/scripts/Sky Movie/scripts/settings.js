function settingView(id) {
    var keys = JSON.parse($file.read("assets/settings.json").string)
    var settingViews = {
        type: "view",
        props: {
            id: "settingViews",
            bgcolor: $color("clear"),
            alpha: 0
        },
        layout: $layout.fill,
        views: [{
            type: "blur",
            props: {
                alpha: 0.95,
                style: 1
            },
            layout: $layout.fill,
            events: {
                tapped: function (sender) {
                    $ui.animate({
                        duration: 0.3,
                        animation: function () {
                            $("settingListView").scale(1)
                            $("settingViews").alpha = 0
                        }
                    })
                }
            }
        }, {
            type: "view",
            props: {
                id: "settingListView",
                bgcolor: $color("white")
            },
            layout: function (make, view) {
                make.center.equalTo(view.super)
                make.size.equalTo($size(300, 440))
                shadow(view)
            },
            views: [{
                type: "list",
                props: {
                    bgcolor: $color("clear"),
                    scrollEnabled: 0,
                    header: {
                        type: "label",
                        props: {
                            id: "settingsLabel",
                            height: 60,
                            text: "  " + $l10n("SETTINGS"),
                            align: $align.left,
                            font: $font("HelveticaNeue-Bold", 30)
                        }
                    },
                    actions: [
                        {
                            title: $l10n("SIGNUP"),
                            color: $color("red"),
                            handler: function (sender, indexPath) {
                                if (indexPath.section == 0) {
                                    $safari.open({ url: "https://www.kdy666.com" })
                                } else if (indexPath.section == 1) {
                                    $safari.open({ url: "https://airtable.com" })
                                } else if (indexPath.section == 2) {
                                    $safari.open({ url: "http://imdbapi.net" })
                                }
                            }
                        },
                    ],
                    data: [
                        {
                            title: "Movie",
                            rows: [{
                                type: "input",
                                props: {
                                    id: "movieTokenInput",
                                    text: keys.movieToken,
                                    textColor: $color("darkGray"),
                                    placeholder: $l10n("MOVIETOKEN"),
                                    bgcolor: $color("clear"),
                                    accessoryView: {
                                        type: "label",
                                        props: {
                                            id: "movieTokenLabel",
                                            text: keys.movieToken,
                                            height: 44,
                                            bgcolor: $color("white"),
                                            alpha: 0.8
                                        },
                                        events: {
                                            tapped: function (sender) {

                                            }
                                        },
                                        layout: $layout.fill,
                                        views: [{
                                            type: "button",
                                            props: {
                                                icon: $icon("106", $color("black")),
                                                bgcolor: $color("clear"),
                                                alpha: 0.8
                                            },
                                            layout: function (make, view) {
                                                make.centerY.equalTo(view.super)
                                                make.right.inset(5)
                                            },
                                            events: {
                                                tapped: function (sender) {
                                                    $("movieTokenInput").text = $("movieTokenInput").text + $clipboard.text
                                                    $("movieTokenLabel").text = $("movieTokenInput").text
                                                }
                                            }
                                        }]
                                    }
                                },
                                layout: $layout.fill,
                                events: {
                                    returned: function (sender) {
                                        $("movieTokenInput").blur()
                                    },
                                    changed: function (sender) {
                                        $("movieTokenLabel").text = $("movieTokenInput").text
                                    }
                                }
                            }]
                        },
                        {
                            title: "Airtable",
                            rows: [{
                                type: "input",
                                props: {
                                    id: "airtableKeyInput",
                                    text: keys.airtableKey,
                                    textColor: $color("darkGray"),
                                    placeholder: $l10n("AIRTABLEKEY"),
                                    bgcolor: $color("clear"),
                                    accessoryView: {
                                        type: "label",
                                        props: {
                                            id: "airtableKeyLabel",
                                            text: keys.airtableKey,
                                            height: 44,
                                            bgcolor: $color("white"),
                                            alpha: 0.8
                                        },
                                        events: {
                                            tapped: function (sender) {

                                            }
                                        },
                                        layout: $layout.fill,
                                        views: [{
                                            type: "button",
                                            props: {
                                                icon: $icon("106", $color("black")),
                                                bgcolor: $color("clear"),
                                                alpha: 0.8
                                            },
                                            layout: function (make, view) {
                                                make.centerY.equalTo(view.super)
                                                make.right.inset(5)
                                            },
                                            events: {
                                                tapped: function (sender) {
                                                    $("airtableKeyInput").text = $("airtableKeyInput").text + $clipboard.text
                                                    $("airtableKeyLabel").text = $("airtableKeyInput").text
                                                }
                                            }
                                        }]
                                    }
                                },
                                layout: $layout.fill,
                                events: {
                                    returned: function (sender) {
                                        $("airtableKeyInput").blur()
                                    },
                                    changed: function (sender) {
                                        $("airtableKeyLabel").text = $("airtableKeyInput").text
                                    }
                                }
                            }]
                        },
                        {
                            title: "IMDb",
                            rows: [{
                                type: "input",
                                props: {
                                    id: "imdbKeyInput",
                                    text: keys.imdbKey,
                                    textColor: $color("darkGray"),
                                    placeholder: $l10n("IMDBKEY"),
                                    bgcolor: $color("clear"),
                                    accessoryView: {
                                        type: "label",
                                        props: {
                                            id: "imdbKeyLabel",
                                            text: keys.imdbKey,
                                            height: 44,
                                            bgcolor: $color("white"),
                                            alpha: 0.8
                                        },
                                        events: {
                                            tapped: function (sender) {

                                            }
                                        },
                                        layout: $layout.fill,
                                        views: [{
                                            type: "button",
                                            props: {
                                                icon: $icon("106", $color("black")),
                                                bgcolor: $color("clear"),
                                                alpha: 0.8
                                            },
                                            layout: function (make, view) {
                                                make.centerY.equalTo(view.super)
                                                make.right.inset(5)
                                            },
                                            events: {
                                                tapped: function (sender) {
                                                    $("imdbKeyInput").text = $("imdbKeyInput").text + $clipboard.text
                                                    $("imdbKeyLabel").text = $("imdbKeyInput").text
                                                }
                                            }
                                        }]
                                    }
                                },
                                layout: $layout.fill,
                                events: {
                                    returned: function (sender) {
                                        $("imdbKeyInput").blur()
                                    },
                                    changed: function (sender) {
                                        $("imdbKeyLabel").text = $("imdbKeyInput").text
                                    }
                                }
                            }]
                        }
                    ]
                },
                layout: $layout.fill,
            }, {
                type: "button",
                props: {
                    icon: $icon("058", $color("black")),
                    bgcolor: $color("clear")
                },
                layout: function (make, view) {
                    make.centerY.equalTo($("settingsLabel").centerY)
                    make.right.inset(15)
                },
                events: {
                    tapped: function (sender) {
                        var buyMeaCoffee = require('scripts/coffee')
                        buyMeaCoffee.coffee("settingViews")
                    },
                    longPressed: function (sender) {
                        $safari.open({ url: "https://airtable.com/shrA1vmSMRtTZBdqb" })
                        $device.taptic(2)
                    }
                }
            }, {
                type: "button",
                props: {
                    src: "assets/popcorn.png"
                },
                layout: function (make, view) {
                    make.centerX.equalTo(view.super)
                    make.size.equalTo($size(50, 50))
                    make.bottom.inset(15)
                },
                events: {
                    tapped: function (sender) {
                        keys.movieToken = $("movieTokenInput").text
                        keys.airtableKey = $("airtableKeyInput").text
                        keys.imdbKey = $("imdbKeyInput").text
                        $file.write({
                            data: $data({ string: JSON.stringify(keys) }),
                            path: "assets/settings.json"
                        })
                        $ui.animate({
                            duration: 0.3,
                            animation: function () {
                                $("settingListView").scale(1)
                                $("settingViews").alpha = 0
                            }
                        })
                    }
                }
            }]
        }]
    }
    $(id).add(settingViews)
    $ui.animate({
        duration: 0.5,
        animation: function () {
            $("settingViews").alpha = 1
            $("settingListView").scale(1.1)
        }
    })
}

module.exports = {
    settingView: settingView
}

function shadow(view) {
    var layer = view.runtimeValue().invoke("layer")
    layer.invoke("setCornerRadius", 5)
    layer.invoke("setShadowOffset", $size(3, 3))
    layer.invoke("setShadowColor", $color("gray").runtimeValue().invoke("CGColor"))
    layer.invoke("setShadowOpacity", 0.3)
    layer.invoke("setShadowRadius", 5)
}