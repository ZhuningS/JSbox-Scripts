async function doubanView(id) {
    $ui.push({
        props: {
            id: "douBanView",
            navBarHidden: 1,
            statusBarHidden: 1,
            homeIndicatorHidden: 1
        },
        views: [{
            type: "web",
            props: {
                url: "https://movie.douban.com/subject/" + id,
            },
            layout: $layout.fill
        }, {
            type: "blur",
            props: {
                style: 1,
                circular: true
            },
            layout: function (make, view) {
                make.right.bottom.inset(20)
                make.size.equalTo($size(50, 50))
            },
            views: [{
                type: "button",
                props: {
                    src: "assets/coke.png"
                },
                layout: $layout.fill,
                events: {
                    tapped: function (sender) {
                        $ui.pop()
                    },
                    doubleTapped: function (sender) {
                        $("web").goBack()
                    },
                    longPressed: function (sender) {
                        $ui.menu({
                            items: [$l10n("FEED"), $l10n("SHARE")],
                            handler: (title, index) => {
                                shareFeed(index, $("web").url)
                            }
                        })
                        $device.taptic(2)
                    }
                }
            }]
        }, {
            type: "blur",
            props: {
                style: 1,
                circular: true
            },
            layout: function (make, view) {
                make.right.inset(75)
                make.bottom.inset(20)
                make.size.equalTo($size(50, 50))
            },
            views: [{
                type: "button",
                props: {
                    id: "friesBt",
                    src: "assets/fries.png"
                },
                layout: $layout.fill,
                events: {
                    tapped: function (sender) {
                        searchMovie(id, "searchSky", "douBanView")
                    },
                    doubleTapped: async function (sender) {
                        var imdbId = await imdbIdGet(id)
                        $("web").url = "https://www.imdb.com/title/" + imdbId
                    },
                    longPressed: function (sender) {
                        searchMovie(id, "airtableUpload", "douBanView")
                        $device.taptic(2)
                    }
                }
            }]
        }]
    });
}

module.exports = {
    doubanView: doubanView,
    searchMovie: searchMovie
}

async function searchMovie(id, type, viewId) {
    var movieData = await $http.get("https://api.douban.com/v2/movie/subject/" + id)
    if (movieData.data.title) {
        if (type == "searchSky") {
            var search = require("scripts/search")
            search.search(movieData.data.title, "skyMovie", "douBanView")
        } else {
            var imdbId = await imdbIdGet(id)
            airtableUpload(movieData.data, imdbId, viewId)
        }
    }
}

var keyToken = require("scripts/keyToken")

function airtableUpload(data, imdbId, viewId) {
    buttonAnimation(viewId)
    $http.post({
        url: "", //Airtable内Doudan Table 请求链接
        header: {
            "Authorization": "Bearer " + keyToken.keyTokenGet("airtableKey")
        },
        body: {
            "fields": {
                "Title": data.title + "  " + data.original_title,
                "Description": data.summary,
                "Year": data.year,
                "Poster": [{ "url": data.images.large }],
                "Actors": charsName(data.casts),
                "Director": charsName(data.directors),
                "Genre": data.genres.toString(),
                "Rating": data.rating.average,
                "Douban": "https://movie.douban.com/subject/" + data.id,
                "IMDb": "https://www.imdb.com/title/" + imdbId
            }
        },
        handler: function (resp) {
            timer.invalidate()
            $("loadingView").remove()
            if (resp.data.error) {
                $ui.alert({
                    title: resp.data.error.type,
                    message: resp.data.error.message
                })
            } else {
                $audio.play({ url: 'file:////System/Library/Audio/UISounds/health_notification.caf' })
                imdbUpload(imdbId, data.id, resp.data.id, viewId) //上传IMDb Table
            }
        }
    })
}

function charsName(position) {
    var names = ""
    for (var i = 0; i < position.length; i++) {
        if (i < position.length - 1) {
            names = names + position[i].name + " / "
        } else {
            names = names + position[i].name
        }
    }
    return names
}

async function imdbIdGet(dbId) {
    var imdbPage = await $http.get("https://movie.douban.com/subject/" + dbId)
    var imdbUrl = imdbPage.data.match(/http:\/\/www.imdb.com\/title[^"]+/g)
    var imdbId = imdbUrl[0].match(/tt\d+/)
    return imdbId[0]
}

async function imdbUpload(imdbId, dbId, dbRecordId, viewId) {
    var imdbData = await $http.post({
        url: "http://imdbapi.net/api",
        header: {
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"
        },
        body: {
            "key": keyToken.keyTokenGet("imdbKey"),
            "id": imdbId,
            "type": "json"
        }
    })

    var data = imdbData.data
    if (data.status == "false") {
        $ui.alert({
            title: data.status,
            message: data.message
        })
    } else {
        buttonAnimation(viewId)
        $http.post({
            url: "", //Airtable内IMDb Table 请求链接
            header: {
                "Authorization": "Bearer " + keyToken.keyTokenGet("airtableKey")
            },
            body: {
                "fields": {
                    "Title": data.title,
                    "Description": data.plot,
                    "Year": data.year,
                    "Poster": [{ "url": data.poster }],
                    "Actors": data.actors,
                    "Director": data.director,
                    "Genre": data.genre,
                    "Rating": data.rating,
                    "Douban": "https://movie.douban.com/subject/" + dbId,
                    "IMDb": "https://www.imdb.com/title/" + imdbId,
                    "Douban Table": [dbRecordId]
                }
            },
            handler: function (resp) {
                timer.invalidate()
                $("loadingView").remove()
                var data = resp.data
                if (data.error) {
                    $ui.alert({
                        title: data.error.type,
                        message: data.error.message
                    })
                } else {
                    $audio.play({ url: 'file:////System/Library/Audio/UISounds/health_notification.caf' })
                }
            }
        })
    }
}

function buttonAnimation(viewId) {
    var button = require("scripts/button")
    button.buttonAnimation(viewId)
}

async function shareFeed(type, url) {
    if (type == 0) {
        $ui.alert({
            title: $l10n("FEEDCONFIRM"),
            actions: [
                {
                    title: $l10n("OK"),
                    handler: async function () {
                        buttonAnimation("web")
                        var timestamp = new Date().getTime()
                        timestamp = timestamp.toString()
                        timestamp = timestamp.match(/\d{10}/)
                        var token = $text.MD5(keyToken.keyTokenGet("movieToken") + "parse_api" + timestamp[0])
                        var feedResults = await $http.post({
                            url: "https://www.kdy666.com/Api/ApiVideo/InputKeyWord",
                            header: {
                                "OpenToken": token,
                                "Timestamp": timestamp[0],
                                "Key": keyToken.keyTokenGet("movieToken")
                            },
                            body: {
                                "InputKey": url,
                                "EVideoType": "3"
                            }
                        })
                        timer.invalidate()
                        $("loadingView").remove()
                        if (feedResults.data.Code == 200) {
                            alert(feedResults.data.ResultData)
                        } else {
                            alert(feedResults.data.ErrMsg)
                        }
                    }
                },
                {
                    title: $l10n("CANCEL"),
                    handler: function () {

                    }
                }
            ]
        })
    } else {
        $share.sheet(url)
    }
}