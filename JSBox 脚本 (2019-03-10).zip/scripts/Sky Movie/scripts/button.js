function buttonAnimation(id) {
    var loadingView = {
        type: "view",
        props: {
            id: "loadingView",
            bgcolor: $color("clear")
        },
        layout: $layout.fill,
        views: [{
            type: "blur",
            props: {
                style: 1,
                radius: 15
            },
            layout: function (make, view) {
                make.size.equalTo($size(100, 100))
                make.center.equalTo(view.super)
            },
            views: [{
                type: "image",
                props: {
                    id: "loadingImg",
                    bgcolor: $color("clear")
                },
                layout: function (make, view) {
                    make.center.equalTo(view.super)
                    make.size.equalTo($size(80, 80))
                }
            }]
        }]
    }
    $(id).add(loadingView)
    var icon = ["popcorn", "coke", "fries", "ice-cream", "candy", "sprite"]
    var i = 0
    timer = $timer.schedule({
        interval: 0.1,
        handler: function () {
            $("loadingImg").src = "assets/" + icon[i] + ".png"
            i = i + 1
            if (i == 6) {
                i = 0
            }
        }
    })
}

module.exports = {
    buttonAnimation: buttonAnimation
}