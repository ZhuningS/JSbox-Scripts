function keyTokenGet(type) {
    var keyToken = JSON.parse($file.read("assets/settings.json").string)
    if (type == "movieToken") {
        return keyToken.movieToken
    } else if (type == "airtableKey") {
        return keyToken.airtableKey
    } else {
        return keyToken.imdbKey
    }
}

module.exports = {
    keyTokenGet: keyTokenGet
}