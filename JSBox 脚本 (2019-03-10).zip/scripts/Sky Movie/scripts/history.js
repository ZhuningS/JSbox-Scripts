function history(data) {
    var history = $cache.get("history")
    if (data.name) {
        var id = data.name.info
        var historyData = {
            historyCover: {
                src: data.cover.src,
            },
            historyMovieTitle: {
                text: data.movieTitle.text
            },
            historyScore: {
                text: data.score.text
            },
            historyName: {
                text: data.name.text,
                info: id
            },
            historyTags: {
                text: data.tags.text
            }
        }
    } else {
        id = data.historyName.info
    }

    if (history) {
        var duplicate = history.ids.indexOf(id)
        if (duplicate == -1) {
            history.ids.unshift(id)
            history.idsData[id] = historyData
        } else {
            history.ids.splice(duplicate, 1)
            history.ids.unshift(id)
        }
        if (history.ids.length >= 10) {
            var newHistory = history.idsData
            history.idsData = {}
            for (var i = 0; i <= 10; i++) {
                history.idsData[history.ids[i]] = newHistory[history.ids[i]]
            }
        }
        $cache.set("history", history)
    } else {
        $cache.set("history", {
            idsData: { [id]: historyData },
            ids: [id]
        })
    }
    historyDataUpdate()
}

function historyDataUpdate() {
    var historyData = $cache.get("history")
    if (historyData) {
        var matrixData = []
        for (var i in historyData.ids) {
            matrixData.push(historyData.idsData[historyData.ids[i]])
        }
        $("historyMatrix").data = matrixData
    } else {
        $("historyMatrix").data = []
    }
}

function delHistory(id) {
    var historyData = $cache.get("history")
    var delId = historyData.ids.indexOf(id)
    historyData.ids.splice(delId, 1)
    delete historyData.idsData[id]
    $cache.set("history", historyData)
    historyDataUpdate()
}

module.exports = {
    history: history,
    historyDataUpdate: historyDataUpdate,
    delHistory: delHistory
}