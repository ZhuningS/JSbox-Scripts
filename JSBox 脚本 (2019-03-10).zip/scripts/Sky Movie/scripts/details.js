async function resultDetails(id, viewId, type) {
    if (type == "skyMovie") {
        buttonAnimation(viewId)
        var keyToken = require("scripts/keyToken")
        var timestamp = new Date().getTime()
        timestamp = timestamp.toString()
        timestamp = timestamp.match(/\d{10}/)
        var token = $text.MD5(keyToken.keyTokenGet("movieToken") + "parse_api" + timestamp[0])
        var results = await $http.post({
            url: "https://www.kdy666.com/Api/ApiVideo/Detail",
            header: {
                "OpenToken": token,
                "Timestamp": timestamp[0],
                "Key": keyToken.keyTokenGet("movieToken")
            },
            body: {
                "ObjectId": id,
                "pagesize": "999"
            }
        })
        timer.invalidate()
        $("loadingView").remove()
        var detailsData = results.data.ResultData
        if (detailsData.VideoDetail) {
            var dbId = detailsData.VideoDetail.match(/\d+/)
        }
        var playNameData = []
        for (var i in detailsData.EpisodeList) {
            playNameData.push({
                playName: {
                    text: detailsData.EpisodeList[i].EpisodeName,
                    info: "https://www.kdy666.com/Movie/VodPlay/" + detailsData.EpisodeList[i].EpisodeUrl
                }
            })
        }
        $ui.push({
            props: {
                id: "detailsView",
                navBarHidden: 1,
                statusBarStyle: 0,
                bgcolor: $color("#F3F7FB"),
                homeIndicatorHidden: 1
            },
            views: [{
                type: "scroll",
                props: {
                    showsHorizontalIndicator: false,
                    showsVerticalIndicator: false
                },
                layout: $layout.fill,
                views: [{
                    type: "image",
                    props: {
                        id: "detailsCover",
                        src: detailsData.ResultImg
                    },
                    layout: function (make, view) {
                        make.top.inset(30)
                        make.centerX.equalTo(view.super)
                    }
                }, {
                    type: "label",
                    props: {
                        id: "detailsName",
                        text: detailsData.ResultName,
                        textColor: $color("#007E00"),
                        align: $align.left,
                        font: $font("HelveticaNeue-Bold", 21)
                    },
                    layout: function (make, view) {
                        make.top.equalTo($("detailsCover").bottom).inset(10)
                        make.left.inset(15)
                        make.width.equalTo(view.super)
                    }
                }, {
                    type: "label",
                    props: {
                        id: "detailsYear",
                        text: "(" + detailsData.VideoYear + ")",
                        textColor: $color("#BABABA"),
                        align: $align.left,
                        font: $font(15)
                    },
                    layout: function (make, view) {
                        make.top.equalTo($("detailsName").bottom).inset(5)
                        make.left.inset(15)
                        make.width.equalTo(view.super)
                    }
                }, {
                    type: "label",
                    props: {
                        id: "detailsIntroduction",
                        text: ("导演：" + detailsData.VideoDirectors + "\n主演：" + detailsData.VideoCasts + "\n简介：" + detailsData.VideoSummary).replace(/\n/g, "\n\n"),
                        textColor: $color("#BABABA"),
                        align: $align.left,
                        font: $font(15),
                        lines: 0
                    },
                    layout: function (make, view) {
                        make.top.equalTo($("detailsYear").bottom).inset(15)
                        make.left.inset(15)
                        make.right.equalTo($("detailsYear").right).inset(30)
                        make.height.equalTo(textSize($("detailsIntroduction").text))
                    }
                }, {
                    type: "matrix",
                    props: {
                        bgcolor: $color("#F3F7FB"),
                        columns: 3,
                        itemHeight: 32,
                        spacing: 5,
                        data: playNameData,
                        template: {
                            props: {},
                            views: [
                                {
                                    type: "view",
                                    props: {
                                        bgcolor: $color("white")
                                    },
                                    layout: function (make, view) {
                                        make.edges.insets(5, 5, 5, 5)
                                        shadow(view)
                                    },
                                    views: [{
                                        type: "label",
                                        props: {
                                            id: "playName",
                                            textColor: $color("darkGray"),
                                            align: $align.center,
                                            font: $font(15)
                                        },
                                        layout: $layout.fill
                                    }]
                                }
                            ]
                        }
                    },
                    layout: function (make, view) {
                        var height = (detailsData.EpisodeList.length / 3 + 1) * 37 + 10
                        make.top.equalTo($("detailsIntroduction").bottom).inset(15)
                        make.left.inset(15)
                        make.right.equalTo($("detailsYear").right).inset(30)
                        make.height.equalTo(height)
                    },
                    events: {
                        didSelect: function (sender, indexPath, data) {
                            watchOrShare(data.playName.info, "watch")
                        },
                        didLongPress: function (sender, indexPath, data) {
                            watchOrShare(data.playName.info, "share")
                            $device.taptic(2)
                        }
                    }
                }, {
                    type: "label",
                    props: {
                        text: "Sky Movie by Neurogram",
                        textColor: $color("gray"),
                        font: $font(13),
                        align: $align.center
                    },
                    layout: function (make, view) {
                        make.top.equalTo($("matrix").bottom).inset(15)
                        make.centerX.equalTo($("matrix").centerX)
                    },
                    events: {
                        tapped: function (sender) {
                            var buyMeaCoffee = require('scripts/coffee')
                            buyMeaCoffee.coffee("detailsView")
                        }
                    }
                }]
            }, {
                type: "blur",
                props: {
                    style: 1,
                    circular: true
                },
                layout: function (make, view) {
                    make.right.bottom.inset(20)
                    make.size.equalTo($size(50, 50))
                },
                views: [{
                    type: "button",
                    props: {
                        src: "assets/popcorn.png"
                    },
                    layout: $layout.fill,
                    events: {
                        tapped: function (sender) {
                            $ui.pop()
                        }
                    }
                }]
            }, {
                type: "blur",
                props: {
                    style: 1,
                    circular: true
                },
                layout: function (make, view) {
                    make.right.inset(75)
                    make.bottom.inset(20)
                    make.size.equalTo($size(50, 50))
                },
                views: [{
                    type: "button",
                    props: {
                        src: "assets/coke.png"
                    },
                    layout: $layout.fill,
                    events: {
                        tapped: function (sender) {
                            if (dbId) {
                                doubanView(dbId[0])
                            } else {
                                var search = require("scripts/search")
                                search.search(detailsData.ResultName, "douban", "detailsView")
                            }
                        },
                        longPressed: function (sender) {
                            airtableCheck(dbId[0])
                            $device.taptic(2)
                        }
                    }
                }]
            }]
        })
    } else {
        doubanView(id)
    }
}

module.exports = {
    resultDetails: resultDetails
}

function shadow(view) {
    var layer = view.runtimeValue().invoke("layer")
    layer.invoke("setCornerRadius", 5)
    layer.invoke("setShadowOffset", $size(3, 3))
    layer.invoke("setShadowColor", $color("gray").runtimeValue().invoke("CGColor"))
    layer.invoke("setShadowOpacity", 0.3)
    layer.invoke("setShadowRadius", 5)
}

function textSize(text) {
    var size = $text.sizeThatFits({
        text: text,
        width: $device.info.screen.width - 30,
        font: $font(15)
    })
    return size.height

}

function buttonAnimation(viewId) {
    var button = require("scripts/button")
    button.buttonAnimation(viewId)
}

var douban = require("scripts/douban")

async function doubanView(id) {
    if (await idCheck(id) == true) {
        douban.doubanView(id)
    } else {
        alert($l10n("NODBPAGE"))
    }
}

async function airtableCheck(id) {
    if (await idCheck(id) == true) {
        douban.searchMovie(id, "airtableUpload", "detailsView")
    } else {
        alert($l10n("NODBPAGE"))
    }
}

async function idCheck(id) {
    var idCheck = await $http.get("https://api.douban.com/v2/movie/subject/" + id)
    if (idCheck.data.msg == "movie_not_found") {
        return false
    } else {
        return true
    }
}

async function watchOrShare(link, type) {
    var resp = await $http.get(link)
    var data = resp.data.match(/<iframe src="[^"]+/)
    if (data) {
        var videoUrl = data[0].replace(/<iframe src="/, "https:")
        if (type == "watch") {
            $safari.open({
                url: videoUrl
            })
        } else {
            $share.sheet(videoUrl)
        }
    } else {
        var resource = resp.data.indexOf("资源已屏蔽")
        if (resource != -1) {
            alert("应版权方要求，资源已屏蔽！")
        }
    }
}