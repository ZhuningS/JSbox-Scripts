async function search(keywords, type, viewId) {
    if (type == "skyMovie") {
        buttonAnimation(viewId)
        var keyToken = require("scripts/keyToken")
        var timestamp = new Date().getTime()
        timestamp = timestamp.toString()
        timestamp = timestamp.match(/\d{10}/)
        var token = $text.MD5(keyToken.keyTokenGet("movieToken") + "parse_api" + timestamp[0])
        var results = await $http.post({
            url: "https://www.kdy666.com/Api/ApiVideo",
            header: {
                "OpenToken": token,
                "Timestamp": timestamp[0],
                "Key": keyToken.keyTokenGet("movieToken")
            },
            body: {
                "KeyWord": keywords,
                "pagesize": "999"
            }
        })
    } else {
        buttonAnimation(viewId)
        var results = await $http.get("https://api.douban.com/v2/movie/search?q=" + $text.URLEncode(keywords))
    }
    timer.invalidate()
    $("loadingView").remove()
    var listData = []

    if (type == "skyMovie") {
        if (results.data.Code == 403) {
            $ui.alert({
                title: $l10n("ERROR"),
                message: $l10n("ERRORMSG"),
                actions: [
                    {
                        title: $l10n("SETTINGS"),
                        handler: function () {
                            var settings = require("scripts/settings")
                            settings.settingView("searchView")

                        }
                    },
                    {
                        title: $l10n("CANCEL"),
                        handler: function () {

                        }
                    }
                ]
            })
        } else if (results.data.Code == 202) {
            $ui.alert({
                title: $l10n("NORESULTS"),
                message: $l10n("SEARCHDOUBAN"),
                actions: [
                    {
                        title: $l10n("OK"),
                        handler: function () {
                            search(keywords, "douban", "searchView")
                        }
                    },
                    {
                        title: $l10n("CANCEL"),
                        handler: function () {

                        }
                    }
                ]
            })
        }
        var resultData = results.data.ResultData
        for (var i in resultData) {
            if (resultData[i].ResultName) {
                movieTitleData = " " + resultData[i].MovieType + " "
            } else {
                movieTitleData = ""
            }
            listData.push({
                cover: {
                    src: resultData[i].ResultImg,
                },
                movieTitle: {
                    text: movieTitleData
                },
                score: {
                    text: " " + resultData[i].VideoRating + " "
                },
                name: {
                    text: "《" + resultData[i].ResultName + "》",
                    info: resultData[i].objectId
                },
                tags: {
                    text: "类型：" + resultData[i].VideoGenres
                }
            })
        }
    } else {
        for (var i in results.data.subjects) {
            listData.push({
                cover: {
                    src: results.data.subjects[i].images.large,
                },
                movieTitle: {
                    text: " " + results.data.subjects[i].year + " "
                },
                score: {
                    text: " " + results.data.subjects[i].rating.average + " "
                },
                name: {
                    text: "《" + results.data.subjects[i].title + "  " + results.data.subjects[i].original_title + "》",
                    info: results.data.subjects[i].id
                },
                tags: {
                    text: "类型：" + results.data.subjects[i].genres
                }
            })
        }
    }

    resultsList(listData, keywords, type)
}

if ($app.env == $env.today) {
    var labelHeight = 15
} else {
    var labelHeight = 90 * $device.info.screen.height / 812
}

function resultsList(data, keywords, type) {
    if (type == "skyMovie") {
        var btIcon = "popcorn.png"
    } else {
        var btIcon = "coke.png"
    }
    $ui.push({
        props: {
            id: "searchView",
            navBarHidden: 1,
            statusBarStyle: 0,
            homeIndicatorHidden: 1
        },
        views: [{
            type: "label",
            props: {
                id: "keywordslabel",
                text: keywords,
                align: $align.center,
                font: $font("HelveticaNeue-Bold", 30)
            },
            layout: function (make, view) {
                make.top.inset(labelHeight)
                make.left.inset(15)
            }
        }, {
            type: "matrix",
            props: {
                columns: 2,
                itemHeight: 305,
                spacing: 5,
                bgcolor: $color("clear"),
                data: data,
                template: {
                    props: {
                        bgcolor: $color("clear")
                    },
                    views: [
                        {
                            type: "view",
                            props: {
                                clipsToBounds: false,
                                bgcolor: $color("#EFEFF4")
                            },
                            layout: function (make, view) {
                                make.edges.insets($insets(10, 0, 10, 0))
                                shadow(view)
                            },
                            views: [{
                                type: "image",
                                props: {
                                    id: "cover",
                                    radius: 5
                                },
                                layout: function (make, view) {
                                    make.top.left.right.inset(0)
                                    make.centerX.equalTo(view.super.centerX)
                                    make.height.equalTo(235)
                                },
                                views: [{
                                    type: "label",
                                    props: {
                                        id: "movieTitle",
                                        textColor: $color("white"),
                                        bgcolor: $color("orange"),
                                        align: $align.left,
                                        font: $font("HelveticaNeue-Bold", 10),
                                        radius: 3,
                                        alpha: 0.9
                                    },
                                    layout: function (make, view) {
                                        make.top.left.inset(5)
                                    }
                                }, {
                                    type: "label",
                                    props: {
                                        id: "score",
                                        textColor: $color("white"),
                                        bgcolor: $color("black"),
                                        align: $align.left,
                                        font: $font("HelveticaNeue-Bold", 13),
                                        radius: 3,
                                        alpha: 0.9
                                    },
                                    layout: function (make, view) {
                                        make.bottom.right.inset(5)
                                    }
                                }]
                            }, {
                                type: "label",
                                props: {
                                    id: "name",
                                    textColor: $color("darkGray"),
                                    align: $align.left,
                                    font: $font("HelveticaNeue-Bold", 15),
                                    radius: 3,
                                    alpha: 0.9
                                },
                                layout: function (make, view) {
                                    make.top.equalTo($("cover").bottom).inset(5)
                                    make.left.inset(0)
                                    make.right.inset(5)
                                }
                            }, {
                                type: "label",
                                props: {
                                    id: "tags",
                                    textColor: $color("gray"),
                                    align: $align.left,
                                    font: $font("HelveticaNeue-Bold", 13),
                                    radius: 3,
                                    alpha: 0.9
                                },
                                layout: function (make, view) {
                                    make.top.equalTo($("name").bottom).inset(5)
                                    make.left.inset(5)
                                    make.right.inset(5)
                                }
                            }]
                        }
                    ]
                }
            },
            events: {
                didSelect: function (sender, indexPath, data) {
                    resultDetail(data.name.info, type)
                    history(data)
                }
            },
            layout: function (make, views) {
                make.top.equalTo($("keywordslabel").bottom).inset(5)
                make.left.right.bottom.inset(0)
            }
        }, {
            type: "blur",
            props: {
                style: 1,
                circular: true
            },
            layout: function (make, view) {
                make.right.bottom.inset(20)
                make.size.equalTo($size(50, 50))
            },
            views: [{
                type: "button",
                props: {
                    id: "resultsBt",
                    src: "assets/" + btIcon
                },
                layout: $layout.fill,
                events: {
                    tapped: function (sender) {
                        $ui.pop()
                    }
                }
            }]
        }]
    });
}

module.exports = {
    search: search
}

function shadow(view) {
    var layer = view.runtimeValue().invoke("layer")
    layer.invoke("setCornerRadius", 5)
    layer.invoke("setShadowOffset", $size(3, 3))
    layer.invoke("setShadowColor", $color("gray").runtimeValue().invoke("CGColor"))
    layer.invoke("setShadowOpacity", 0.3)
    layer.invoke("setShadowRadius", 5)
}

function resultDetail(id, type) {
    if (id) {
        var details = require("scripts/details")
        details.resultDetails(id, "searchView", type)
    }
}

function buttonAnimation(viewId) {
    var button = require("scripts/button")
    button.buttonAnimation(viewId)
}

function history(data) {
    var history = require("scripts/history")
    history.history(data)
}