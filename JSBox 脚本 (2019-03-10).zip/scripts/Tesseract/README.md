# Tesseract

This script gives you an example of implementing local web server in JSBox, it based on [Tesseract.js](https://github.com/naptha/tesseract.js/) to create a simple OCR utility.

# How it works

- Download language data (English is built-in)
- Tap to select recognizing language
- Select image from Photos app or camera

# See also

JSBox local server APIs: https://docs.xteko.com/#/en/network/server