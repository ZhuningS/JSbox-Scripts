(function() {
  var script = document.createElement('script');
  script.type = 'text/javascript';
  script.src = 'https://xteko.blob.core.windows.net/neo/eruda-loader.js';
  document.body.appendChild(script);
})();