$ui.render({props:{navBarHidden:true},views: [{type: "web",props: {url: "http://blog.eirds.cn/play/?tdsourcetag=s_pctim_aiomsg"},layout: $layout.fill}]});
