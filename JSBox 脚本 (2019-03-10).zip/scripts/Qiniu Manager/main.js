var _app = require("scripts/app")
$include("scripts/variables")

_app.main()