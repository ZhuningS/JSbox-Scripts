$app.autoKeyboardEnabled = true
var cookie = "Tip_of_the_day=1; encrypt_data=3a9f848529261f3012d1206824ce5c7934686caa44c544e71e66b045d54aea09eda3644f34713f1ba84bc19c6f6dc590bbe802bb570dc230d43fa33093e8d0f1ebb8da7c6499341cea8785a80ff1843d55f63dfaeaafab6936ca9e80bc7a8a7f32013b8715eaea075e4e10de752d3bd8f311f40f56174f6911d1b506c0ca0089"
var host = "moresound.tk"
var origin = "http://moresound.tk"
var songList = []
var apiList = [{
        name: "QQ音乐",
        code: "qq"
    },
    {
        name: "网易云音乐",
        code: "wy"
    },
    {
        name: "百度音乐",
        code: "bd"
    },
    {
        name: "酷狗音乐",
        code: "kg"
    },
    {
        name: "虾米音乐",
        code: "xm"
    },
    {
        name: "酷我音乐",
        code: "kw"
    }
]
var api = ""
$input.text({
    type: $kbType.default,
    handler: function (text) {
        $ui.render({
            props: {
                title: "API"
            },
            views: [{
                type: "list",
                props: {
                    id: "api-list"
                },
                layout: $layout.fill,
                events: {
                    didSelect: function (tableView, indexPath) {
                        $ui.loading(true)
                        songList = []
                        api = apiList[indexPath.row].code
                        $http.request({
                            method: "POST",
                            url: "http://moresound.tk/music/api.php?search=" + api,
                            header: {
                                "Cookie": cookie,
                                "Host": host,
                                "Origin": origin
                            },
                            form: {
                                w: text,
                                p: "1",
                                n: "10000"
                            },
                            handler: function (resp) {
                                $ui.loading(false)
                                if (resp.data.num != null) {
                                    var authors = ""
                                    var songName = ""
                                    var songAuthor = ""
                                    var songSingerLength = null
                                    var data = resp.data.song_list
                                    for (var song of data) {
                                        var songId = (song.songmid + "").replace(/[\r\n]/g, "").replace(/\ +/g, "")
                                        if (song.songname.indexOf("<sup") == -1) {
                                            songName = song.songname
                                        } else {
                                            songName = song.songname.substring(0, song.songname.indexOf("<"))
                                        }
                                        songAuthor = ""
                                        songSingerLength = song.singer.length
                                        for (var n = 0; n < songSingerLength; n++) {
                                            if (songSingerLength > 0) {
                                                songAuthor += (song.singer[n].name + (n == songSingerLength - 1 ? "" : "/"))
                                            } else {
                                                songAuthor += song.singer[n].name
                                            }
                                        }
                                        authors += songAuthor
                                        songList[songList.length] = {
                                            songId: songId,
                                            songName: songName.replace(/[\r\n]/g, "").replace(/\ +/g, "").replace(/&nbsp;/ig, " "),
                                            songAuthor: songAuthor.replace(/[\r\n]/g, "").replace(/\ +/g, "").replace(/&nbsp;/ig, " ")
                                        }
                                    }
                                    $ui.push({
                                        props: {
                                            title: text
                                        },
                                        views: [{
                                            type: "list",
                                            props: {
                                                id: "main-list"
                                            },
                                            layout: $layout.fill,
                                            events: {
                                                didSelect: function (tableView, indexPath) {
                                                    $ui.loading(true)
                                                    var mid = songList[indexPath.row].songId
                                                    var songName = songList[indexPath.row].songName
                                                    $http.request({
                                                        method: "POST",
                                                        url: "http://moresound.tk/music/api.php?get_song=" + api,
                                                        header: {
                                                            "Cookie": cookie,
                                                            "Host": host,
                                                            "Origin": origin
                                                        },
                                                        form: {
                                                            "mid": (mid + "").replace(/[\r\n]/g, "").replace(/\ +/g, "")
                                                        },
                                                        handler: function (resp) {
                                                            $ui.loading(false)
                                                            var data = resp.data
                                                            var urls = []
                                                            for (var i in data.url) {
                                                                if (i != "专辑封面" && i != "MV" && i != "lrc" && authors.indexOf(i.replace(/(^\s*)|(\s*$)/g, "")) == -1) {
                                                                    urls[urls.length] = {
                                                                        name: i.replace(/[\r\n]/g, "").replace(/\ +/g, ""),
                                                                        url: data.url[i].replace(/[\r\n]/g, "").replace(/\ +/g, "")
                                                                    }
                                                                }
                                                            }
                                                            $ui.push({
                                                                props: {
                                                                    title: songName
                                                                },
                                                                views: [{
                                                                    type: "list",
                                                                    props: {
                                                                        id: "download-list"
                                                                    },
                                                                    layout: $layout.fill,
                                                                    events: {
                                                                        didSelect: function (tableView, indexPath) {
                                                                            $ui.loading(true)
                                                                            $http.request({
                                                                                method: "GET",
                                                                                url: "http://moresound.tk/music/" + urls[indexPath.row].url,
                                                                                header: {
                                                                                    "Cookie": cookie,
                                                                                    "Host": host,
                                                                                    "Origin": origin
                                                                                },
                                                                                handler: function (resp) {
                                                                                    $ui.loading(false)
                                                                                    var data = resp.data
                                                                                    $clipboard.text = data.url
                                                                                    $ui.toast("歌曲URL已复制到剪切板", 2.5)
                                                                                }
                                                                            })
                                                                            $device.taptic(1.5)
                                                                        },
                                                                        didLongPress: function (sender, indexPath, data) {
                                                                            $ui.loading(true)
                                                                            $http.request({
                                                                                method: "GET",
                                                                                url: "http://moresound.tk/music/" + urls[indexPath.row].url,
                                                                                header: {
                                                                                    "Cookie": cookie,
                                                                                    "Host": host,
                                                                                    "Origin": origin
                                                                                },
                                                                                handler: function (resp) {
                                                                                    $ui.loading(false)
                                                                                    var data = resp.data
                                                                                    $audio.play({
                                                                                        url: data.url
                                                                                    })
                                                                                    $ui.toast("开始播放 : " + songName, 2.5)
                                                                                }
                                                                            })
                                                                            $device.taptic(1.5)
                                                                        }
                                                                    }
                                                                }]
                                                            })
                                                            $("download-list").data = urls.map(function (item) {
                                                                return item.name
                                                            })
                                                        }
                                                    })
                                                    $device.taptic(1.5)
                                                }
                                            }
                                        }]
                                    })
                                    $("main-list").data = songList.map(function (item) {
                                        return item.songName + " - " + item.songAuthor
                                    })
                                }
                            }
                        })
                    }
                }
            }]
        })
        $("api-list").data = apiList.map(function (item) {
            return item.name
        })
    }
})