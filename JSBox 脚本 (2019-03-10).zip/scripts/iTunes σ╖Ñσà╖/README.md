# iTunes Utilities

在钟大的 itunes-search 脚本基础上修改增强

- 增加扩展运行方式
- 增加多媒体类型的分享
- 增加 macOS、iPad 分类
- 增加 App 今日推荐壁纸下载
- 增加 Version ID 获取(用于查询下载旧版)
- 增加应用描述和更新翻译(Google API + 链接可点击)
- 增加详细信息、价格变化预览(AppzApp API，需自备 deviceuid，可抓包提取)
- 增加 Widget 获取分享当前 Music.app 播放音乐(查询顺序：AM->网易云->内置图片纯文字分享)

[Tap to Install](https://xteko.com/redir?name=iTunes%20Utilities&url=https%3A%2F%2Fgithub.com%2Faxelburks%2FJSBox%2Fraw%2Fmaster%2FiTunes%2520Utilities%2F.output%2FiTunes%2520Utilities.box)