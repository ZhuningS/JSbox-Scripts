# CamNotes

- Take a photo
- Add notes
- That's done!

# Tips

- Can be launched from share sheet
- Long press to reorder items